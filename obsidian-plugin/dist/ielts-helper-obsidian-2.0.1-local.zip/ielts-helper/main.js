"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target2, all) => {
  for (var name in all)
    __defProp(target2, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target2) => (target2 = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target2, "default", { value: mod, enumerable: true }) : target2,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/pend/index.js
var require_pend = __commonJS({
  "node_modules/pend/index.js"(exports2, module2) {
    module2.exports = Pend;
    function Pend() {
      this.pending = 0;
      this.max = Infinity;
      this.listeners = [];
      this.waiting = [];
      this.error = null;
    }
    Pend.prototype.go = function(fn) {
      if (this.pending < this.max) {
        pendGo(this, fn);
      } else {
        this.waiting.push(fn);
      }
    };
    Pend.prototype.wait = function(cb) {
      if (this.pending === 0) {
        cb(this.error);
      } else {
        this.listeners.push(cb);
      }
    };
    Pend.prototype.hold = function() {
      return pendHold(this);
    };
    function pendHold(self) {
      self.pending += 1;
      var called = false;
      return onCb;
      function onCb(err) {
        if (called) throw new Error("callback called twice");
        called = true;
        self.error = self.error || err;
        self.pending -= 1;
        if (self.waiting.length > 0 && self.pending < self.max) {
          pendGo(self, self.waiting.shift());
        } else if (self.pending === 0) {
          var listeners = self.listeners;
          self.listeners = [];
          listeners.forEach(cbListener);
        }
      }
      function cbListener(listener) {
        listener(self.error);
      }
    }
    function pendGo(self, fn) {
      fn(pendHold(self));
    }
  }
});

// node_modules/yauzl/fd-slicer.js
var require_fd_slicer = __commonJS({
  "node_modules/yauzl/fd-slicer.js"(exports2) {
    var fs12 = require("fs");
    var util = require("util");
    var stream = require("stream");
    var Readable = stream.Readable;
    var PassThrough = stream.PassThrough;
    var Pend = require_pend();
    var EventEmitter = require("events").EventEmitter;
    exports2.BufferSlicer = BufferSlicer;
    exports2.FdSlicer = FdSlicer;
    util.inherits(FdSlicer, EventEmitter);
    function FdSlicer(fd) {
      EventEmitter.call(this);
      this.fd = fd;
      this.pend = new Pend();
      this.pend.max = 1;
      this.refCount = 0;
    }
    FdSlicer.prototype.read = function(buffer, offset, length, position, callback) {
      var self = this;
      self.pend.go(function(cb) {
        fs12.read(self.fd, buffer, offset, length, position, function(err, bytesRead, buffer2) {
          cb();
          callback(err, bytesRead, buffer2);
        });
      });
    };
    FdSlicer.prototype.createReadStream = function(options2) {
      return new ReadStream(this, options2);
    };
    FdSlicer.prototype.ref = function() {
      this.refCount += 1;
    };
    FdSlicer.prototype.unref = function() {
      var self = this;
      self.refCount -= 1;
      if (self.refCount < 0) throw new Error("invalid unref");
      if (self.refCount > 0) return;
      fs12.close(self.fd, onCloseDone);
      function onCloseDone(err) {
        if (err) {
          self.emit("error", err);
        } else {
          self.emit("close");
        }
      }
    };
    util.inherits(ReadStream, Readable);
    function ReadStream(context, options2) {
      options2 = options2 || {};
      Readable.call(this, options2);
      this.context = context;
      this.context.ref();
      this.start = options2.start || 0;
      this.endOffset = options2.end;
      this.pos = this.start;
    }
    ReadStream.prototype._read = function(n) {
      var self = this;
      var toRead = Math.min(self._readableState.highWaterMark, n);
      if (self.endOffset != null) {
        toRead = Math.min(toRead, self.endOffset - self.pos);
      }
      if (toRead <= 0) {
        self.push(null);
        this._cleanup();
        return;
      }
      self.context.pend.go(function(cb) {
        var buffer = Buffer.allocUnsafe(toRead);
        fs12.read(self.context.fd, buffer, 0, toRead, self.pos, function(err, bytesRead) {
          if (err) {
            self.destroy(err);
          } else if (bytesRead === 0) {
            self.push(null);
            self._cleanup();
          } else {
            self.pos += bytesRead;
            self.push(buffer.slice(0, bytesRead));
          }
          cb();
        });
      });
    };
    ReadStream.prototype._destroy = function(err, cb) {
      this._cleanup();
      cb(err);
    };
    ReadStream.prototype._cleanup = function() {
      if (this.context != null) {
        this.context.unref();
        this.context = null;
      }
    };
    util.inherits(BufferSlicer, EventEmitter);
    function BufferSlicer(buffer) {
      EventEmitter.call(this);
      this.refCount = 0;
      this.buffer = buffer;
    }
    BufferSlicer.prototype.read = function(buffer, offset, length, position, callback) {
      if (!(0 <= offset && offset <= buffer.length)) throw new RangeError("offset outside buffer: 0 <= " + offset + " <= " + buffer.length);
      if (position < 0) throw new RangeError("position is negative: " + position);
      if (offset + length > buffer.length) {
        length = buffer.length - offset;
      }
      if (position + length > this.buffer.length) {
        length = this.buffer.length - position;
      }
      if (length <= 0) {
        setImmediate(function() {
          callback(null, 0);
        });
        return;
      }
      this.buffer.copy(buffer, offset, position, position + length);
      setImmediate(function() {
        callback(null, length);
      });
    };
    BufferSlicer.prototype.createReadStream = function(options2) {
      options2 = options2 || {};
      var readStream = new PassThrough(options2);
      readStream.start = options2.start || 0;
      readStream.endOffset = options2.end;
      readStream.pos = readStream.endOffset || this.buffer.length;
      var entireSlice = this.buffer.slice(readStream.start, readStream.pos);
      var maxChunkSize = 65536;
      var offset = 0;
      while (true) {
        var nextOffset = offset + maxChunkSize;
        if (nextOffset >= entireSlice.length) {
          if (offset < entireSlice.length) {
            readStream.write(entireSlice.slice(offset, entireSlice.length));
          }
          break;
        }
        readStream.write(entireSlice.slice(offset, nextOffset));
        offset = nextOffset;
      }
      readStream.end();
      return readStream;
    };
    BufferSlicer.prototype.ref = function() {
      this.refCount += 1;
    };
    BufferSlicer.prototype.unref = function() {
      this.refCount -= 1;
      if (this.refCount < 0) {
        throw new Error("invalid unref");
      }
    };
  }
});

// node_modules/yauzl/crc32.js
var require_crc32 = __commonJS({
  "node_modules/yauzl/crc32.js"(exports2, module2) {
    var CRC_TABLE = new Int32Array([
      0,
      1996959894,
      3993919788,
      2567524794,
      124634137,
      1886057615,
      3915621685,
      2657392035,
      249268274,
      2044508324,
      3772115230,
      2547177864,
      162941995,
      2125561021,
      3887607047,
      2428444049,
      498536548,
      1789927666,
      4089016648,
      2227061214,
      450548861,
      1843258603,
      4107580753,
      2211677639,
      325883990,
      1684777152,
      4251122042,
      2321926636,
      335633487,
      1661365465,
      4195302755,
      2366115317,
      997073096,
      1281953886,
      3579855332,
      2724688242,
      1006888145,
      1258607687,
      3524101629,
      2768942443,
      901097722,
      1119000684,
      3686517206,
      2898065728,
      853044451,
      1172266101,
      3705015759,
      2882616665,
      651767980,
      1373503546,
      3369554304,
      3218104598,
      565507253,
      1454621731,
      3485111705,
      3099436303,
      671266974,
      1594198024,
      3322730930,
      2970347812,
      795835527,
      1483230225,
      3244367275,
      3060149565,
      1994146192,
      31158534,
      2563907772,
      4023717930,
      1907459465,
      112637215,
      2680153253,
      3904427059,
      2013776290,
      251722036,
      2517215374,
      3775830040,
      2137656763,
      141376813,
      2439277719,
      3865271297,
      1802195444,
      476864866,
      2238001368,
      4066508878,
      1812370925,
      453092731,
      2181625025,
      4111451223,
      1706088902,
      314042704,
      2344532202,
      4240017532,
      1658658271,
      366619977,
      2362670323,
      4224994405,
      1303535960,
      984961486,
      2747007092,
      3569037538,
      1256170817,
      1037604311,
      2765210733,
      3554079995,
      1131014506,
      879679996,
      2909243462,
      3663771856,
      1141124467,
      855842277,
      2852801631,
      3708648649,
      1342533948,
      654459306,
      3188396048,
      3373015174,
      1466479909,
      544179635,
      3110523913,
      3462522015,
      1591671054,
      702138776,
      2966460450,
      3352799412,
      1504918807,
      783551873,
      3082640443,
      3233442989,
      3988292384,
      2596254646,
      62317068,
      1957810842,
      3939845945,
      2647816111,
      81470997,
      1943803523,
      3814918930,
      2489596804,
      225274430,
      2053790376,
      3826175755,
      2466906013,
      167816743,
      2097651377,
      4027552580,
      2265490386,
      503444072,
      1762050814,
      4150417245,
      2154129355,
      426522225,
      1852507879,
      4275313526,
      2312317920,
      282753626,
      1742555852,
      4189708143,
      2394877945,
      397917763,
      1622183637,
      3604390888,
      2714866558,
      953729732,
      1340076626,
      3518719985,
      2797360999,
      1068828381,
      1219638859,
      3624741850,
      2936675148,
      906185462,
      1090812512,
      3747672003,
      2825379669,
      829329135,
      1181335161,
      3412177804,
      3160834842,
      628085408,
      1382605366,
      3423369109,
      3138078467,
      570562233,
      1426400815,
      3317316542,
      2998733608,
      733239954,
      1555261956,
      3268935591,
      3050360625,
      752459403,
      1541320221,
      2607071920,
      3965973030,
      1969922972,
      40735498,
      2617837225,
      3943577151,
      1913087877,
      83908371,
      2512341634,
      3803740692,
      2075208622,
      213261112,
      2463272603,
      3855990285,
      2094854071,
      198958881,
      2262029012,
      4057260610,
      1759359992,
      534414190,
      2176718541,
      4139329115,
      1873836001,
      414664567,
      2282248934,
      4279200368,
      1711684554,
      285281116,
      2405801727,
      4167216745,
      1634467795,
      376229701,
      2685067896,
      3608007406,
      1308918612,
      956543938,
      2808555105,
      3495958263,
      1231636301,
      1047427035,
      2932959818,
      3654703836,
      1088359270,
      936918e3,
      2847714899,
      3736837829,
      1202900863,
      817233897,
      3183342108,
      3401237130,
      1404277552,
      615818150,
      3134207493,
      3453421203,
      1423857449,
      601450431,
      3009837614,
      3294710456,
      1567103746,
      711928724,
      3020668471,
      3272380065,
      1510334235,
      755167117
    ]);
    function crc32(buf) {
      let crc = -1;
      for (let x of buf) {
        crc = CRC_TABLE[(crc ^ x) & 255] ^ crc >>> 8;
      }
      return (crc ^ -1) >>> 0;
    }
    module2.exports = crc32;
  }
});

// node_modules/yauzl/index.js
var require_yauzl = __commonJS({
  "node_modules/yauzl/index.js"(exports2) {
    var fs12 = require("fs");
    var zlib = require("zlib");
    var fd_slicer = require_fd_slicer();
    var util = require("util");
    var EventEmitter = require("events").EventEmitter;
    var Transform3 = require("stream").Transform;
    var PassThrough = require("stream").PassThrough;
    var Writable = require("stream").Writable;
    var crc32 = typeof zlib.crc32 === "function" ? zlib.crc32 : require_crc32();
    exports2.open = open2;
    exports2.fromFd = fromFd;
    exports2.fromBuffer = fromBuffer;
    exports2.fromRandomAccessReader = fromRandomAccessReader;
    exports2.openPromise = openPromise;
    exports2.fromFdPromise = fromFdPromise;
    exports2.fromBufferPromise = fromBufferPromise;
    exports2.fromRandomAccessReaderPromise = fromRandomAccessReaderPromise;
    exports2.dosDateTimeToDate = dosDateTimeToDate;
    exports2.getFileNameLowLevel = getFileNameLowLevel;
    exports2.validateFileName = validateFileName;
    exports2.parseExtraFields = parseExtraFields;
    exports2.ZipFile = ZipFile;
    exports2.Entry = Entry;
    exports2.LocalFileHeader = LocalFileHeader;
    exports2.RandomAccessReader = RandomAccessReader;
    function openPromise(path12, options2) {
      return new Promise((resolve, reject) => {
        open2(path12, { ...options2, lazyEntries: true }, function(err, zipfile) {
          if (err) return reject(err);
          resolve(zipfile);
        });
      });
    }
    function fromFdPromise(fd, options2) {
      return new Promise((resolve, reject) => {
        fromFd(fd, { ...options2, lazyEntries: true }, function(err, zipfile) {
          if (err) return reject(err);
          resolve(zipfile);
        });
      });
    }
    function fromBufferPromise(buffer, options2) {
      return new Promise((resolve, reject) => {
        fromBuffer(buffer, { ...options2, lazyEntries: true }, function(err, zipfile) {
          if (err) return reject(err);
          resolve(zipfile);
        });
      });
    }
    function fromRandomAccessReaderPromise(reader, totalSize, options2) {
      return new Promise((resolve, reject) => {
        fromRandomAccessReader(reader, totalSize, { ...options2, lazyEntries: true }, function(err, zipfile) {
          if (err) return reject(err);
          resolve(zipfile);
        });
      });
    }
    function open2(path12, options2, callback) {
      if (typeof options2 === "function") {
        callback = options2;
        options2 = null;
      }
      if (options2 == null) options2 = {};
      if (options2.autoClose == null) options2.autoClose = true;
      if (options2.lazyEntries == null) options2.lazyEntries = false;
      if (options2.decodeStrings == null) options2.decodeStrings = true;
      if (options2.validateEntrySizes == null) options2.validateEntrySizes = true;
      if (options2.strictFileNames == null) options2.strictFileNames = false;
      if (callback == null) callback = defaultCallback;
      fs12.open(path12, "r", function(err, fd) {
        if (err) return callback(err);
        fromFd(fd, options2, function(err2, zipfile) {
          if (err2) fs12.close(fd, defaultCallback);
          callback(err2, zipfile);
        });
      });
    }
    function fromFd(fd, options2, callback) {
      if (typeof options2 === "function") {
        callback = options2;
        options2 = null;
      }
      if (options2 == null) options2 = {};
      if (options2.autoClose == null) options2.autoClose = false;
      if (options2.lazyEntries == null) options2.lazyEntries = false;
      if (options2.decodeStrings == null) options2.decodeStrings = true;
      if (options2.validateEntrySizes == null) options2.validateEntrySizes = true;
      if (options2.strictFileNames == null) options2.strictFileNames = false;
      if (callback == null) callback = defaultCallback;
      fs12.fstat(fd, function(err, stats) {
        if (err) return callback(err);
        var reader = new fd_slicer.FdSlicer(fd);
        fromRandomAccessReader(reader, stats.size, options2, callback);
      });
    }
    function fromBuffer(buffer, options2, callback) {
      if (typeof options2 === "function") {
        callback = options2;
        options2 = null;
      }
      if (options2 == null) options2 = {};
      options2.autoClose = false;
      if (options2.lazyEntries == null) options2.lazyEntries = false;
      if (options2.decodeStrings == null) options2.decodeStrings = true;
      if (options2.validateEntrySizes == null) options2.validateEntrySizes = true;
      if (options2.strictFileNames == null) options2.strictFileNames = false;
      var reader = new fd_slicer.BufferSlicer(buffer);
      fromRandomAccessReader(reader, buffer.length, options2, callback);
    }
    function fromRandomAccessReader(reader, totalSize, options2, callback) {
      if (typeof options2 === "function") {
        callback = options2;
        options2 = null;
      }
      if (options2 == null) options2 = {};
      if (options2.autoClose == null) options2.autoClose = true;
      if (options2.lazyEntries == null) options2.lazyEntries = false;
      if (options2.decodeStrings == null) options2.decodeStrings = true;
      var decodeStrings = !!options2.decodeStrings;
      if (options2.validateEntrySizes == null) options2.validateEntrySizes = true;
      if (options2.strictFileNames == null) options2.strictFileNames = false;
      if (callback == null) callback = defaultCallback;
      if (typeof totalSize !== "number") throw new Error("expected totalSize parameter to be a number");
      if (totalSize > Number.MAX_SAFE_INTEGER) {
        throw new Error("zip file too large. only file sizes up to 2^52 are supported due to JavaScript's Number type being an IEEE 754 double.");
      }
      reader.ref();
      var eocdrWithoutCommentSize = 22;
      var zip64EocdlSize = 20;
      var maxCommentSize = 65535;
      var bufferSize = Math.min(zip64EocdlSize + eocdrWithoutCommentSize + maxCommentSize, totalSize);
      var buffer = newBuffer(bufferSize);
      var bufferReadStart = totalSize - buffer.length;
      readAndAssertNoEof(reader, buffer, 0, bufferSize, bufferReadStart, function(err) {
        if (err) return callback(err);
        for (var i = bufferSize - eocdrWithoutCommentSize; i >= 0; i -= 1) {
          if (buffer.readUInt32LE(i) !== 101010256) continue;
          var eocdrBuffer = buffer.subarray(i);
          var diskNumber = eocdrBuffer.readUInt16LE(4);
          var entryCount = eocdrBuffer.readUInt16LE(10);
          var centralDirectoryOffset = eocdrBuffer.readUInt32LE(16);
          var commentLength = eocdrBuffer.readUInt16LE(20);
          var expectedCommentLength = eocdrBuffer.length - eocdrWithoutCommentSize;
          if (commentLength !== expectedCommentLength) {
            return callback(new Error("Invalid comment length. Expected: " + expectedCommentLength + ". Found: " + commentLength + ". Are there extra bytes at the end of the file? Or is the end of central dir signature `PK\u263A\u263B` in the comment?"));
          }
          var comment = decodeStrings ? decodeBuffer(eocdrBuffer.subarray(22), false) : eocdrBuffer.subarray(22);
          if (i - zip64EocdlSize >= 0 && buffer.readUInt32LE(i - zip64EocdlSize) === 117853008) {
            var zip64EocdlBuffer = buffer.subarray(i - zip64EocdlSize, i - zip64EocdlSize + zip64EocdlSize);
            var zip64EocdrOffset = readUInt64LE(zip64EocdlBuffer, 8);
            var zip64EocdrBuffer = newBuffer(56);
            return readAndAssertNoEof(reader, zip64EocdrBuffer, 0, zip64EocdrBuffer.length, zip64EocdrOffset, function(err2) {
              if (err2) return callback(err2);
              if (zip64EocdrBuffer.readUInt32LE(0) !== 101075792) {
                return callback(new Error("invalid zip64 end of central directory record signature"));
              }
              diskNumber = zip64EocdrBuffer.readUInt32LE(16);
              if (diskNumber !== 0) {
                return callback(new Error("multi-disk zip files are not supported: found disk number: " + diskNumber));
              }
              entryCount = readUInt64LE(zip64EocdrBuffer, 32);
              centralDirectoryOffset = readUInt64LE(zip64EocdrBuffer, 48);
              return callback(null, new ZipFile(reader, centralDirectoryOffset, totalSize, entryCount, comment, options2.autoClose, options2.lazyEntries, decodeStrings, options2.validateEntrySizes, options2.strictFileNames));
            });
          }
          if (diskNumber !== 0) {
            return callback(new Error("multi-disk zip files are not supported: found disk number: " + diskNumber));
          }
          return callback(null, new ZipFile(reader, centralDirectoryOffset, totalSize, entryCount, comment, options2.autoClose, options2.lazyEntries, decodeStrings, options2.validateEntrySizes, options2.strictFileNames));
        }
        callback(new Error("End of central directory record signature not found. Either not a zip file, or file is truncated."));
      });
    }
    util.inherits(ZipFile, EventEmitter);
    function ZipFile(reader, centralDirectoryOffset, fileSize, entryCount, comment, autoClose, lazyEntries, decodeStrings, validateEntrySizes, strictFileNames) {
      var self = this;
      EventEmitter.call(self);
      self.reader = reader;
      self.reader.on("error", function(err) {
        emitError(self, err);
      });
      self.reader.once("close", function() {
        self.emit("close");
      });
      self.readEntryCursor = centralDirectoryOffset;
      self.fileSize = fileSize;
      self.entryCount = entryCount;
      self.comment = comment;
      self.entriesRead = 0;
      self.autoClose = !!autoClose;
      self.lazyEntries = !!lazyEntries;
      self.decodeStrings = !!decodeStrings;
      self.validateEntrySizes = !!validateEntrySizes;
      self.strictFileNames = !!strictFileNames;
      self.isOpen = true;
      self.emittedError = false;
      self.hasEachEntryBeenCalled = false;
      if (!self.lazyEntries) self._readEntry();
    }
    ZipFile.prototype.close = function() {
      if (!this.isOpen) return;
      this.isOpen = false;
      this.reader.unref();
    };
    function emitErrorAndAutoClose(self, err) {
      if (self.autoClose) self.close();
      emitError(self, err);
    }
    function emitError(self, err) {
      if (self.emittedError) return;
      self.emittedError = true;
      self.emit("error", err);
    }
    ZipFile.prototype.readEntry = function() {
      if (!this.lazyEntries) throw new Error("readEntry() called without lazyEntries:true");
      this._readEntry();
    };
    ZipFile.prototype._readEntry = function() {
      var self = this;
      if (self.entryCount === self.entriesRead) {
        setImmediate(function() {
          if (self.autoClose) self.close();
          if (self.emittedError) return;
          self.emit("end");
        });
        return;
      }
      if (self.emittedError) return;
      var buffer = newBuffer(46);
      readAndAssertNoEof(self.reader, buffer, 0, buffer.length, self.readEntryCursor, function(err) {
        if (err) return emitErrorAndAutoClose(self, err);
        if (self.emittedError) return;
        var entry = new Entry();
        var signature = buffer.readUInt32LE(0);
        if (signature !== 33639248) return emitErrorAndAutoClose(self, new Error("invalid central directory file header signature: 0x" + signature.toString(16)));
        entry.versionMadeBy = buffer.readUInt16LE(4);
        entry.versionNeededToExtract = buffer.readUInt16LE(6);
        entry.generalPurposeBitFlag = buffer.readUInt16LE(8);
        entry.compressionMethod = buffer.readUInt16LE(10);
        entry.lastModFileTime = buffer.readUInt16LE(12);
        entry.lastModFileDate = buffer.readUInt16LE(14);
        entry.crc32 = buffer.readUInt32LE(16);
        entry.compressedSize = buffer.readUInt32LE(20);
        entry.uncompressedSize = buffer.readUInt32LE(24);
        entry.fileNameLength = buffer.readUInt16LE(28);
        entry.extraFieldLength = buffer.readUInt16LE(30);
        entry.fileCommentLength = buffer.readUInt16LE(32);
        entry.internalFileAttributes = buffer.readUInt16LE(36);
        entry.externalFileAttributes = buffer.readUInt32LE(38);
        entry.relativeOffsetOfLocalHeader = buffer.readUInt32LE(42);
        if (entry.generalPurposeBitFlag & 64) return emitErrorAndAutoClose(self, new Error("strong encryption is not supported"));
        self.readEntryCursor += 46;
        buffer = newBuffer(entry.fileNameLength + entry.extraFieldLength + entry.fileCommentLength);
        readAndAssertNoEof(self.reader, buffer, 0, buffer.length, self.readEntryCursor, function(err2) {
          if (err2) return emitErrorAndAutoClose(self, err2);
          if (self.emittedError) return;
          entry.fileNameRaw = buffer.subarray(0, entry.fileNameLength);
          var fileCommentStart = entry.fileNameLength + entry.extraFieldLength;
          entry.extraFieldRaw = buffer.subarray(entry.fileNameLength, fileCommentStart);
          entry.fileCommentRaw = buffer.subarray(fileCommentStart, fileCommentStart + entry.fileCommentLength);
          try {
            entry.extraFields = parseExtraFields(entry.extraFieldRaw);
          } catch (err3) {
            return emitErrorAndAutoClose(self, err3);
          }
          if (self.decodeStrings) {
            var isUtf8 = (entry.generalPurposeBitFlag & 2048) !== 0;
            entry.fileComment = decodeBuffer(entry.fileCommentRaw, isUtf8);
            entry.fileName = getFileNameLowLevel(entry.generalPurposeBitFlag, entry.fileNameRaw, entry.extraFields, self.strictFileNames);
            var errorMessage = validateFileName(entry.fileName);
            if (errorMessage != null) return emitErrorAndAutoClose(self, new Error(errorMessage));
          } else {
            entry.fileComment = entry.fileCommentRaw;
            entry.fileName = entry.fileNameRaw;
          }
          entry.comment = entry.fileComment;
          self.readEntryCursor += buffer.length;
          self.entriesRead += 1;
          for (var i = 0; i < entry.extraFields.length; i++) {
            var extraField = entry.extraFields[i];
            if (extraField.id !== 1) continue;
            var zip64EiefBuffer = extraField.data;
            var index = 0;
            if (entry.uncompressedSize === 4294967295) {
              if (index + 8 > zip64EiefBuffer.length) {
                return emitErrorAndAutoClose(self, new Error("zip64 extended information extra field does not include uncompressed size"));
              }
              entry.uncompressedSize = readUInt64LE(zip64EiefBuffer, index);
              index += 8;
            }
            if (entry.compressedSize === 4294967295) {
              if (index + 8 > zip64EiefBuffer.length) {
                return emitErrorAndAutoClose(self, new Error("zip64 extended information extra field does not include compressed size"));
              }
              entry.compressedSize = readUInt64LE(zip64EiefBuffer, index);
              index += 8;
            }
            if (entry.relativeOffsetOfLocalHeader === 4294967295) {
              if (index + 8 > zip64EiefBuffer.length) {
                return emitErrorAndAutoClose(self, new Error("zip64 extended information extra field does not include relative header offset"));
              }
              entry.relativeOffsetOfLocalHeader = readUInt64LE(zip64EiefBuffer, index);
              index += 8;
            }
            break;
          }
          if (self.validateEntrySizes && entry.compressionMethod === 0) {
            var expectedCompressedSize = entry.uncompressedSize;
            if (entry.isEncrypted()) {
              expectedCompressedSize += 12;
            }
            if (entry.compressedSize !== expectedCompressedSize) {
              var msg = "compressed/uncompressed size mismatch for stored file: " + entry.compressedSize + " != " + entry.uncompressedSize;
              return emitErrorAndAutoClose(self, new Error(msg));
            }
          }
          self.emit("entry", entry);
          if (!self.lazyEntries) self._readEntry();
        });
      });
    };
    ZipFile.prototype.eachEntry = function() {
      const self = this;
      if (!self.lazyEntries) throw new Error("eachEntry() requires lazyEntries: true");
      if (self.hasEachEntryBeenCalled) throw new Error("eachEntry() must only be called once per ZipFile");
      self.hasEachEntryBeenCalled = true;
      let pendingResolveReject = null;
      self.on("entry", onEntry);
      self.on("end", onEnd);
      self.on("error", onError);
      function cleanup() {
        self.removeListener("entry", onEntry);
        self.removeListener("end", onEnd);
        self.removeListener("error", onError);
        if (self.autoClose) self.close();
      }
      function onEntry(entry) {
        let { resolve } = pendingResolveReject;
        pendingResolveReject = null;
        resolve({ value: entry });
      }
      function onEnd() {
        let { resolve } = pendingResolveReject;
        pendingResolveReject = null;
        cleanup();
        resolve({ done: true });
      }
      function onError(err) {
        let { reject } = pendingResolveReject;
        pendingResolveReject = null;
        cleanup();
        reject(err);
      }
      return {
        [Symbol.asyncIterator]() {
          return this;
        },
        next() {
          const promise = new Promise((resolve, reject) => {
            if (pendingResolveReject != null) throw new Error("next() called before previous Promise was resolved.");
            pendingResolveReject = { resolve, reject };
          });
          self.readEntry();
          return promise;
        },
        return(value) {
          cleanup();
          return Promise.resolve({ done: true, value });
        },
        throw(value) {
          cleanup();
          return Promise.reject(value);
        }
      };
    };
    ZipFile.prototype.openReadStream = function(entry, options2, callback) {
      var self = this;
      var relativeStart = 0;
      var relativeEnd = entry.compressedSize;
      if (callback == null) {
        callback = options2;
        options2 = null;
      }
      if (options2 == null) {
        options2 = {};
      } else {
        if (options2.decodeFileData === false) {
          if (options2.decrypt != null) {
            throw new Error("cannot use options.decrypt when options.decodeFileData === false");
          }
          if (options2.decompress != null) {
            throw new Error("cannot use options.decompress when options.decodeFileData === false");
          }
        } else {
          if (options2.decrypt != null) {
            if (!entry.isEncrypted()) {
              throw new Error("options.decrypt can only be specified for encrypted entries. See also option decodeFileData.");
            }
            if (options2.decrypt !== false) throw new Error("invalid options.decrypt value: " + options2.decrypt);
            if (entry.isCompressed()) {
              if (options2.decompress !== false) throw new Error("entry is encrypted and compressed, and options.decompress !== false. See also option decodeFileData.");
            }
          }
          if (options2.decompress != null) {
            if (!entry.isCompressed()) {
              throw new Error("options.decompress can only be specified for compressed entries. See also option decodeFileData.");
            }
            if (!(options2.decompress === false || options2.decompress === true)) {
              throw new Error("invalid options.decompress value: " + options2.decompress);
            }
            decompress = options2.decompress;
          }
        }
        if (options2.start != null) {
          relativeStart = options2.start;
          if (relativeStart < 0) throw new Error("options.start < 0");
          if (relativeStart > entry.compressedSize) throw new Error("options.start > entry.compressedSize");
        }
        if (options2.end != null) {
          relativeEnd = options2.end;
          if (relativeEnd < 0) throw new Error("options.end < 0");
          if (relativeEnd > entry.compressedSize) throw new Error("options.end > entry.compressedSize");
          if (relativeEnd < relativeStart) throw new Error("options.end < options.start");
        }
      }
      var rawMode = options2.decodeFileData === false || // Explicitly requested raw.
      (entry.compressionMethod === 0 || // Naturally without compression.
      entry.compressionMethod === 8 && options2.decompress === false) && (!entry.isEncrypted() || // Naturally without encryption.
      options2.decrypt === false);
      if (options2.start != null || options2.end != null) {
        if (!rawMode) throw new Error("start/end range require options.decodeFileData === false for non-trivial encoded entries.");
      }
      if (!self.isOpen) return callback(new Error("closed"));
      if (entry.isEncrypted() && !rawMode) {
        if (options2.decrypt !== false) return callback(new Error("entry is encrypted, and options.decodeFileData !== false"));
      }
      var decompress;
      if (rawMode) {
        decompress = false;
      } else if (entry.compressionMethod === 8) {
        decompress = options2.decodeFileData !== true;
      } else {
        return callback(new Error("unsupported compression method: " + entry.compressionMethod));
      }
      self.readLocalFileHeader(entry, { minimal: true }, function(err, localFileHeader) {
        if (err) return callback(err);
        self.openReadStreamLowLevel(
          localFileHeader.fileDataStart,
          entry.compressedSize,
          relativeStart,
          relativeEnd,
          decompress,
          entry.uncompressedSize,
          callback
        );
      });
    };
    ZipFile.prototype.openReadStreamLowLevel = function(fileDataStart, compressedSize, relativeStart, relativeEnd, decompress, uncompressedSize, callback) {
      var self = this;
      var fileDataEnd = fileDataStart + compressedSize;
      var readStream = self.reader.createReadStream({
        start: fileDataStart + relativeStart,
        end: fileDataStart + relativeEnd
      });
      var endpointStream = readStream;
      if (decompress) {
        var destroyed = false;
        var inflateFilter = zlib.createInflateRaw();
        readStream.on("error", function(err) {
          setImmediate(function() {
            if (!destroyed) inflateFilter.emit("error", err);
          });
        });
        readStream.pipe(inflateFilter);
        if (self.validateEntrySizes) {
          endpointStream = new AssertByteCountStream(uncompressedSize);
          inflateFilter.on("error", function(err) {
            setImmediate(function() {
              if (!destroyed) endpointStream.emit("error", err);
            });
          });
          inflateFilter.pipe(endpointStream);
        } else {
          endpointStream = inflateFilter;
        }
        installDestroyFn(endpointStream, function() {
          destroyed = true;
          if (inflateFilter !== endpointStream) inflateFilter.unpipe(endpointStream);
          readStream.unpipe(inflateFilter);
          readStream.destroy();
        });
      }
      callback(null, endpointStream);
    };
    ZipFile.prototype.readLocalFileHeader = function(entry, options2, callback) {
      var self = this;
      if (callback == null) {
        callback = options2;
        options2 = null;
      }
      if (options2 == null) options2 = {};
      self.reader.ref();
      var buffer = newBuffer(30);
      readAndAssertNoEof(self.reader, buffer, 0, buffer.length, entry.relativeOffsetOfLocalHeader, function(err) {
        try {
          if (err) return callback(err);
          var signature = buffer.readUInt32LE(0);
          if (signature !== 67324752) {
            return callback(new Error("invalid local file header signature: 0x" + signature.toString(16)));
          }
          var fileNameLength = buffer.readUInt16LE(26);
          var extraFieldLength = buffer.readUInt16LE(28);
          var fileDataStart = entry.relativeOffsetOfLocalHeader + 30 + fileNameLength + extraFieldLength;
          if (fileDataStart + entry.compressedSize > self.fileSize) {
            return callback(new Error("file data overflows file bounds: " + fileDataStart + " + " + entry.compressedSize + " > " + self.fileSize));
          }
          if (options2.minimal) {
            return callback(null, { fileDataStart });
          }
          var localFileHeader = new LocalFileHeader();
          localFileHeader.fileDataStart = fileDataStart;
          localFileHeader.versionNeededToExtract = buffer.readUInt16LE(4);
          localFileHeader.generalPurposeBitFlag = buffer.readUInt16LE(6);
          localFileHeader.compressionMethod = buffer.readUInt16LE(8);
          localFileHeader.lastModFileTime = buffer.readUInt16LE(10);
          localFileHeader.lastModFileDate = buffer.readUInt16LE(12);
          localFileHeader.crc32 = buffer.readUInt32LE(14);
          localFileHeader.compressedSize = buffer.readUInt32LE(18);
          localFileHeader.uncompressedSize = buffer.readUInt32LE(22);
          localFileHeader.fileNameLength = fileNameLength;
          localFileHeader.extraFieldLength = extraFieldLength;
          buffer = newBuffer(fileNameLength + extraFieldLength);
          self.reader.ref();
          readAndAssertNoEof(self.reader, buffer, 0, buffer.length, entry.relativeOffsetOfLocalHeader + 30, function(err2) {
            try {
              if (err2) return callback(err2);
              localFileHeader.fileName = buffer.subarray(0, fileNameLength);
              localFileHeader.extraField = buffer.subarray(fileNameLength);
              return callback(null, localFileHeader);
            } finally {
              self.reader.unref();
            }
          });
        } finally {
          self.reader.unref();
        }
      });
    };
    ZipFile.prototype.openReadStreamPromise = function(entry, options2) {
      return new Promise((resolve, reject) => {
        this.openReadStream(entry, options2, function(err, readStream) {
          if (err) return reject(err);
          resolve(readStream);
        });
      });
    };
    ZipFile.prototype.openReadStreamLowLevelPromise = function(fileDataStart, compressedSize, relativeStart, relativeEnd, decompress, uncompressedSize) {
      return new Promise((resolve, reject) => {
        this.openReadStream(fileDataStart, compressedSize, relativeStart, relativeEnd, decompress, uncompressedSize, function(err, readStream) {
          if (err) return reject(err);
          resolve(readStream);
        });
      });
    };
    ZipFile.prototype.readLocalFileHeaderPromise = function(entry, options2) {
      return new Promise((resolve, reject) => {
        this.readLocalFileHeader(entry, options2, function(err, localFileHeader) {
          if (err) return reject(err);
          resolve(localFileHeader);
        });
      });
    };
    function Entry() {
    }
    Entry.prototype.getLastModDate = function(options2) {
      if (options2 == null) options2 = {};
      if (!options2.forceDosFormat) {
        for (var i = 0; i < this.extraFields.length; i++) {
          var extraField = this.extraFields[i];
          if (extraField.id === 21589) {
            var data = extraField.data;
            if (data.length < 5) continue;
            var flags = data[0];
            var HAS_MTIME = 1;
            if (!(flags & HAS_MTIME)) continue;
            var posixTimestamp = data.readInt32LE(1);
            return new Date(posixTimestamp * 1e3);
          } else if (extraField.id === 10) {
            var data = extraField.data;
            if (data.length !== 32) continue;
            if (data.readUInt16LE(4) !== 1) continue;
            if (data.readUInt16LE(6) !== 24) continue;
            var hundredNanoSecondsSince1601 = data.readUInt32LE(8) + 4294967296 * data.readInt32LE(12);
            var millisecondsSince1970 = hundredNanoSecondsSince1601 / 1e4 - 116444736e5;
            return new Date(millisecondsSince1970);
          }
        }
      }
      return dosDateTimeToDate(this.lastModFileDate, this.lastModFileTime, options2.timezone);
    };
    Entry.prototype.canDecodeFileData = function() {
      return !this.isEncrypted() && (this.compressionMethod === 0 || this.compressionMethod === 8);
    };
    Entry.prototype.isEncrypted = function() {
      return (this.generalPurposeBitFlag & 1) !== 0;
    };
    Entry.prototype.isCompressed = function() {
      return this.compressionMethod === 8;
    };
    function LocalFileHeader() {
    }
    function dosDateTimeToDate(date, time, timezone) {
      var day = date & 31;
      var month = (date >> 5 & 15) - 1;
      var year = (date >> 9 & 127) + 1980;
      var millisecond = 0;
      var second = (time & 31) * 2;
      var minute = time >> 5 & 63;
      var hour = time >> 11 & 31;
      if (timezone == null || timezone === "local") {
        return new Date(year, month, day, hour, minute, second, millisecond);
      } else if (timezone === "UTC") {
        return new Date(Date.UTC(year, month, day, hour, minute, second, millisecond));
      } else {
        throw new Error("unrecognized options.timezone: " + options.timezone);
      }
    }
    function getFileNameLowLevel(generalPurposeBitFlag, fileNameBuffer, extraFields, strictFileNames) {
      var fileName = null;
      for (var i = 0; i < extraFields.length; i++) {
        var extraField = extraFields[i];
        if (extraField.id === 28789) {
          if (extraField.data.length < 6) {
            continue;
          }
          if (extraField.data.readUInt8(0) !== 1) {
            continue;
          }
          var oldNameCrc32 = extraField.data.readUInt32LE(1);
          if (crc32(fileNameBuffer) !== oldNameCrc32) {
            continue;
          }
          fileName = decodeBuffer(extraField.data.subarray(5), true);
          break;
        }
      }
      if (fileName == null) {
        var isUtf8 = (generalPurposeBitFlag & 2048) !== 0;
        fileName = decodeBuffer(fileNameBuffer, isUtf8);
      }
      if (!strictFileNames) {
        fileName = fileName.replace(/\\/g, "/");
      }
      return fileName;
    }
    function validateFileName(fileName) {
      if (fileName.indexOf("\\") !== -1) {
        return "invalid characters in fileName: " + fileName;
      }
      if (/^[a-zA-Z]:/.test(fileName) || /^\//.test(fileName)) {
        return "absolute path: " + fileName;
      }
      if (fileName.split("/").indexOf("..") !== -1) {
        return "invalid relative path: " + fileName;
      }
      return null;
    }
    function parseExtraFields(extraFieldBuffer) {
      var extraFields = [];
      var i = 0;
      while (i < extraFieldBuffer.length - 3) {
        var headerId = extraFieldBuffer.readUInt16LE(i + 0);
        var dataSize = extraFieldBuffer.readUInt16LE(i + 2);
        var dataStart = i + 4;
        var dataEnd = dataStart + dataSize;
        if (dataEnd > extraFieldBuffer.length) throw new Error("extra field length exceeds extra field buffer size");
        var dataBuffer = extraFieldBuffer.subarray(dataStart, dataEnd);
        extraFields.push({
          id: headerId,
          data: dataBuffer
        });
        i = dataEnd;
      }
      return extraFields;
    }
    function readAndAssertNoEof(reader, buffer, offset, length, position, callback) {
      if (length === 0) {
        return setImmediate(function() {
          callback(null, newBuffer(0));
        });
      }
      reader.read(buffer, offset, length, position, function(err, bytesRead) {
        if (err) return callback(err);
        if (bytesRead < length) {
          return callback(new Error("unexpected EOF"));
        }
        callback();
      });
    }
    util.inherits(AssertByteCountStream, Transform3);
    function AssertByteCountStream(byteCount) {
      Transform3.call(this);
      this.actualByteCount = 0;
      this.expectedByteCount = byteCount;
    }
    AssertByteCountStream.prototype._transform = function(chunk, encoding, cb) {
      this.actualByteCount += chunk.length;
      if (this.actualByteCount > this.expectedByteCount) {
        var msg = "too many bytes in the stream. expected " + this.expectedByteCount + ". got at least " + this.actualByteCount;
        return cb(new Error(msg));
      }
      cb(null, chunk);
    };
    AssertByteCountStream.prototype._flush = function(cb) {
      if (this.actualByteCount < this.expectedByteCount) {
        var msg = "not enough bytes in the stream. expected " + this.expectedByteCount + ". got only " + this.actualByteCount;
        return cb(new Error(msg));
      }
      cb();
    };
    util.inherits(RandomAccessReader, EventEmitter);
    function RandomAccessReader() {
      EventEmitter.call(this);
      this.refCount = 0;
    }
    RandomAccessReader.prototype.ref = function() {
      this.refCount += 1;
    };
    RandomAccessReader.prototype.unref = function() {
      var self = this;
      self.refCount -= 1;
      if (self.refCount > 0) return;
      if (self.refCount < 0) throw new Error("invalid unref");
      self.close(onCloseDone);
      function onCloseDone(err) {
        if (err) return self.emit("error", err);
        self.emit("close");
      }
    };
    RandomAccessReader.prototype.createReadStream = function(options2) {
      if (options2 == null) options2 = {};
      var start = options2.start;
      var end = options2.end;
      if (start === end) {
        var emptyStream = new PassThrough();
        setImmediate(function() {
          emptyStream.end();
        });
        return emptyStream;
      }
      var stream = this._readStreamForRange(start, end);
      var destroyed = false;
      var refUnrefFilter = new RefUnrefFilter(this);
      stream.on("error", function(err) {
        setImmediate(function() {
          if (!destroyed) refUnrefFilter.emit("error", err);
        });
      });
      installDestroyFn(refUnrefFilter, function() {
        stream.unpipe(refUnrefFilter);
        refUnrefFilter.unref();
        stream.destroy();
      });
      var byteCounter = new AssertByteCountStream(end - start);
      refUnrefFilter.on("error", function(err) {
        setImmediate(function() {
          if (!destroyed) byteCounter.emit("error", err);
        });
      });
      installDestroyFn(byteCounter, function() {
        destroyed = true;
        refUnrefFilter.unpipe(byteCounter);
        refUnrefFilter.destroy();
      });
      return stream.pipe(refUnrefFilter).pipe(byteCounter);
    };
    RandomAccessReader.prototype._readStreamForRange = function(start, end) {
      throw new Error("not implemented");
    };
    RandomAccessReader.prototype.read = function(buffer, offset, length, position, callback) {
      var readStream = this.createReadStream({ start: position, end: position + length });
      var writeStream = new Writable();
      var written = 0;
      writeStream._write = function(chunk, encoding, cb) {
        chunk.copy(buffer, offset + written, 0, chunk.length);
        written += chunk.length;
        cb();
      };
      writeStream.on("finish", callback);
      readStream.on("error", function(error) {
        callback(error);
      });
      readStream.pipe(writeStream);
    };
    RandomAccessReader.prototype.close = function(callback) {
      setImmediate(callback);
    };
    util.inherits(RefUnrefFilter, PassThrough);
    function RefUnrefFilter(context) {
      PassThrough.call(this);
      this.context = context;
      this.context.ref();
      this.unreffedYet = false;
    }
    RefUnrefFilter.prototype._flush = function(cb) {
      this.unref();
      cb();
    };
    RefUnrefFilter.prototype.unref = function(cb) {
      if (this.unreffedYet) return;
      this.unreffedYet = true;
      this.context.unref();
    };
    var cp437 = "\0\u263A\u263B\u2665\u2666\u2663\u2660\u2022\u25D8\u25CB\u25D9\u2642\u2640\u266A\u266B\u263C\u25BA\u25C4\u2195\u203C\xB6\xA7\u25AC\u21A8\u2191\u2193\u2192\u2190\u221F\u2194\u25B2\u25BC !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u2302\xC7\xFC\xE9\xE2\xE4\xE0\xE5\xE7\xEA\xEB\xE8\xEF\xEE\xEC\xC4\xC5\xC9\xE6\xC6\xF4\xF6\xF2\xFB\xF9\xFF\xD6\xDC\xA2\xA3\xA5\u20A7\u0192\xE1\xED\xF3\xFA\xF1\xD1\xAA\xBA\xBF\u2310\xAC\xBD\xBC\xA1\xAB\xBB\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255D\u255C\u255B\u2510\u2514\u2534\u252C\u251C\u2500\u253C\u255E\u255F\u255A\u2554\u2569\u2566\u2560\u2550\u256C\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256B\u256A\u2518\u250C\u2588\u2584\u258C\u2590\u2580\u03B1\xDF\u0393\u03C0\u03A3\u03C3\xB5\u03C4\u03A6\u0398\u03A9\u03B4\u221E\u03C6\u03B5\u2229\u2261\xB1\u2265\u2264\u2320\u2321\xF7\u2248\xB0\u2219\xB7\u221A\u207F\xB2\u25A0\xA0";
    function decodeBuffer(buffer, isUtf8) {
      if (isUtf8) {
        return buffer.toString("utf8");
      } else {
        var result = "";
        for (var i = 0; i < buffer.length; i++) {
          result += cp437[buffer[i]];
        }
        return result;
      }
    }
    function readUInt64LE(buffer, offset) {
      var lower32 = buffer.readUInt32LE(offset);
      var upper32 = buffer.readUInt32LE(offset + 4);
      return upper32 * 4294967296 + lower32;
    }
    var newBuffer;
    if (typeof Buffer.allocUnsafe === "function") {
      newBuffer = function(len) {
        return Buffer.allocUnsafe(len);
      };
    } else {
      newBuffer = function(len) {
        return new Buffer(len);
      };
    }
    function installDestroyFn(stream, fn) {
      if (typeof stream.destroy === "function") {
        stream._destroy = function(err, cb) {
          fn();
          if (cb != null) cb(err);
        };
      } else {
        stream.destroy = fn;
      }
    }
    function defaultCallback(err) {
      if (err) throw err;
    }
  }
});

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => IELTSPlugin
});
module.exports = __toCommonJS(main_exports);

// src/user-error.ts
var UserError = class extends Error {
};
function userMessage(error) {
  return error instanceof UserError ? error.message : "\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u8DEF\u5F84\u3001\u7F51\u7EDC\u4E0E\u914D\u7F6E\u540E\u91CD\u8BD5";
}

// src/main.ts
var import_obsidian5 = require("obsidian");
var import_node_path9 = __toESM(require("node:path"));

// src/ui/host-reload.ts
var import_node_fs = require("node:fs");
var import_node_path = __toESM(require("node:path"));
async function reloadAndVerify(manager, id, dir) {
  const expected = JSON.parse(
    await import_node_fs.promises.readFile(import_node_path.default.join(dir, "manifest.json"), "utf8")
  );
  if (expected.id !== id || typeof expected.version !== "string")
    throw new UserError("\u5F85\u52A0\u8F7D\u63D2\u4EF6\u8EAB\u4EFD\u65E0\u6548");
  const runtime = {
    ...manager.manifests[id],
    ...manager.plugins[id]?.manifest
  };
  if (typeof runtime.dir !== "string" || !runtime.dir)
    throw new UserError("\u65E0\u6CD5\u5B9A\u4F4D\u5F53\u524D\u63D2\u4EF6\u76EE\u5F55\uFF0C\u5DF2\u53D6\u6D88\u81EA\u52A8\u91CD\u8F7D");
  const next = { ...runtime, ...expected, dir: runtime.dir };
  await manager.disablePlugin(id);
  manager.manifests[id] = next;
  const enabled = await manager.enablePlugin(id);
  const loaded = manager.plugins[id];
  if (enabled === false || !loaded || loaded._loaded === false || loaded.manifest.version !== expected.version || loaded.manifest.dir !== runtime.dir)
    throw new UserError("Obsidian \u672A\u52A0\u8F7D\u76EE\u6807\u63D2\u4EF6\u7248\u672C");
}

// src/config/machine-config.ts
var import_node_fs2 = require("node:fs");
var import_node_path2 = __toESM(require("node:path"));
var import_node_os = __toESM(require("node:os"));
var import_node_crypto = require("node:crypto");
function assertIsolatedPath(file) {
  if (process.env.IELTS_HELPER_ISOLATED !== "1") return;
  const allowed = process.env.IELTS_HELPER_TEST_ROOT || process.env.IELTS_HELPER_CONFIG_ROOT && import_node_path2.default.dirname(process.env.IELTS_HELPER_CONFIG_ROOT);
  if (!allowed || !contains(allowed, file))
    throw new UserError("\u9694\u79BB\u6A21\u5F0F\u53EA\u5141\u8BB8\u8BBF\u95EE\u6307\u5B9A\u6D4B\u8BD5\u76EE\u5F55");
}
function contains(parent, child) {
  const rel = import_node_path2.default.relative(import_node_path2.default.resolve(parent), import_node_path2.default.resolve(child));
  return rel === "" || !rel.startsWith(".." + import_node_path2.default.sep) && rel !== ".." && !import_node_path2.default.isAbsolute(rel);
}
function configRoot() {
  if (process.env.IELTS_HELPER_ISOLATED === "1" && !process.env.IELTS_HELPER_CONFIG_ROOT)
    throw new UserError("\u9694\u79BB\u6A21\u5F0F\u5FC5\u987B\u663E\u5F0F\u8BBE\u7F6E IELTS_HELPER_CONFIG_ROOT");
  return process.env.IELTS_HELPER_CONFIG_ROOT || (process.platform === "win32" ? import_node_path2.default.join(
    process.env.LOCALAPPDATA || import_node_path2.default.join(import_node_os.default.homedir(), "AppData/Local"),
    "ielts-helper"
  ) : process.platform === "darwin" ? import_node_path2.default.join(import_node_os.default.homedir(), "Library/Application Support/ielts-helper") : import_node_path2.default.join(
    process.env.XDG_CONFIG_HOME || import_node_path2.default.join(import_node_os.default.homedir(), ".config"),
    "ielts-helper"
  ));
}
function vaultKey(root) {
  const normalized2 = import_node_path2.default.resolve(root).replace(/\\/g, "/").replace(/\/$/, "");
  return (0, import_node_crypto.createHash)("sha256").update(
    process.platform === "win32" ? normalized2.toLowerCase() : normalized2
  ).digest("hex").slice(0, 16);
}
function validateProfile(p3) {
  const labels = {
    vaultRoot: "\u7B14\u8BB0\u5E93",
    studyRoot: "\u5B66\u4E60\u76EE\u5F55",
    appRoot: "\u5916\u90E8\u7A0B\u5E8F\u76EE\u5F55",
    dataDir: "\u5916\u90E8\u6570\u636E\u76EE\u5F55"
  };
  for (const key of ["vaultRoot", "studyRoot", "appRoot", "dataDir"]) {
    assertIsolatedPath(p3[key]);
    if (!import_node_path2.default.isAbsolute(p3[key]))
      throw new UserError(labels[key] + "\u5FC5\u987B\u4E3A\u7EDD\u5BF9\u8DEF\u5F84");
  }
  if (!contains(p3.vaultRoot, p3.studyRoot))
    throw new UserError("\u5B66\u4E60\u76EE\u5F55\u5FC5\u987B\u4F4D\u4E8E\u5F53\u524D Vault \u5185");
  if (contains(p3.vaultRoot, p3.appRoot) || contains(p3.vaultRoot, p3.dataDir))
    throw new UserError("\u7A0B\u5E8F\u548C\u6570\u636E\u76EE\u5F55\u5FC5\u987B\u4F4D\u4E8E Vault \u5916");
  if (contains(p3.appRoot, p3.dataDir) || contains(p3.dataDir, p3.appRoot))
    throw new UserError("\u7A0B\u5E8F\u548C\u6570\u636E\u76EE\u5F55\u4E0D\u80FD\u4E92\u76F8\u5305\u542B");
  if (!Number.isInteger(p3.port) || p3.port < 1024 || p3.port > 65535)
    throw new UserError("\u7AEF\u53E3\u5FC5\u987B\u4E3A 1024\u201365535");
  if (!p3.pythonPath.trim())
    throw new UserError("\u8BF7\u586B\u5199\u6216\u81EA\u52A8\u68C0\u6D4B Python \u89E3\u91CA\u5668");
}
async function canonical(file) {
  try {
    return await import_node_fs2.promises.realpath(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
    return import_node_path2.default.join(await canonical(import_node_path2.default.dirname(file)), import_node_path2.default.basename(file));
  }
}
var MachineConfig = class {
  constructor(vaultRoot, root = configRoot()) {
    this.vaultRoot = vaultRoot;
    this.root = root;
    if (contains(vaultRoot, root))
      throw new UserError("\u672C\u673A\u914D\u7F6E\u4E0D\u80FD\u5B58\u5165 Vault");
    assertIsolatedPath(root);
    this.file = import_node_path2.default.join(root, "config.json");
  }
  file;
  async read() {
    try {
      if (contains(await canonical(this.vaultRoot), await canonical(this.root)))
        throw new UserError("\u672C\u673A\u914D\u7F6E\u76EE\u5F55\u4E0D\u80FD\u7ECF\u7B26\u53F7\u94FE\u63A5\u8FDB\u5165 Vault");
      try {
        const stat4 = await import_node_fs2.promises.lstat(this.file);
        if (!stat4.isFile() || stat4.nlink > 1)
          throw new UserError("\u672C\u673A\u914D\u7F6E\u4E0D\u662F\u72EC\u7ACB\u666E\u901A\u6587\u4EF6");
      } catch (e) {
        if (e.code !== "ENOENT") throw e;
      }
      const value = JSON.parse(await import_node_fs2.promises.readFile(this.file, "utf8"));
      if (value.schema !== 1 || !value.vaults)
        throw new UserError("\u4E0D\u652F\u6301\u7684\u672C\u673A\u914D\u7F6E");
      return value;
    } catch (e) {
      if (e.code === "ENOENT")
        return { schema: 1, vaults: {} };
      throw e;
    }
  }
  async load() {
    const p3 = (await this.read()).vaults[vaultKey(this.vaultRoot)];
    if (p3) {
      validateProfile(p3);
      if (vaultKey(p3.vaultRoot) !== vaultKey(this.vaultRoot))
        throw new UserError("Vault \u6620\u5C04\u4E0D\u4E00\u81F4");
    }
    return p3;
  }
  async save(profile) {
    validateProfile(profile);
    if (import_node_path2.default.resolve(profile.vaultRoot) !== import_node_path2.default.resolve(this.vaultRoot))
      throw new UserError("Vault \u6620\u5C04\u4E0D\u4E00\u81F4");
    const data = await this.read();
    data.vaults[vaultKey(this.vaultRoot)] = profile;
    await import_node_fs2.promises.mkdir(this.root, { recursive: true, mode: 448 });
    const temp = this.file + "." + (0, import_node_crypto.randomUUID)() + ".tmp";
    try {
      await import_node_fs2.promises.writeFile(temp, JSON.stringify(data, null, 2), {
        mode: 384,
        flag: "wx"
      });
      await import_node_fs2.promises.chmod(temp, 384);
      await import_node_fs2.promises.rename(temp, this.file);
    } finally {
      await import_node_fs2.promises.rm(temp, { force: true });
    }
  }
};
async function importLegacy(file, base) {
  assertIsolatedPath(file);
  const old = JSON.parse(
    (await import_node_fs2.promises.readFile(file, "utf8")).replace(/^\uFEFF/, "")
  );
  if (typeof old.vaultRoot === "string" && vaultKey(old.vaultRoot) !== vaultKey(base.vaultRoot))
    throw new UserError(
      "\u8BE5\u914D\u7F6E\u5C5E\u4E8E\u5176\u4ED6 Vault\uFF08\u7B14\u8BB0\u5E93\uFF09\uFF0C\u8BF7\u9009\u62E9\u5F53\u524D\u7B14\u8BB0\u5E93\u7684\u65E7\u914D\u7F6E\u6587\u4EF6"
    );
  const p3 = {
    ...base,
    appRoot: typeof old.appRoot === "string" && old.appRoot.trim() ? old.appRoot : import_node_path2.default.dirname(import_node_path2.default.resolve(file)),
    updateSource: { ...base.updateSource }
  };
  for (const key of ["dataDir", "studyRoot", "pythonPath"])
    if (typeof old[key] === "string") p3[key] = old[key];
  if (old.releaseProvider === "github" || old.releaseProvider === "gitee") {
    p3.updateSource.mode = old.releaseProvider;
    if (typeof old.repository === "string")
      p3.updateSource[old.releaseProvider === "github" ? "githubRepo" : "giteeRepo"] = old.repository;
  }
  if (typeof old.port === "number") p3.port = old.port;
  validateProfile(p3);
  return p3;
}

// src/config/python-detect.ts
var import_node_child_process = require("node:child_process");
var import_node_fs3 = require("node:fs");
var import_node_path3 = __toESM(require("node:path"));
var import_node_os2 = __toESM(require("node:os"));
async function collectDirPythons(root, subpath) {
  const out = [];
  try {
    for (const entry of await import_node_fs3.promises.readdir(root))
      out.push(import_node_path3.default.join(root, entry, ...subpath));
  } catch {
  }
  return out;
}
async function detectPython(candidates) {
  let list = candidates;
  if (!list) {
    list = ["python", "python3", "py"];
    if (process.platform === "win32") {
      const localAppData = process.env.LOCALAPPDATA || import_node_path3.default.join(import_node_os2.default.homedir(), "AppData/Local");
      list.push(
        ...await collectDirPythons(
          import_node_path3.default.join(localAppData, "mise/installs/python"),
          ["python.exe"]
        ),
        ...await collectDirPythons(
          import_node_path3.default.join(localAppData, "Programs/Python"),
          ["python.exe"]
        ),
        ...await collectDirPythons(
          import_node_path3.default.join(import_node_os2.default.homedir(), ".pyenv/pyenv-win/versions"),
          ["python.exe"]
        ),
        import_node_path3.default.join(import_node_os2.default.homedir(), "miniconda3/python.exe"),
        import_node_path3.default.join(import_node_os2.default.homedir(), "anaconda3/python.exe")
      );
      try {
        for (const entry of await import_node_fs3.promises.readdir("C:\\"))
          if (/^Python3\d+$/i.test(entry))
            list.push(import_node_path3.default.join("C:\\", entry, "python.exe"));
      } catch {
      }
    } else {
      list.push(
        "/opt/homebrew/bin/python3",
        "/usr/local/bin/python3",
        ...await collectDirPythons(
          import_node_path3.default.join(import_node_os2.default.homedir(), ".local/share/mise/installs/python"),
          ["bin", "python3"]
        ),
        import_node_path3.default.join(import_node_os2.default.homedir(), ".pyenv/shims/python3"),
        "/usr/bin/python3"
      );
    }
  }
  const probe = 'import os,sys,json; base=getattr(sys,"_base_executable","") or ""; exe=base if base and os.path.isfile(base) else sys.executable; print(json.dumps({"path":exe,"version":list(sys.version_info[:3])}))';
  for (const command of [...new Set(list)]) {
    if (/Microsoft[/\\]WindowsApps/i.test(command)) continue;
    if (process.platform === "win32" && /^python3?$/.test(command)) {
      let alias = false;
      for (const rawDir of (process.env.PATH || "").split(import_node_path3.default.delimiter)) {
        const dir = rawDir.trim().replace(/^"(.*)"$/, "$1");
        if (!dir) continue;
        try {
          await import_node_fs3.promises.access(import_node_path3.default.join(dir, command + ".exe"));
          alias = /Microsoft[/\\]WindowsApps/i.test(dir);
          break;
        } catch {
        }
      }
      if (alias) continue;
    }
    const result = await new Promise(
      (resolve) => (0, import_node_child_process.execFile)(
        command,
        [...command === "py" ? ["-3"] : [], "-c", probe],
        { windowsHide: true, timeout: 5e3 },
        (err, out) => resolve(err ? void 0 : out)
      )
    );
    if (result)
      try {
        const value = JSON.parse(result);
        const [major, minor] = value.version;
        if (major === 3 && minor >= 8 && typeof value.path === "string" && !/Microsoft[/\\]WindowsApps/i.test(value.path))
          return { path: value.path, version: value.version.join(".") };
      } catch {
      }
  }
  throw new UserError("\u672A\u627E\u5230 Python 3.8+\uFF0C\u8BF7\u6307\u5B9A\u89E3\u91CA\u5668\u5B8C\u6574\u8DEF\u5F84");
}

// src/config/study-layout.ts
var import_node_fs5 = require("node:fs");
var import_node_path5 = __toESM(require("node:path"));

// src/launcher/service-manager.ts
var import_node_child_process2 = require("node:child_process");
var import_node_crypto2 = require("node:crypto");
var import_node_fs4 = require("node:fs");
var import_node_path4 = __toESM(require("node:path"));
var import_node_net = require("node:net");
var import_node_http = require("node:http");
var wait = (ms) => new Promise((r) => setTimeout(r, ms));
function log(event) {
  console.info(`[IELTS Helper ${(/* @__PURE__ */ new Date()).toISOString()}] ${event}`);
}
async function localApi(port, route, body) {
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new UserError("\u672C\u5730\u63A5\u53E3\u7AEF\u53E3\u65E0\u6548");
  if (!/^\/(?!\/)/.test(route) || /[\\\r\n\x00#]/.test(route))
    throw new UserError("\u672C\u5730\u63A5\u53E3\u8DEF\u5F84\u65E0\u6548");
  const payload = body === void 0 ? void 0 : JSON.stringify(body);
  return new Promise((resolve, reject) => {
    let settled = false;
    const fail = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(deadline);
      req.destroy();
      reject(error);
    };
    const req = (0, import_node_http.request)(
      {
        hostname: "127.0.0.1",
        port,
        path: route,
        method: payload === void 0 ? "GET" : "POST",
        headers: payload === void 0 ? {} : {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(payload)
        }
      },
      (response) => {
        response.once("error", () => fail(new UserError("\u672C\u5730\u63A5\u53E3\u54CD\u5E94\u8BFB\u53D6\u5931\u8D25")));
        response.once("aborted", () => fail(new UserError("\u672C\u5730\u63A5\u53E3\u54CD\u5E94\u4E2D\u65AD")));
        if (!response.statusCode || response.statusCode < 200 || response.statusCode >= 300) {
          fail(new UserError("\u672C\u5730\u63A5\u53E3\u54CD\u5E94 " + response.statusCode));
          return;
        }
        let text2 = "";
        response.setEncoding("utf8");
        response.on("data", (chunk) => {
          text2 += chunk;
        });
        response.once("end", () => {
          if (settled) return;
          let value;
          try {
            value = JSON.parse(text2);
          } catch {
            fail(new UserError("\u672C\u5730\u63A5\u53E3\u8FD4\u56DE\u65E0\u6548 JSON"));
            return;
          }
          settled = true;
          clearTimeout(deadline);
          resolve(value);
        });
      }
    );
    const deadline = setTimeout(() => fail(new UserError("\u672C\u5730\u63A5\u53E3\u8BF7\u6C42\u8D85\u65F6")), 3e3);
    req.once("error", () => fail(new UserError("\u65E0\u6CD5\u8FDE\u63A5\u672C\u5730\u5B66\u4E60\u670D\u52A1")));
    req.end(payload);
  });
}
async function portFree(port) {
  return new Promise((resolve) => {
    const socket = (0, import_node_net.connect)({ host: "127.0.0.1", port });
    let done = false;
    const finish = (free) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(free);
    };
    socket.once("connect", () => finish(false));
    socket.once(
      "error",
      (e) => finish(e.code === "ECONNREFUSED")
    );
    socket.setTimeout(1500, () => finish(false));
  });
}
function extractErrorClass(stderrTail) {
  const matches = stderrTail.match(/\b[A-Z][A-Za-z]+(?:Error|Exception)\b/g);
  return matches?.at(-1) ?? "";
}
var ServiceStartError = class extends UserError {
  constructor(message, reason, errorClass, missingBaseDb = false) {
    super(message);
    this.reason = reason;
    this.errorClass = errorClass;
    this.missingBaseDb = missingBaseDb;
  }
};
var ServiceManager = class {
  constructor(config, pluginVersion) {
    this.config = config;
    this.pluginVersion = pluginVersion;
  }
  child;
  instance;
  ownedPid;
  starting;
  replacing = false;
  closed = false;
  /** 健康接口暂未应答时仍确认是否持有存活或启动中的自有子进程。 */
  hasOwnedProcess() {
    return Boolean(this.starting || this.child && this.child.exitCode === null);
  }
  /** 保存配置写入磁盘前同步锁定当前管理器，避免写入期间并发启动又被 dispose 关闭。 */
  beginReplace() {
    if (this.hasOwnedProcess())
      throw new UserError("\u4FEE\u6539\u914D\u7F6E\u524D\u8BF7\u5148\u505C\u6B62\u5F53\u524D\u5B66\u4E60\u670D\u52A1");
    this.replacing = true;
  }
  endReplace() {
    this.replacing = false;
  }
  async version() {
    try {
      const v = await localApi(
        this.config.port,
        "/api/version"
      );
      return typeof v?.version === "string" && /^\d+\.\d+\.\d+$/.test(v.version) ? v : void 0;
    } catch {
      return void 0;
    }
  }
  async state() {
    const v = await this.version();
    if (!v) {
      if (this.child && this.child.exitCode === null) return "external";
      return await portFree(this.config.port) ? "stopped" : "external";
    }
    const id = v.serviceIdentity;
    if (!this.child || this.child.exitCode !== null || !this.instance || id?.instanceId !== this.instance || typeof id?.pid !== "number" || id.pid <= 0)
      return "external";
    if (id.pid === this.child.pid) {
      this.ownedPid = id.pid;
      return "owned";
    }
    if (this.ownedPid === id.pid) return "owned";
    if (this.starting && this.ownedPid === void 0) {
      this.ownedPid = id.pid;
      return "owned";
    }
    return "external";
  }
  async start() {
    if (this.closed) throw new UserError("\u63D2\u4EF6\u5DF2\u5378\u8F7D");
    if (this.replacing) throw new UserError("\u6B63\u5728\u4FDD\u5B58\u914D\u7F6E\uFF0C\u8BF7\u7A0D\u5019\u91CD\u8BD5");
    if (this.starting) return this.starting;
    this.starting = this.startReady();
    try {
      await this.starting;
    } finally {
      this.starting = void 0;
    }
  }
  async startReady() {
    if (await this.version()) return;
    if (!await portFree(this.config.port))
      throw new ServiceStartError(
        "\u7AEF\u53E3\u5DF2\u88AB\u5916\u90E8\u670D\u52A1\u5360\u7528\u6216\u65E0\u6CD5\u786E\u8BA4\u7A7A\u95F2\uFF0C\u8BF7\u624B\u52A8\u5904\u7406",
        "port"
      );
    const c = this.config;
    let current;
    try {
      current = JSON.parse(
        await import_node_fs4.promises.readFile(import_node_path4.default.join(c.appRoot, "current.json"), "utf8")
      );
    } catch (e) {
      if (e.code === "ENOENT")
        throw new UserError("\u5C1A\u672A\u5B89\u88C5 Helper \u7A0B\u5E8F\uFF0C\u8BF7\u5148\u521D\u59CB\u5316\u5B89\u88C5\u6216\u5BFC\u5165\u7A0B\u5E8F\u5305");
      throw new UserError("\u7A0B\u5E8F\u7248\u672C\u6307\u9488\u65E0\u6CD5\u8BFB\u53D6");
    }
    if (!current.version || !/^\d+\.\d+\.\d+$/.test(current.version))
      throw new UserError("\u5C1A\u672A\u5B89\u88C5 Helper \u7A0B\u5E8F\u6216\u7248\u672C\u6307\u9488\u65E0\u6548");
    const cwd = import_node_path4.default.join(c.appRoot, "releases", current.version, "terminal");
    try {
      await import_node_fs4.promises.access(import_node_path4.default.join(cwd, "IELTS_Vocab_Helper.py"));
    } catch {
      throw new UserError("\u7A0B\u5E8F\u76EE\u5F55\u7F3A\u5C11 IELTS_Vocab_Helper.py\uFF0C\u8BF7\u91CD\u65B0\u5B89\u88C5 Helper \u7A0B\u5E8F");
    }
    this.instance = (0, import_node_crypto2.randomUUID)();
    this.ownedPid = void 0;
    const child = (0, import_node_child_process2.spawn)(
      c.pythonPath,
      [
        "-X",
        "utf8",
        "IELTS_Vocab_Helper.py",
        "--port",
        String(c.port),
        "--plugin-instance",
        this.instance,
        "serve"
      ],
      {
        cwd,
        windowsHide: true,
        stdio: ["pipe", "ignore", "pipe"],
        env: {
          ...process.env,
          IELTS_DATA_DIR: c.dataDir,
          IELTS_VAULT: c.studyRoot,
          IELTS_DETACHED: "1",
          IELTS_PLUGIN_VERSION: this.pluginVersion,
          PYTHONPYCACHEPREFIX: import_node_path4.default.join(c.appRoot, "runtime/pycache"),
          IELTS_DEV_CONFIG: import_node_path4.default.join(c.appRoot, "dev-auth.json")
        }
      }
    );
    this.child = child;
    let spawnCode;
    let stderrTail = "";
    child.on("error", (err) => {
      spawnCode = err.code || "ERROR";
    });
    child.stdin?.on("error", () => {
    });
    child.stderr?.on("data", (chunk) => {
      stderrTail = (stderrTail + chunk.toString("utf8")).slice(-4096);
    });
    child.on("exit", () => {
      if (this.child === child) {
        this.child = void 0;
        this.ownedPid = void 0;
      }
    });
    log("\u8BF7\u6C42\u542F\u52A8\u5B66\u4E60\u670D\u52A1");
    for (let i = 0; i < 100; i++) {
      if (this.closed || spawnCode || child.exitCode !== null) break;
      if (await this.state() === "owned") {
        log("\u5B66\u4E60\u670D\u52A1\u5065\u5EB7\u68C0\u67E5\u5C31\u7EEA");
        return;
      }
      await wait(200);
    }
    child.stdin?.end();
    if (spawnCode) {
      log(`\u5B66\u4E60\u670D\u52A1\u62C9\u8D77\u5931\u8D25\uFF08${spawnCode}\uFF09`);
      throw new ServiceStartError(
        "\u65E0\u6CD5\u542F\u52A8 Python \u89E3\u91CA\u5668\uFF0C\u8BF7\u68C0\u67E5 Python \u8DEF\u5F84\u662F\u5426\u5B58\u5728\u4E14\u53EF\u6267\u884C",
        "spawn",
        spawnCode
      );
    }
    if (child.exitCode !== null) {
      const exc = extractErrorClass(stderrTail);
      const missingBaseDb = exc === "FileNotFoundError" && /FileNotFoundError:\s*(?:base|active) database not found:/i.test(stderrTail);
      log(`\u5B66\u4E60\u670D\u52A1\u5F02\u5E38\u9000\u51FA\uFF08code=${child.exitCode}${exc ? `, ${exc}` : ""}\uFF09`);
      throw new ServiceStartError(
        `\u672C\u5730\u5B66\u4E60\u670D\u52A1\u542F\u52A8\u5931\u8D25\uFF08\u9000\u51FA\u7801 ${child.exitCode}${exc ? `\uFF0C${exc}` : ""}\uFF09\uFF0C\u8BF7\u68C0\u67E5\u6570\u636E\u76EE\u5F55\u6570\u636E\u5E93\u3001\u5B66\u4E60\u76EE\u5F55\u4E0E Python \u8DEF\u5F84`,
        "exit",
        exc || void 0,
        missingBaseDb
      );
    }
    log("\u5B66\u4E60\u670D\u52A1\u542F\u52A8\u8D85\u65F6");
    throw new ServiceStartError(
      "\u672C\u5730\u5B66\u4E60\u670D\u52A1\u542F\u52A8\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5 Python \u8DEF\u5F84\u3001\u7AEF\u53E3\u5360\u7528\u4E0E\u7A0B\u5E8F\u76EE\u5F55",
      "timeout"
    );
  }
  async stop() {
    const state = await this.state();
    if (state === "stopped") return;
    if (state !== "owned")
      throw new UserError("\u68C0\u6D4B\u5230\u5916\u90E8\u6216\u5F52\u5C5E\u672A\u77E5\u670D\u52A1\uFF0C\u8BF7\u5148\u624B\u52A8\u505C\u6B62");
    const child = this.child;
    child.stdin?.end();
    for (let i = 0; i < 50; i++) {
      if (child.exitCode !== null || child.signalCode !== null) {
        if (await this.version()) throw new UserError("\u7AEF\u53E3\u4ECD\u6709\u670D\u52A1\u8FD0\u884C");
        log("\u5B66\u4E60\u670D\u52A1\u5DF2\u505C\u6B62");
        return;
      }
      await wait(100);
    }
    throw new UserError("\u670D\u52A1\u5C1A\u672A\u9000\u51FA\uFF0C\u5DF2\u4FDD\u7559\u8FDB\u7A0B\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
  }
  dispose() {
    this.closed = true;
    this.ownedPid = void 0;
    this.child?.stdin?.end();
  }
};

// src/config/study-layout.ts
async function target(file) {
  try {
    return await import_node_fs5.promises.realpath(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
    return import_node_path5.default.join(await target(import_node_path5.default.dirname(file)), import_node_path5.default.basename(file));
  }
}
async function ensureStudyLayout(profile) {
  validateProfile(profile);
  const vault = await target(profile.vaultRoot), study = await target(profile.studyRoot);
  if (!contains(vault, study))
    throw new UserError("\u5B66\u4E60\u76EE\u5F55\u4E0D\u80FD\u7ECF\u7B26\u53F7\u94FE\u63A5\u79BB\u5F00\u5F53\u524D Vault");
  await import_node_fs5.promises.mkdir(profile.studyRoot, { recursive: true });
  for (const name of ["02-Areas", "2.Areas", ".obsidian"]) {
    const file = import_node_path5.default.join(profile.studyRoot, name);
    try {
      const stat4 = await import_node_fs5.promises.stat(file);
      if (!stat4.isDirectory()) throw new UserError("\u5B66\u4E60\u5E03\u5C40\u6807\u8BC6\u4E0D\u662F\u76EE\u5F55\uFF1A" + name);
      if (!contains(study, await import_node_fs5.promises.realpath(file)))
        throw new UserError("\u5B66\u4E60\u5E03\u5C40\u76EE\u5F55\u4E0D\u80FD\u6307\u5411 Vault \u5916");
      return;
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
  }
  await import_node_fs5.promises.mkdir(import_node_path5.default.join(profile.studyRoot, "02-Areas"));
  log("\u9996\u6B21\u521D\u59CB\u5316\u5DF2\u5EFA\u7ACB\u6700\u5C0F\u5B66\u4E60\u76EE\u5F55");
}

// src/launcher/service-context.ts
var import_node_path6 = __toESM(require("node:path"));
function normalized(file) {
  const isWindows = /^[a-z]:[/\\]/i.test(file);
  const value = (isWindows ? import_node_path6.default.win32.resolve(file) : import_node_path6.default.resolve(file)).replace(/\\/g, "/").replace(/\/$/, "");
  return isWindows ? value.toLowerCase() : value;
}
function assertServiceContext(profile, version) {
  const id = version?.serviceIdentity;
  if (!id?.dataRoot || !id.vaultRoot)
    throw new UserError("\u65E0\u6CD5\u786E\u8BA4\u670D\u52A1\u4F7F\u7528\u7684\u5B66\u4E60\u76EE\u5F55\uFF0C\u4E0D\u80FD\u5206\u914D\u5F85\u5904\u7406\u8BCD\uFF1B\u5B66\u4E60\u9875\u4ECD\u53EF\u6253\u5F00");
  if (normalized(id.dataRoot) !== normalized(profile.dataDir) || normalized(id.vaultRoot) !== normalized(profile.studyRoot))
    throw new UserError("\u5F53\u524D\u7AEF\u53E3\u670D\u52A1\u5C5E\u4E8E\u5176\u4ED6\u6570\u636E\u76EE\u5F55\u6216 Vault\uFF0C\u8BF7\u624B\u52A8\u5904\u7406\u540E\u91CD\u8BD5");
}

// src/features/dashboard-view.ts
var import_obsidian = require("obsidian");

// src/features/review-scanner.ts
function studyRelative(file, prefix) {
  if (prefix === void 0 || prefix === "0-IELTS")
    return file.replace(/^0-IELTS\//, "");
  return !prefix ? file : file.startsWith(prefix + "/") ? file.slice(prefix.length + 1) : "";
}
var reviewPath = (file, prefix) => {
  const p3 = studyRelative(file, prefix);
  return /^(?:01-Projects|1\.Projects)\/IELTS-Review\//.test(p3) || /^(?:02-Areas|2\.Areas)\/(?:Reading|Listening)\//.test(p3);
};
var buckets = {
  notfound: "\u5B9A\u4F4D\u5931\u8BEF",
  time: "\u5B9A\u4F4D\u5931\u8BEF",
  missed: "\u5B9A\u4F4D\u5931\u8BEF",
  synonym: "\u540C\u4E49\u66FF\u6362\u672A\u8BC6\u522B",
  paraphrase: "\u540C\u4E49\u66FF\u6362\u672A\u8BC6\u522B",
  logic: "\u903B\u8F91\u63A8\u65AD",
  overthink: "\u903B\u8F91\u63A8\u65AD",
  distractor: "\u903B\u8F91\u63A8\u65AD",
  distraction: "\u903B\u8F91\u63A8\u65AD",
  grammar: "\u903B\u8F91\u63A8\u65AD",
  rush: "\u7C97\u5FC3",
  careless: "\u7C97\u5FC3",
  misread: "\u7C97\u5FC3",
  spelling: "\u7C97\u5FC3",
  plural: "\u7C97\u5FC3",
  linking_sound: "\u7C97\u5FC3",
  sound_mapping: "\u7C97\u5FC3",
  word_limit: "\u7C97\u5FC3",
  vocab: "\u8BCD\u6C47\u4E0D\u8DB3",
  vocabulary: "\u8BCD\u6C47\u4E0D\u8DB3"
};
var native = "missed|paraphrase|distraction|distractor|spelling|plural|linking_sound|sound_mapping|misread|word_limit|vocabulary";
function frontmatter(text2) {
  const out = {};
  let key = "";
  for (const line of (text2.replace(/^\uFEFF/, "").match(/^---\r?\n([\s\S]*?)\r?\n---/)?.[1] || "").split(/\r?\n/)) {
    const pair = line.match(/^(\w+):\s*(.*)$/);
    if (pair) {
      key = pair[1];
      const v = pair[2].replace(/^["']|["']$/g, "");
      out[key] = v.startsWith("[") ? v.slice(1, -1).split(",").map((s) => s.trim().replace(/^["']|["']$/g, "")) : v || [];
    } else {
      const item = line.match(/^\s+-\s+(.*)$/);
      if (item && Array.isArray(out[key]))
        out[key].push(item[1].replace(/^["']|["']$/g, ""));
    }
  }
  return out;
}
function bucketType(raw) {
  const t = raw.toLowerCase();
  if (/fill|blank|completion|填空|summary|note|table|diagram|flow|short/.test(t))
    return "\u586B\u7A7A";
  if (/tfng|^tf$|yn|判断|true|false|not given/.test(t)) return "\u5224\u65AD";
  if (/heading/.test(t)) return "Heading";
  if (/match|匹配|feature|sentend/.test(t)) return "\u5339\u914D";
  if (/choice|选择|^mc$|multiple|单选/.test(t)) return "\u5355\u9009";
  if (/title|标题/.test(t)) return "\u9009\u6807\u9898";
  return raw;
}
function scanReviews(files, skill = "all", prefix) {
  const data = {
    records: [],
    errorCounts: {},
    errorFiles: {},
    qType: {}
  };
  for (const file of files) {
    if (!reviewPath(file.path, prefix)) continue;
    const source = file.text;
    const start = source.indexOf("<!-- IELTS_AUTO_REVIEW_START -->"), end = source.indexOf("<!-- IELTS_AUTO_REVIEW_END -->", start);
    const text2 = start >= 0 && end > start ? (source.match(/^\uFEFF?---\r?\n[\s\S]*?\r?\n---/)?.[0] || "") + "\n" + source.slice(start, end) : source;
    const fm = frontmatter(text2);
    const get = (k) => String(fm[k] || "");
    const listening = /listening/i.test(
      file.path + " " + get("tags") + " " + get("test_type") + " " + get("ielts_skill") + " " + get("ielts_mode")
    );
    const sk = listening ? "listening" : "reading";
    if (skill !== "all" && skill !== sk) continue;
    let depth = 0;
    for (const line of text2.split("\n")) {
      const h = line.match(/^\s{0,3}(#{1,6})\s+(.+)$/);
      if (h && /^Tag Reference\b/i.test(h[2])) {
        depth = h[1].length;
        continue;
      }
      if (h && h[1].length <= depth) depth = 0;
      if (depth) continue;
      for (const m of line.matchAll(
        new RegExp("#(?:error/(\\w+)|(" + native + ")\\b)", "g")
      )) {
        const label = buckets[m[1] || m[2]] || m[1];
        data.errorCounts[label] = (data.errorCounts[label] || 0) + 1;
        data.errorFiles[label] ??= [];
        if (!data.errorFiles[label].includes(file.path))
          data.errorFiles[label].push(file.path);
      }
    }
    const inline = (key) => [
      ...text2.matchAll(
        new RegExp("\\[" + key + "\\s*::\\s*([^\\]]+)\\]", "gi")
      )
    ].map((m) => m[1].trim());
    let scores = inline("score");
    const dates = inline("date"), parts = inline("part"), topics = inline("topic");
    if (get("ielts_data_kind") === "machine_exam") {
      scores.push(
        ...[...text2.matchAll(/\bScore\s+`(\d+\s*\/\s*\d+)`/gi)].map(
          (m) => m[1]
        )
      );
      scores = [scores.at(-1) || get("score")];
    } else if (!scores.length) scores = [get("score")];
    else if (get("score") && get("date") && !dates.includes(get("date")))
      scores.push(get("score"));
    const own = [];
    scores.forEach((value, i) => {
      const score = value.match(/(\d+)\s*\/\s*(\d+)/);
      if (!score) return;
      const record = {
        date: dates[i] || get("date"),
        num: +score[1],
        den: +score[2],
        topic: topics[i] || get("topic"),
        part: parts[i] || get("passage"),
        types: Array.isArray(fm.question_types) ? fm.question_types.map(bucketType) : [],
        skill: sk,
        file: file.path
      };
      own.push(record);
      data.records.push(record);
    });
    const push = (type, c, t) => {
      const q = data.qType[type] ??= { c: 0, t: 0, files: [] };
      q.c += c;
      q.t += t;
      if (!q.files.includes(file.path)) q.files.push(file.path);
    };
    let table = false, found = false, typeIdx = -1, markIdx = -1, myIdx = -1, ansIdx = -1;
    for (const line of text2.split("\n")) {
      const row = line.replace(/\[\[([^\]]+)\]\]/g, (x) => x.replace(/\|/g, "\0")).split("|").map((x) => x.replace(/\u0000/g, "|").trim());
      if (line.startsWith("|") && /Type/i.test(line) && /[✅❌]/.test(line)) {
        typeIdx = row.findIndex((x) => /^Type/i.test(x));
        markIdx = row.findIndex((x) => x.includes("\u2705") && x.includes("\u274C"));
        myIdx = row.findIndex((x) => /My/i.test(x));
        ansIdx = row.findIndex((x) => /Correct|Ans/i.test(x));
        table = typeIdx > 0;
        continue;
      }
      if (!line.startsWith("|")) table = false;
      if (!table || /^\|\s*[:\-]/.test(line) || !row[typeIdx]) continue;
      const mark = row[markIdx] || "";
      const correct = mark.includes("\u2705") || !mark.includes("\u274C") && myIdx > 0 && ansIdx > 0 && row[myIdx].toLowerCase() === row[ansIdx].replace(/==/g, "").toLowerCase();
      push(bucketType(row[typeIdx]), correct ? 1 : 0, 1);
      found = true;
    }
    for (const r of own) {
      if (listening) push(r.part || "P?", r.num, r.den);
      else if (!found) for (const type of r.types) push(type, r.num, r.den);
    }
  }
  return data;
}
function dayString(date) {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ].join("-");
}
function streak(dates, now = /* @__PURE__ */ new Date()) {
  const set = new Set(dates);
  let offset = set.has(dayString(now)) ? 0 : -1, count = 0;
  for (; ; offset--) {
    const d = new Date(now);
    d.setDate(d.getDate() + offset);
    if (!set.has(dayString(d))) return count;
    count++;
  }
}
function buildTrend(records, days = 30, now = /* @__PURE__ */ new Date()) {
  const points = Array.from({ length: days }, (_, i) => {
    const d = new Date(now);
    d.setDate(d.getDate() + i - days + 1);
    const date = dayString(d);
    const rows = records.filter((r) => r.date === date);
    const t = rows.reduce((s, r) => s + r.den, 0);
    return {
      date,
      value: t ? Math.round(rows.reduce((s, r) => s + r.num, 0) / t * 100) : null,
      files: [...new Set(rows.map((r) => r.file))]
    };
  });
  const ma = points.map((_, i) => {
    const values = points.slice(Math.max(0, i - 6), i + 1).flatMap((p3) => p3.value === null ? [] : [p3.value]);
    return values.length >= 2 ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : null;
  });
  return { points, ma };
}

// src/features/dashboard-charts.ts
function drawChart(canvas, points, kind, open2, ma = []) {
  const width = 620, height = 280, dpr = window.devicePixelRatio || 1;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.scale(dpr, dpr);
  const css = getComputedStyle(canvas);
  const color = (key) => css.getPropertyValue(key).trim() || css.color;
  const colors = [
    "--interactive-accent",
    "--text-success",
    "--text-warning",
    "--text-error",
    "--text-accent"
  ].map(color);
  ctx.font = "12px sans-serif";
  ctx.fillStyle = color("--text-muted");
  const regions = [];
  if (!points.some((p3) => p3.value !== null)) {
    ctx.fillText("\u6682\u65E0\u5B66\u4E60\u8BB0\u5F55", 24, 48);
    return;
  }
  if (kind === "pie") {
    const total = points.reduce((s, p3) => s + (p3.value || 0), 0);
    if (!total) {
      ctx.fillText("\u6682\u65E0\u9519\u56E0\u6807\u7B7E", 24, 48);
      return;
    }
    let angle = -Math.PI / 2;
    points.forEach((p3, i) => {
      const a = angle, b = a + (p3.value || 0) / total * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(140, 140);
      ctx.arc(140, 140, 105, a, b);
      ctx.closePath();
      ctx.fillStyle = colors[i % colors.length];
      ctx.fill();
      ctx.fillRect(290, 32 + i * 32, 10, 10);
      ctx.fillStyle = color("--text-normal");
      ctx.fillText(`${p3.label} \xB7 ${p3.value}`, 310, 42 + i * 32);
      regions.push({
        files: p3.files,
        hit: (x, y) => {
          let t = Math.atan2(y - 140, x - 140);
          while (t < a) t += Math.PI * 2;
          return Math.hypot(x - 140, y - 140) <= 105 && t <= b;
        }
      });
      angle = b;
    });
  } else if (kind === "bar") {
    const row = Math.min(35, 230 / Math.max(points.length, 1));
    points.forEach((p3, i) => {
      const y = 24 + i * row;
      ctx.fillStyle = color("--text-normal");
      ctx.fillText(p3.label, 8, y + 13);
      ctx.fillStyle = colors[0];
      ctx.fillRect(130, y, Math.max(1, (p3.value || 0) * 3.6), 18);
      ctx.fillStyle = color("--text-normal");
      ctx.fillText(`${p3.value ?? "\u2014"}%`, 500, y + 13);
      regions.push({
        files: p3.files,
        hit: (x, yy) => x >= 0 && x <= width && yy >= y && yy <= y + row
      });
    });
  } else {
    const x = (i) => 42 + i / Math.max(1, points.length - 1) * 550, y = (v) => 240 - v * 2;
    ctx.strokeStyle = color("--background-modifier-border");
    for (let v = 0; v <= 100; v += 25) {
      ctx.beginPath();
      ctx.moveTo(40, y(v));
      ctx.lineTo(600, y(v));
      ctx.stroke();
      ctx.fillStyle = color("--text-muted");
      ctx.fillText(String(v), 8, y(v));
    }
    const series = (values, stroke) => {
      ctx.beginPath();
      ctx.strokeStyle = stroke;
      let began = false;
      values.forEach((v, i) => {
        if (v === null) return;
        if (!began) {
          ctx.moveTo(x(i), y(v));
          began = true;
        } else ctx.lineTo(x(i), y(v));
      });
      ctx.stroke();
    };
    series(
      points.map((p3) => p3.value),
      colors[0]
    );
    series(ma, colors[2]);
    points.forEach((p3, i) => {
      if (p3.value === null) return;
      ctx.fillStyle = colors[0];
      ctx.beginPath();
      ctx.arc(x(i), y(p3.value), 3, 0, Math.PI * 2);
      ctx.fill();
      regions.push({
        files: p3.files,
        hit: (xx, yy) => Math.hypot(xx - x(i), yy - y(p3.value)) < 10
      });
      if (i % 5 === 0) {
        ctx.fillStyle = color("--text-muted");
        ctx.fillText(p3.label.slice(5), x(i) - 12, 266);
      }
    });
  }
  canvas.onclick = (event) => {
    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) * width / rect.width, y = (event.clientY - rect.top) * height / rect.height;
    const hit = regions.find((r) => r.hit(x, y));
    if (hit?.files.length) open2(hit.files, event);
  };
}

// src/features/dashboard-view.ts
var DASHBOARD = "ielts-helper-dashboard";
var DashboardView = class extends import_obsidian.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  skill = "all";
  generation = 0;
  getViewType() {
    return DASHBOARD;
  }
  getDisplayText() {
    return "IELTS \u5B66\u4E60\u4EEA\u8868\u76D8";
  }
  getIcon() {
    return "bar-chart";
  }
  async onOpen() {
    await this.refresh();
  }
  async onClose() {
    this.generation++;
    this.contentEl.empty();
  }
  async refresh() {
    const generation = ++this.generation;
    const root = this.contentEl;
    root.empty();
    root.addClass("ielts-helper-dash");
    root.createEl("h2", { text: "\u5B66\u4E60\u4EEA\u8868\u76D8" });
    const controls = root.createDiv({ cls: "ielts-helper-toolbar" });
    for (const [value, title] of [
      ["all", "\u5168\u90E8"],
      ["reading", "\u9605\u8BFB"],
      ["listening", "\u542C\u529B"]
    ]) {
      const button = controls.createEl("button", { text: title });
      button.setAttribute("aria-pressed", String(this.skill === value));
      button.onclick = () => {
        this.skill = value;
        void this.refresh();
      };
    }
    controls.createEl("button", { text: "\u5237\u65B0" }).onclick = () => void this.refresh();
    const loading = root.createEl("p", { text: "\u6B63\u5728\u8BFB\u53D6\u590D\u76D8\u7B14\u8BB0\u2026" });
    try {
      const prefix = this.plugin.studyPrefix();
      const candidates = this.app.vault.getMarkdownFiles();
      const files = await Promise.all(
        candidates.filter((f) => reviewPath(f.path, prefix)).map(async (f) => ({
          path: f.path,
          text: await this.app.vault.cachedRead(f)
        }))
      );
      const data = scanReviews(files, this.skill, prefix);
      const daily = await Promise.all(
        candidates.filter(
          (f) => studyRelative(f.path, prefix).startsWith("vocabulary/Daily/") && f.name !== "tpl-daily.md"
        ).map(
          async (f) => String(frontmatter(await this.app.vault.cachedRead(f)).date || "")
        )
      );
      if (generation !== this.generation) return;
      loading.remove();
      const stats = root.createDiv({ cls: "ielts-helper-stats" });
      const total = data.records.reduce((s, r) => s + r.den, 0), correct = data.records.reduce((s, r) => s + r.num, 0);
      const now = /* @__PURE__ */ new Date(), ago = new Date(now);
      ago.setDate(ago.getDate() - 7);
      const week = data.records.filter(
        (r) => r.date >= dayString(ago) && r.date <= dayString(now)
      ).length;
      for (const [label, value] of [
        ["\u603B\u9898\u6570", String(total)],
        ["\u603B\u6B63\u786E\u7387", total ? Math.round(correct / total * 100) + "%" : "\u2014"],
        ["\u672C\u5468\u7EC3\u4E60\u91CF", week + " \u7BC7"],
        ["\u8FDE\u7EED\u6253\u5361", streak(daily) + " \u5929"]
      ]) {
        const el = stats.createDiv();
        el.createEl("span", { text: label });
        el.createEl("strong", { text: value });
      }
      const grid = root.createDiv({ cls: "ielts-helper-charts" });
      const open2 = (paths, event) => {
        if (paths.length === 1) {
          void this.app.workspace.openLinkText(paths[0], "", false);
          return;
        }
        const menu = new import_obsidian.Menu();
        for (const p3 of paths)
          menu.addItem(
            (item) => item.setTitle(p3.split("/").at(-1)).onClick(() => {
              void this.app.workspace.openLinkText(p3, "", false);
            })
          );
        menu.showAtMouseEvent(event);
      };
      const chart = (title) => {
        const card = grid.createDiv({ cls: "ielts-helper-chart" });
        card.createEl("h3", { text: title });
        return card.createEl("canvas", {
          attr: { "aria-label": title, role: "img" }
        });
      };
      drawChart(
        chart("\u9519\u56E0\u5206\u5E03 \xB7 \u70B9\u51FB\u8DF3\u8F6C\u7B14\u8BB0"),
        Object.entries(data.errorCounts).map(([label, value]) => ({
          label,
          value,
          files: data.errorFiles[label]
        })),
        "pie",
        open2
      );
      drawChart(
        chart("\u9898\u578B / Part \u6B63\u786E\u7387"),
        Object.entries(data.qType).map(([label, q]) => ({
          label,
          value: q.t ? Math.round(q.c / q.t * 100) : 0,
          files: q.files
        })),
        "bar",
        open2
      );
      const trend = buildTrend(data.records);
      drawChart(
        chart("\u8FD1 30 \u5929\u6B63\u786E\u7387 \xB7 7 \u65E5\u79FB\u52A8\u5E73\u5747"),
        trend.points.map((p3) => ({
          label: p3.date,
          value: p3.value,
          files: p3.files
        })),
        "line",
        open2,
        trend.ma
      );
      const weeklyCanvas = chart("\u542C\u5199\u6A21\u5757 \xB7 \u5468\u51C6\u786E\u7387\u8D8B\u52BF");
      const weeklyLegend = weeklyCanvas.parentElement.createEl("p", {
        text: "\u9AD8\u9891\u7B54\u6848\u8BCD / \u9AD8\u9891\u542C\u529B\u539F\u6587\u8BCD"
      });
      try {
        const h = await this.plugin.api("/api/dict/group-training/history");
        if (generation !== this.generation) return;
        const weeks = [
          ...new Set(
            [...h.answer || [], ...h.original || []].map(
              (r) => r.week_start
            )
          )
        ].sort();
        drawChart(
          weeklyCanvas,
          weeks.map((w) => ({
            label: w,
            value: h.answer?.find((r) => r.week_start === w)?.accuracy ?? null,
            files: []
          })),
          "line",
          open2,
          weeks.map(
            (w) => h.original?.find((r) => r.week_start === w)?.accuracy ?? null
          )
        );
      } catch {
        weeklyLegend.setText("\u5B66\u4E60\u670D\u52A1\u79BB\u7EBF\uFF0C\u5468\u7EDF\u8BA1\u6682\u4E0D\u53EF\u7528");
      }
      root.createEl("p", {
        text: "\u6700\u540E\u626B\u63CF\uFF1A" + (/* @__PURE__ */ new Date()).toLocaleString() + " \xB7 " + data.records.length + " \u6761\u8BB0\u5F55",
        cls: "ielts-helper-muted"
      });
    } catch {
      if (generation === this.generation)
        loading.setText("\u8BFB\u53D6\u590D\u76D8\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7B14\u8BB0\u8BBF\u95EE\u6743\u9650\u540E\u5237\u65B0");
    }
  }
};

// src/features/inbox-router.ts
function parseStudyPlan(text2) {
  let first, last;
  for (const line of text2.split(/\r?\n/)) {
    const m = line.match(/^\|\s*(\d+)\s*\|/);
    if (!m) continue;
    const topics = [];
    const add = (id, label) => {
      id = id.toUpperCase();
      if (!topics.some((t) => t.id === id)) topics.push({ id, label });
    };
    for (const t of line.matchAll(
      /\[\[Topics\/([^\]|]+)(?:\|([^\]]+))?\]\]/g
    )) {
      const id = (t[2] || t[1]).match(/T\d{2}/i)?.[0];
      if (id) add(id, t[2] || id);
    }
    for (const t of line.replace(/\[\[[^\]]+\]\]/g, "").matchAll(/\bT\d{2}\b/gi))
      add(t[0], t[0]);
    last = { day: Number(m[1]), topics };
    if (!/\|\s*✅\s*\|\s*$/.test(line) && !first) first = last;
  }
  return first || last;
}

// src/ui/settings-tab.ts
var import_obsidian2 = require("obsidian");
var import_node_path8 = __toESM(require("node:path"));

// src/updater/types.ts
var pluginFiles = ["main.js", "manifest.json", "styles.css"];
var stable = /^\d+\.\d+\.\d+$/;
function compareVersions(a, b) {
  if (!stable.test(a) || !stable.test(b))
    throw new UserError("\u9700\u8981\u7A33\u5B9A\u7248\u672C\u53F7 x.y.z");
  const x = a.split(".").map(BigInt), y = b.split(".").map(BigInt);
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i] ? 1 : -1;
  return 0;
}
function archiveName(kind, version) {
  return `ielts-helper-${kind === "resources" ? "resources-" : ""}${version}.zip`;
}
function updateLog(event) {
  console.info(`[${(/* @__PURE__ */ new Date()).toISOString()}] IELTS \u66F4\u65B0\uFF1A${event}`);
}

// src/updater/feed-client.ts
var fs8 = __toESM(require("node:fs/promises"));
var import_node_os3 = require("node:os");
var path8 = __toESM(require("node:path"));

// src/updater/archive.ts
var fs6 = __toESM(require("node:fs/promises"));
var import_node_fs6 = require("node:fs");
var path7 = __toESM(require("node:path"));
var import_promises = require("node:stream/promises");
var import_node_stream = require("node:stream");
var import_node_crypto3 = require("node:crypto");
var yauzl = __toESM(require_yauzl());
function checksum(text2, name) {
  const sums = text2.split(/\r?\n/).map((l) => /^([a-f\d]{64})\s+\*?(.+?)\s*$/i.exec(l)).filter((m) => m && m[2] === name);
  if (sums.length !== 1) throw new UserError("\u6821\u9A8C\u6E05\u5355\u7F3A\u5C11\u5BF9\u5E94\u6587\u4EF6\u6216\u8BB0\u5F55\u91CD\u590D");
  return sums[0][1].toLowerCase();
}
var legacyBuildReceipts = {
  "ielts-helper-full-3.8.0.zip": [
    "9a83ffb988e43bdc925bac1a362611e40e295e43ef5a8398b752ac272818deb9",
    "3db9beb69f71d70b625cf2f312c4ce52ffb7aacae9ca6a36cb7cc1ceb8047273"
  ]
};
function parseSidecarDigest(content, name) {
  const lines = content.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length === 1 && /^[a-f\d]{64}$/i.test(lines[0]))
    return lines[0].toLowerCase();
  const matches = lines.map((l) => /^([a-f\d]{64})\s+\*?(.+?)\s*$/i.exec(l)).filter((m) => Boolean(m && m[2] === name));
  if (matches.length > 1) throw new UserError("\u6821\u9A8C\u6E05\u5355\u8BB0\u5F55\u91CD\u590D");
  if (matches.length === 1) return matches[0][1].toLowerCase();
  return void 0;
}
async function findDirectoryChecksum(dir, name) {
  const found = /* @__PURE__ */ new Set();
  const sidecar = path7.join(dir, `${name}.sha256`);
  try {
    const info = await fs6.stat(sidecar);
    if (info.isFile()) {
      if (info.size > 1024 * 1024) throw new UserError("\u6821\u9A8C\u6E05\u5355\u8FC7\u5927");
      const hit = parseSidecarDigest(await fs6.readFile(sidecar, "utf8"), name);
      if (hit) found.add(hit);
    }
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  const candidates = [];
  try {
    for (const entry of await fs6.readdir(dir)) {
      if (/^(?:checksums|SHA256SUMS)(?:[\s._-][^/\\]*)?(?:\.txt)?$/i.test(entry))
        candidates.push(entry);
    }
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  for (const file of candidates) {
    const full = path7.join(dir, file);
    const info = await fs6.stat(full).catch(() => void 0);
    if (!info?.isFile()) continue;
    if (info.size > 1024 * 1024) throw new UserError("\u6821\u9A8C\u6E05\u5355\u8FC7\u5927");
    const matches = (await fs6.readFile(full, "utf8")).split(/\r?\n/).map((l) => /^([a-f\d]{64})\s+\*?(.+?)\s*$/i.exec(l)).filter((m) => Boolean(m && m[2] === name));
    if (matches.length > 1) throw new UserError("\u6821\u9A8C\u6E05\u5355\u8BB0\u5F55\u91CD\u590D");
    if (matches.length === 1) found.add(matches[0][1].toLowerCase());
  }
  if (found.size > 1) throw new UserError("\u540C\u76EE\u5F55\u591A\u4E2A\u6821\u9A8C\u6E05\u5355\u5BF9\u8BE5\u6587\u4EF6\u7684 SHA-256 \u4E0D\u4E00\u81F4");
  return [...found][0];
}
async function localPackage(file, expectedSha256) {
  const name = path7.basename(file), parts = /^(?:ielts-helper-(light-|resources-|full-)?|ielts-(resources-))(\d+\.\d+\.\d+)\.zip$/.exec(
    name
  );
  if (!parts)
    throw new UserError(
      "\u8BF7\u9009\u62E9\u4FDD\u7559\u539F\u6587\u4EF6\u540D\u7684 Helper \u7A0B\u5E8F\u5305\uFF08\u542B light \u5305\uFF09\u3001\u8D44\u6E90\u5305\u6216\u65E7\u7248\u5B8C\u6574\u5305"
    );
  const tag = parts[1] ?? parts[2];
  const version = parts[3];
  let digest = expectedSha256?.trim();
  let accepted;
  if (!digest) digest = await findDirectoryChecksum(path7.dirname(file), name);
  if (!digest && tag === "full-") {
    const receipts = legacyBuildReceipts[name];
    if (receipts?.length) {
      digest = receipts[0];
      accepted = receipts;
    }
  }
  if (!digest || !/^[a-f\d]{64}$/i.test(digest))
    throw new UserError(
      "\u8BF7\u63D0\u4F9B\u53D1\u5E03\u65B9 SHA-256 \u6216\u540C\u76EE\u5F55\u7684 checksums.txt / SHA256SUMS / .sha256"
    );
  return {
    kind: tag === "resources-" ? "resources" : "helper",
    ...tag === "full-" ? { format: "bundle" } : {},
    version,
    file,
    sha256: digest.toLowerCase(),
    ...accepted ? { acceptedSha256: accepted } : {}
  };
}
var dbNames = ["content.db", "vocabulary.db", "dictation.db"];
var mediaRoots = [
  "listening",
  "audio_cache",
  "cambridge-assets",
  "images",
  "study-books"
];
function resourcePath(name) {
  const p3 = name.replace(/^data\//, "");
  if (dbNames.includes(p3)) return p3;
  if ([
    "source-profiles/providers.json",
    "listening_index.json",
    "reading_exams.json",
    "reading_explanations.json"
  ].includes(p3))
    return p3;
  if (p3.split("/").some(
    (n) => n.startsWith(".") || /backup|cookie|token|credential|secret|progress|settings|session|device/i.test(
      n
    )
  ) || p3.startsWith("audio_cache/on-demand/"))
    return void 0;
  if (mediaRoots.includes(p3.split("/")[0]) && /\.(zip|mp3|m4a|wav|ogg|png|jpe?g|webp|svg|avif|gif|json|pdf)$/i.test(p3))
    return p3;
  return void 0;
}
function entryPath(entry, pkg) {
  const dir = entry.fileName.endsWith("/"), name = entry.fileName.replace(/\/$/, "");
  const type = entry.externalFileAttributes >>> 16 & 61440;
  if (type !== 0 && type !== (dir ? 16384 : 32768) || (entry.externalFileAttributes & 1024) !== 0 || entry.extraFields.some(
    (f) => ![1, 10, 21589, 30837, 28789, 22613, 30805].includes(
      f.id
    )
  ))
    throw new UserError("ZIP \u542B\u94FE\u63A5\u3001\u7279\u6B8A\u6587\u4EF6\u6216\u4E0D\u652F\u6301\u7684\u6269\u5C55\u5C5E\u6027");
  if (entry.generalPurposeBitFlag & 1 || name.split("/").some(
    (p3) => !p3 || p3 === "." || p3 === ".." || /[\\:<>"|?*\x00-\x1f]/.test(p3) || /[. ]$/.test(p3) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(p3)
  ))
    throw new UserError("ZIP \u542B\u65E0\u6548\u8DEF\u5F84\u6216\u52A0\u5BC6\u6761\u76EE");
  if (pkg.format === "bundle") {
    if (dir || !["bundle.json", "program.zip", "resources.zip"].includes(name))
      throw new UserError("\u5B8C\u6574\u5305\u5305\u542B\u672A\u8BC6\u522B\u7684\u6587\u4EF6");
    if (name === "bundle.json" && entry.uncompressedSize > 65536)
      throw new UserError("\u5B8C\u6574\u5305\u6E05\u5355\u8FC7\u5927");
    return name;
  }
  if (pkg.format === "legacy-program" && ["main.js", "styles.css", "manifest.json", "release.json"].includes(name))
    return void 0;
  if (pkg.kind === "helper" && name.split("/")[0] !== "terminal") {
    if (["main.js", "styles.css", "manifest.json", "release.json"].includes(name))
      throw new UserError(
        "\u7A0B\u5E8F\u5305\u53EA\u5141\u8BB8 terminal/\uFF1B\u8FD9\u662F\u65E7\u542F\u52A8\u5668\u7A0B\u5E8F\u5305\uFF0C\u8BF7\u6539\u7528 ielts-helper-light-<\u7248\u672C>.zip \u6216\u5B8C\u6574\u5305 ielts-helper-full-<\u7248\u672C>.zip"
      );
    throw new UserError("\u7A0B\u5E8F\u5305\u53EA\u5141\u8BB8 terminal/");
  }
  if (dir) return void 0;
  return pkg.kind === "helper" ? name : resourcePath(name);
}
async function unpack(pkg, scratch) {
  const zipPath = path7.join(scratch, "archive.zip"), root = path7.join(scratch, "files"), hash = (0, import_node_crypto3.createHash)("sha256");
  await (0, import_promises.pipeline)(
    (0, import_node_fs6.createReadStream)(pkg.file),
    new import_node_stream.Transform({
      transform(chunk, _encoding, cb) {
        hash.update(chunk);
        cb(null, chunk);
      }
    }),
    (0, import_node_fs6.createWriteStream)(zipPath, { flags: "wx", mode: 384 })
  );
  const actual = hash.digest("hex");
  const expected = (pkg.acceptedSha256?.length ? pkg.acceptedSha256 : [pkg.sha256]).map(
    (s) => s.toLowerCase()
  );
  if (!expected.includes(actual))
    throw new UserError("ZIP SHA-256 \u6821\u9A8C\u5931\u8D25");
  const zip = await new Promise(
    (resolve, reject) => yauzl.open(
      zipPath,
      {
        lazyEntries: true,
        strictFileNames: true,
        autoClose: false,
        validateEntrySizes: true
      },
      (err, z) => err ? reject(err) : resolve(z)
    )
  );
  const files = [];
  const seen = /* @__PURE__ */ new Set();
  let total = 0;
  try {
    if (zip.entryCount > 1e5) throw new UserError("ZIP \u6761\u76EE\u8FC7\u591A");
    await fs6.mkdir(root);
    await new Promise((resolve, reject) => {
      zip.once("error", reject);
      zip.once("end", resolve);
      zip.on("entry", (e) => {
        void (async () => {
          const name = entryPath(e, pkg);
          if (name) {
            const key = name.normalize("NFC").toLowerCase();
            if (seen.has(key)) throw new UserError("ZIP \u5305\u542B\u91CD\u540D\u6761\u76EE");
            seen.add(key);
            total += e.uncompressedSize;
            if (total > 8 * 1024 ** 3)
              throw new UserError("ZIP \u5C55\u5F00\u4F53\u79EF\u8D85\u51FA\u9650\u5236");
            const f = path7.join(root, name);
            await fs6.mkdir(path7.dirname(f), { recursive: true });
            const stream = await new Promise(
              (ok, fail) => zip.openReadStream(e, (err, s) => err ? fail(err) : ok(s))
            );
            await (0, import_promises.pipeline)(
              stream,
              (0, import_node_fs6.createWriteStream)(f, { flags: "wx", mode: 384 })
            );
            files.push(name);
          }
          zip.readEntry();
        })().catch(reject);
      });
      zip.readEntry();
    });
  } finally {
    zip.close();
  }
  if (pkg.kind === "helper" && pkg.format !== "bundle" && !files.includes("terminal/IELTS_Vocab_Helper.py"))
    throw new UserError("\u7A0B\u5E8F\u5305\u7F3A\u5C11 Python \u5165\u53E3");
  if (pkg.kind === "resources" && !dbNames.every((n) => files.includes(n)))
    throw new UserError("\u8D44\u6E90\u5305\u7F3A\u5C11\u9898\u5E93\u3001\u8BCD\u6C47\u6216\u542C\u5199\u6570\u636E\u5E93");
  return { root, files };
}
async function bundleParts(root, version) {
  const invalid = () => new UserError("\u5B8C\u6574\u5305\u6E05\u5355\u3001\u7EC4\u4EF6\u5927\u5C0F\u6216\u7248\u672C\u4E0D\u5339\u914D");
  let m;
  try {
    m = JSON.parse(await fs6.readFile(path7.join(root, "bundle.json"), "utf8"));
  } catch {
    throw invalid();
  }
  if (m?.kind !== "ielts-install-bundle" || m.schema !== 1 || m.version !== version || typeof m.resourceVersion !== "string" || !stable.test(m.resourceVersion))
    throw invalid();
  const parts = [];
  for (const kind of ["helper", "resources"]) {
    const name = kind === "helper" ? "program.zip" : "resources.zip", file = path7.join(root, name);
    const meta = m.components?.[name];
    if (typeof meta?.sha256 !== "string" || !/^[a-f\d]{64}$/i.test(meta.sha256) || !Number.isSafeInteger(meta.size) || meta.size !== (await fs6.stat(file).catch(() => void 0))?.size)
      throw invalid();
    parts.push({
      kind,
      file,
      version: kind === "helper" ? version : m.resourceVersion,
      sha256: meta.sha256,
      ...kind === "helper" ? { format: "legacy-program" } : {}
    });
  }
  return parts;
}

// src/updater/network.ts
var import_node_https = require("node:https");
var import_node_http2 = require("node:http");
var net = __toESM(require("node:net"));
var tls = __toESM(require("node:tls"));
var import_node_child_process3 = require("node:child_process");
var import_node_crypto4 = require("node:crypto");
var import_node_fs7 = require("node:fs");
var fs7 = __toESM(require("node:fs/promises"));
var import_promises2 = require("node:stream/promises");
var import_node_stream2 = require("node:stream");
var hosts = {
  github: [
    "api.github.com",
    "github.com",
    "objects.githubusercontent.com",
    "release-assets.githubusercontent.com"
  ],
  gitee: ["gitee.com", "api.gitee.com", "foruda.gitee.com"]
};
function cleanSecret(value, label) {
  if (!value) return void 0;
  const trimmed = value.trim();
  if (!trimmed) return void 0;
  if (/[\r\n\x00]/.test(trimmed))
    throw new UserError(`${label}\u5305\u542B\u6362\u884C\u6216\u975E\u6CD5\u5B57\u7B26\uFF0C\u8BF7\u91CD\u65B0\u7C98\u8D34`);
  return trimmed;
}
function vpsAccess(source) {
  const rawUrl = source.vpsUrl?.trim() ?? "";
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new UserError("\u8BF7\u914D\u7F6E VPS HTTPS \u5730\u5740");
  }
  const token = cleanSecret(source.vpsToken, "VPS \u8BBF\u95EE\u5BC6\u94A5");
  if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || !token)
    throw new UserError("\u9700\u8981 HTTPS \u8BA2\u9605\u5730\u5740\u548C\u5BC6\u94A5\uFF0C\u5BC6\u94A5\u4E0D\u80FD\u653E\u5728 URL \u4E2D");
  if (url.pathname !== "/" && url.pathname !== "/manifest.json")
    throw new UserError(
      "\u8BF7\u586B\u5199\u8BA2\u9605\u7AD9\u70B9\u6839\u5730\u5740\u6216 /manifest.json\uFF0C\u4E0D\u8981\u586B\u5199\u4ED3\u5E93\u6216\u9644\u4EF6\u94FE\u63A5"
    );
  return { origin: url.origin, allowed: [url.origin], token };
}
function getGcmToken(provider) {
  return new Promise((resolve) => {
    const child = (0, import_node_child_process3.spawn)(
      "git",
      ["-c", "credential.interactive=false", "credential", "fill"],
      {
        windowsHide: true,
        stdio: ["pipe", "pipe", "ignore"],
        env: {
          ...process.env,
          GIT_TERMINAL_PROMPT: "0",
          GCM_INTERACTIVE: "never",
          GIT_ASKPASS: "",
          SSH_ASKPASS: ""
        }
      }
    );
    let output = "";
    const timeout = setTimeout(() => child.kill(), 4500);
    child.stdout.setEncoding("utf8").on("data", (s) => {
      if (output.length + s.length <= 32768) output += s;
      else child.kill();
    });
    const finish = (token) => {
      clearTimeout(timeout);
      resolve(token);
    };
    child.on("error", () => finish());
    child.on(
      "close",
      (c) => finish(
        c === 0 ? /^password=([^\r\n]+)$/m.exec(output.replace(/\r/g, ""))?.[1] : void 0
      )
    );
    child.stdin.on("error", () => {
    });
    child.stdin.end(`protocol=https
host=${provider}.com

`);
  });
}
async function providerCandidates(source, provider, privateRepo) {
  const base = {
    origin: provider === "github" ? "https://api.github.com" : "https://gitee.com",
    allowed: hosts[provider].map((h) => "https://" + h)
  };
  if (!privateRepo) return [{ access: base }];
  const entries = [
    [await getGcmToken(provider), "Git \u51ED\u636E"],
    [
      provider === "github" ? source.githubToken : source.giteeToken,
      "\u53EA\u8BFB Token"
    ],
    [
      provider === "github" ? process.env.GITHUB_TOKEN : process.env.GITEE_TOKEN,
      "\u73AF\u5883\u53D8\u91CF Token"
    ]
  ];
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const [raw, label] of entries) {
    if (!raw) continue;
    try {
      const token = cleanSecret(raw, label);
      if (token && !seen.has(token)) {
        seen.add(token);
        out.push({ access: { ...base, token } });
      }
    } catch (err) {
      if (err instanceof UserError) out.push({ error: err });
      else throw err;
    }
  }
  return out.length ? out : [{ access: base }];
}
async function providerAccess(source, provider, privateRepo) {
  const candidates = await providerCandidates(source, provider, privateRepo);
  const valid = candidates.find(
    (c) => "access" in c
  );
  if (valid) return valid.access;
  const firstErr = candidates.find(
    (c) => "error" in c
  );
  if (firstErr) throw firstErr.error;
  return {
    origin: provider === "github" ? "https://api.github.com" : "https://gitee.com",
    allowed: hosts[provider].map((h) => "https://" + h)
  };
}
function isAuthFallbackError(err) {
  return err instanceof UserError && /^更新源返回 HTTP (401|403|404)$/.test(err.message);
}
function isLoopbackHost(host) {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  return h === "localhost" || h === "127.0.0.1" || h === "::1" || h.startsWith("127.");
}
function isProxyBypassed(hostname, bypassRaw) {
  if (!bypassRaw.trim()) return false;
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  for (const raw of bypassRaw.split(/[;,\s]+/)) {
    const entry = raw.trim().toLowerCase();
    if (!entry) continue;
    if (entry === "*") return true;
    if (entry === "<local>") {
      if (!host.includes(".") || isLoopbackHost(host)) return true;
      continue;
    }
    const pattern = entry.replace(/:\d+$/, "");
    if (pattern.includes("*")) {
      const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
      if (new RegExp(`^${escaped}$`, "i").test(host)) return true;
      continue;
    }
    const bare = pattern.replace(/^\./, "");
    if (host === bare || host.endsWith("." + bare)) return true;
  }
  return false;
}
function parseProxyAddress(raw) {
  const trimmed = raw.trim();
  if (!trimmed) return void 0;
  const withScheme = /^[a-z][a-z\d+.-]*:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
  try {
    const u = new URL(withScheme);
    if (!["http:", "https:", "socks:", "socks5:", "socks5h:"].includes(u.protocol))
      return void 0;
    if (!u.hostname) return void 0;
    return u;
  } catch {
    return void 0;
  }
}
function parseWindowsProxy(regOutput) {
  const enabledMatch = /ProxyEnable\s+REG_DWORD\s+0x([0-9a-f]+)/i.exec(regOutput);
  if (!enabledMatch || Number.parseInt(enabledMatch[1], 16) === 0)
    return { bypass: "" };
  const serverMatch = /ProxyServer\s+REG_SZ\s+([^\r\n]+)/i.exec(regOutput);
  const bypassMatch = /ProxyOverride\s+REG_SZ\s+([^\r\n]+)/i.exec(regOutput);
  const server = serverMatch?.[1]?.trim() ?? "";
  const bypass = bypassMatch?.[1]?.trim() ?? "";
  if (!server) return { bypass };
  if (server.includes("=")) {
    const byScheme = /* @__PURE__ */ new Map();
    for (const part of server.split(";")) {
      const idx = part.indexOf("=");
      if (idx > 0) {
        byScheme.set(
          part.slice(0, idx).trim().toLowerCase(),
          part.slice(idx + 1).trim()
        );
      }
    }
    const chosen = byScheme.get("https") ?? byScheme.get("http") ?? (byScheme.get("socks") ? `socks5://${byScheme.get("socks")}` : void 0);
    return { proxy: chosen ? parseProxyAddress(chosen) : void 0, bypass };
  }
  return { proxy: parseProxyAddress(server), bypass };
}
function parseMacProxy(scutilOutput) {
  const field2 = (name) => new RegExp(`^\\s*${name}\\s*:\\s*([^\\r\\n]+)`, "m").exec(scutilOutput)?.[1]?.trim();
  const exceptions = [];
  const listMatch = /ExceptionsList\s*:\s*<array>\s*\{([\s\S]*?)\}/m.exec(
    scutilOutput
  );
  if (listMatch) {
    for (const line of listMatch[1].split(/\r?\n/)) {
      const m = /^\s*\d+\s*:\s*(.+?)\s*$/.exec(line);
      if (m) exceptions.push(m[1]);
    }
  }
  const bypass = exceptions.join(",");
  const pick = (enableKey, hostKey, portKey, scheme) => {
    if (field2(enableKey) !== "1") return void 0;
    const host = field2(hostKey);
    const port = field2(portKey);
    if (!host || !port) return void 0;
    return parseProxyAddress(`${scheme}://${host}:${port}`);
  };
  const proxy = pick("HTTPSEnable", "HTTPSProxy", "HTTPSPort", "http") ?? pick("HTTPEnable", "HTTPProxy", "HTTPPort", "http") ?? pick("SOCKSEnable", "SOCKSProxy", "SOCKSPort", "socks5");
  return { proxy, bypass };
}
var cachedSystemProxy;
async function querySystemProxy() {
  if (process.env.IELTS_HELPER_NO_SYSTEM_PROXY === "1") return { bypass: "" };
  const now = Date.now();
  if (cachedSystemProxy && now < cachedSystemProxy.expires)
    return cachedSystemProxy.value;
  let value = { bypass: "" };
  if (process.platform === "win32") {
    const out = await new Promise(
      (resolve) => (0, import_node_child_process3.execFile)(
        "reg",
        [
          "query",
          "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"
        ],
        { windowsHide: true, timeout: 1500 },
        (err, stdout) => resolve(err ? "" : stdout)
      )
    );
    value = parseWindowsProxy(out);
  } else if (process.platform === "darwin") {
    const out = await new Promise(
      (resolve) => (0, import_node_child_process3.execFile)(
        "scutil",
        ["--proxy"],
        { timeout: 1500 },
        (err, stdout) => resolve(err ? "" : stdout)
      )
    );
    value = parseMacProxy(out);
  }
  cachedSystemProxy = { expires: now + 15e3, value };
  return value;
}
async function resolveProxy(target2) {
  const envRaw = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy || process.env.ALL_PROXY || process.env.all_proxy;
  if (envRaw) {
    const noProxy = process.env.NO_PROXY || process.env.no_proxy || "";
    if (isProxyBypassed(target2.hostname, noProxy)) return void 0;
    const url = parseProxyAddress(envRaw);
    return url ? { url, fromSystem: false } : void 0;
  }
  if (isLoopbackHost(target2.hostname)) return void 0;
  const sys = await querySystemProxy();
  if (!sys.proxy || isProxyBypassed(target2.hostname, sys.bypass))
    return void 0;
  return { url: sys.proxy, fromSystem: true };
}
function connectHttpProxy(proxy, targetHost, targetPort) {
  return new Promise((resolve, reject) => {
    const proxyPort = Number(proxy.port) || (proxy.protocol === "https:" ? 443 : 80);
    const headers = {
      Host: `${targetHost}:${targetPort}`
    };
    if (proxy.username || proxy.password) {
      const cred = `${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`;
      headers["Proxy-Authorization"] = "Basic " + Buffer.from(cred, "utf8").toString("base64");
    }
    const req = (proxy.protocol === "https:" ? import_node_https.request : import_node_http2.request)({
      host: proxy.hostname,
      port: proxyPort,
      method: "CONNECT",
      path: `${targetHost}:${targetPort}`,
      headers
    });
    req.setTimeout(15e3, () => req.destroy(new UserError("\u8FDE\u63A5\u4EE3\u7406\u8D85\u65F6")));
    req.once("connect", (res, socket) => {
      if (res.statusCode !== 200) {
        socket.destroy();
        reject(
          new UserError(
            `\u4EE3\u7406\u62D2\u7EDD\u8FDE\u63A5\uFF08HTTP ${res.statusCode}\uFF09\uFF0C\u8BF7\u68C0\u67E5\u7CFB\u7EDF\u4EE3\u7406\u8BBE\u7F6E`
          )
        );
        return;
      }
      resolve(socket);
    });
    req.once("error", reject);
    req.end();
  });
}
var SocksReader = class {
  constructor(socket) {
    this.socket = socket;
    socket.on("data", this.onData);
    socket.once("error", this.onError);
    socket.once("close", this.onClose);
  }
  buf = Buffer.alloc(0);
  ended;
  waiter;
  onData = (chunk) => {
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    this.flush();
  };
  onError = (err) => this.fail(err);
  onClose = () => this.fail(new UserError("SOCKS5 \u4EE3\u7406\u8FDE\u63A5\u63D0\u524D\u5173\u95ED"));
  flush() {
    if (!this.waiter) return;
    if (this.buf.length >= this.waiter.count) {
      const { count, resolve } = this.waiter;
      this.waiter = void 0;
      const out = this.buf.subarray(0, count);
      this.buf = this.buf.subarray(count);
      resolve(out);
      return;
    }
    if (this.ended) {
      const { reject } = this.waiter;
      this.waiter = void 0;
      reject(this.ended);
    }
  }
  fail(err) {
    if (!this.ended) this.ended = err;
    this.flush();
  }
  read(count) {
    if (this.buf.length >= count) {
      const out = this.buf.subarray(0, count);
      this.buf = this.buf.subarray(count);
      return Promise.resolve(out);
    }
    if (this.ended) return Promise.reject(this.ended);
    return new Promise((resolve, reject) => {
      this.waiter = { count, resolve, reject };
    });
  }
  detach() {
    this.socket.off("data", this.onData);
    this.socket.off("error", this.onError);
    this.socket.off("close", this.onClose);
    if (this.buf.length) {
      this.socket.pause();
      this.socket.unshift(this.buf);
      this.buf = Buffer.alloc(0);
    }
  }
};
async function connectSocks5Proxy(proxy, targetHost, targetPort, timeoutMs = 15e3) {
  const proxyPort = Number(proxy.port) || 1080;
  const socket = await new Promise((resolve, reject) => {
    const s = net.connect({ host: proxy.hostname, port: proxyPort });
    const onTimeout = () => s.destroy(new UserError("\u8FDE\u63A5\u4EE3\u7406\u8D85\u65F6"));
    s.setTimeout(timeoutMs, onTimeout);
    s.once("connect", () => {
      s.off("timeout", onTimeout);
      s.off("error", reject);
      resolve(s);
    });
    s.once("error", reject);
  });
  const reader = new SocksReader(socket);
  const handshakeTimer = setTimeout(() => {
    socket.destroy(new UserError("SOCKS5 \u4EE3\u7406\u63E1\u624B\u8D85\u65F6"));
  }, timeoutMs);
  try {
    const hasAuth = Boolean(proxy.username || proxy.password);
    socket.write(
      hasAuth ? Buffer.from([5, 2, 0, 2]) : Buffer.from([5, 1, 0])
    );
    const greeting = await reader.read(2);
    if (greeting[0] !== 5 || greeting[1] === 255)
      throw new UserError("SOCKS5 \u4EE3\u7406\u8BA4\u8BC1\u65B9\u5F0F\u4E0D\u652F\u6301");
    if (greeting[1] === 2) {
      const user = Buffer.from(decodeURIComponent(proxy.username), "utf8");
      const pass = Buffer.from(decodeURIComponent(proxy.password), "utf8");
      if (user.length > 255 || pass.length > 255)
        throw new UserError("SOCKS5 \u4EE3\u7406\u51ED\u636E\u8FC7\u957F");
      socket.write(
        Buffer.concat([
          Buffer.from([1, user.length]),
          user,
          Buffer.from([pass.length]),
          pass
        ])
      );
      const authRes = await reader.read(2);
      if (authRes[1] !== 0) throw new UserError("SOCKS5 \u4EE3\u7406\u8BA4\u8BC1\u5931\u8D25");
    }
    const hostBuf = Buffer.from(targetHost, "utf8");
    if (hostBuf.length > 255) throw new UserError("\u76EE\u6807\u4E3B\u673A\u540D\u8FC7\u957F");
    const portBuf = Buffer.alloc(2);
    portBuf.writeUInt16BE(targetPort, 0);
    socket.write(
      Buffer.concat([
        Buffer.from([5, 1, 0, 3, hostBuf.length]),
        hostBuf,
        portBuf
      ])
    );
    const head = await reader.read(4);
    if (head[0] !== 5 || head[1] !== 0)
      throw new UserError("SOCKS5 \u4EE3\u7406\u8F6C\u53D1\u76EE\u6807\u5931\u8D25");
    if (head[3] === 1) await reader.read(6);
    else if (head[3] === 4) await reader.read(18);
    else if (head[3] === 3) {
      const len = (await reader.read(1))[0];
      await reader.read(len + 2);
    } else throw new UserError("SOCKS5 \u4EE3\u7406\u54CD\u5E94\u65E0\u6548");
    reader.detach();
    socket.setTimeout(0);
    return socket;
  } catch (err) {
    reader.detach();
    socket.destroy();
    throw err;
  } finally {
    clearTimeout(handshakeTimer);
  }
}
function createProxyAgent(choice) {
  const agent = new import_node_https.Agent({ keepAlive: false });
  agent.createConnection = (options2, cb) => {
    const targetHost = String(options2.servername || options2.host || "");
    const targetPort = Number(options2.port) || 443;
    const dial = choice.url.protocol.startsWith("socks") ? connectSocks5Proxy(choice.url, targetHost, targetPort) : connectHttpProxy(choice.url, targetHost, targetPort);
    dial.then((socket) => {
      const tlsSocket = tls.connect({
        ...options2,
        socket,
        servername: targetHost
      });
      cb(null, tlsSocket);
    }).catch((err) => {
      if (choice.fromSystem && err?.code === "ECONNREFUSED") {
        const direct = tls.connect({
          ...options2,
          host: targetHost,
          port: targetPort,
          servername: targetHost
        });
        cb(null, direct);
        return;
      }
      cb(
        err instanceof UserError ? err : new UserError("\u4EE3\u7406\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7CFB\u7EDF\u4EE3\u7406\u5730\u5740\u4E0E\u7AEF\u53E3")
      );
    });
  };
  return agent;
}
function networkError(err) {
  if (err instanceof UserError) return err;
  const code = err?.code ?? "";
  if (code === "ENOTFOUND" || code === "EAI_AGAIN")
    return new UserError("\u65E0\u6CD5\u89E3\u6790\u66F4\u65B0\u6E90\u57DF\u540D\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u7CFB\u7EDF\u4EE3\u7406");
  if (code === "ETIMEDOUT" || code === "ESOCKETTIMEDOUT")
    return new UserError("\u8FDE\u63A5\u66F4\u65B0\u6E90\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u7CFB\u7EDF\u4EE3\u7406");
  if (code === "ECONNREFUSED")
    return new UserError("\u66F4\u65B0\u6E90\u6216\u4EE3\u7406\u62D2\u7EDD\u8FDE\u63A5\uFF0C\u8BF7\u68C0\u67E5\u5730\u5740\u4E0E\u4EE3\u7406\u7AEF\u53E3");
  if (code === "ECONNRESET" || code === "EPIPE")
    return new UserError("\u66F4\u65B0\u6E90\u8FDE\u63A5\u4E2D\u65AD\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u7CFB\u7EDF\u4EE3\u7406");
  if (code === "ERR_INVALID_CHAR")
    return new UserError("\u8BF7\u6C42\u5934\u542B\u975E\u6CD5\u5B57\u7B26\uFF0C\u8BF7\u68C0\u67E5\u5BC6\u94A5\u662F\u5426\u6709\u591A\u4F59\u6362\u884C\u6216\u7A7A\u683C");
  if (code.startsWith("ERR_TLS_") || [
    "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
    "CERT_HAS_EXPIRED",
    "DEPTH_ZERO_SELF_SIGNED_CERT",
    "SELF_SIGNED_CERT_IN_CHAIN",
    "CERT_NOT_YET_VALID"
  ].includes(code))
    return new UserError("TLS \u8BC1\u4E66\u6821\u9A8C\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7CFB\u7EDF\u65F6\u95F4\u6216\u4EE3\u7406\u8BC1\u4E66");
  return new UserError("\u66F4\u65B0\u6E90\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u3001\u4EE3\u7406\u4E0E\u8BC1\u4E66");
}
async function manifest502(res) {
  try {
    if (res.headers["content-type"]?.startsWith("application/json")) {
      let body = "";
      for await (const chunk of res) {
        if (body.length + chunk.length > 1024) break;
        body += chunk.toString("utf8");
      }
      if (JSON.parse(body)?.error === "upstream_unavailable")
        return new UserError(
          "\u8BA2\u9605\u8FD4\u56DE HTTP 502\uFF1A\u4E0A\u6E38\u6E05\u5355\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7EF4\u62A4\u8005\u68C0\u67E5\u4E09\u7C7B\u53D1\u5E03\u9644\u4EF6\u548C\u79C1\u4ED3\u8BFB\u53D6\u6743\u9650"
        );
    }
  } catch {
  } finally {
    res.destroy();
  }
  return new UserError(
    "\u8BA2\u9605\u8FD4\u56DE HTTP 502\uFF1A\u8BF7\u68C0\u67E5 /health\uFF1B\u82E5\u6B63\u5E38\uFF0C\u8BF7\u7EF4\u62A4\u8005\u6838\u5BF9 VPS \u6E90\u7AD9\u6E05\u5355\u548C\u4E0A\u6E38\u53D1\u5E03"
  );
}
async function openStream(input, access, accept, refresh = false, method = "GET", extraHeaders) {
  let url;
  try {
    url = new URL(input, access.origin);
  } catch {
    throw new UserError("\u4E0B\u8F7D\u5730\u5740\u65E0\u6548");
  }
  let token = access.token && url.origin === access.origin ? access.token : void 0;
  for (let n = 0; n <= 5; n++) {
    if (url.protocol !== "https:" || !access.allowed.includes(url.origin) || url.username || url.password || url.hash)
      throw new UserError("\u62D2\u7EDD\u975E\u53D7\u4FE1 HTTPS \u4E0B\u8F7D\u7AD9\u70B9");
    const proxy = await resolveProxy(url);
    const res = await new Promise((resolve, reject) => {
      let req;
      try {
        req = (0, import_node_https.request)(
          url,
          {
            method,
            ...proxy ? { agent: createProxyAgent(proxy) } : {},
            headers: {
              "User-Agent": "ielts-helper-plugin",
              Accept: accept,
              ...token ? { Authorization: `Bearer ${token}` } : {},
              ...refresh ? { "Cache-Control": "no-cache" } : {},
              ...extraHeaders ?? {}
            }
          },
          resolve
        );
      } catch (err) {
        reject(networkError(err));
        return;
      }
      req.setTimeout(3e4, () => req.destroy(new UserError("\u8FDE\u63A5\u8D85\u65F6")));
      req.on("error", (err) => reject(networkError(err)));
      req.end();
    });
    if ([301, 302, 303, 307, 308].includes(res.statusCode ?? 0)) {
      const location = res.headers.location;
      res.destroy();
      if (!location) throw new UserError("\u4E0B\u8F7D\u6E90\u672A\u63D0\u4F9B\u8DF3\u8F6C\u76EE\u6807");
      let next;
      try {
        next = new URL(location, url);
      } catch {
        throw new UserError("\u4E0B\u8F7D\u8DF3\u8F6C\u5730\u5740\u65E0\u6548");
      }
      if (next.origin !== url.origin) token = void 0;
      url = next;
      continue;
    }
    const okStatus = extraHeaders?.Range ? res.statusCode === 206 || res.statusCode === 200 : res.statusCode === 200;
    if (!okStatus) {
      if (input === "/manifest.json" && res.statusCode === 502)
        throw await manifest502(res);
      res.destroy();
      throw new UserError(`\u66F4\u65B0\u6E90\u8FD4\u56DE HTTP ${res.statusCode}`);
    }
    return res;
  }
  throw new UserError("\u4E0B\u8F7D\u8DF3\u8F6C\u6B21\u6570\u8FC7\u591A");
}
async function text(input, access, accept = "application/json", refresh = false) {
  const response = await openStream(input, access, accept, refresh), chunks = [];
  let bytes = 0;
  try {
    for await (const chunk of response) {
      bytes += chunk.length;
      if (bytes > 8 * 1024 * 1024) {
        response.destroy();
        throw new UserError("\u53D1\u5E03\u5143\u6570\u636E\u8D85\u51FA\u9650\u5236");
      }
      chunks.push(Buffer.from(chunk));
    }
  } catch (err) {
    throw networkError(err);
  }
  return Buffer.concat(chunks).toString("utf8");
}
function checkAsset(a) {
  if (!a || !Number.isSafeInteger(a.size) || a.size < 0 || !/^\w/.test(a.sha256) || !/^[a-f\d]{64}$/i.test(a.sha256) || typeof a.url !== "string")
    throw new UserError("\u6E05\u5355\u9644\u4EF6\u7F3A\u5C11\u5927\u5C0F\u3001\u5730\u5740\u6216 SHA-256");
}
async function fileSha256(file) {
  const hash = (0, import_node_crypto4.createHash)("sha256");
  await (0, import_promises2.pipeline)(
    (0, import_node_fs7.createReadStream)(file),
    new import_node_stream2.Transform({
      transform(chunk, _enc, cb) {
        hash.update(chunk);
        cb();
      }
    })
  );
  return hash.digest("hex");
}
async function download(a, access, file) {
  checkAsset(a);
  let hash = (0, import_node_crypto4.createHash)("sha256");
  let resumed = false;
  let diskBytes = 0;
  for (let attempt = 0; attempt <= 3; attempt++) {
    const resuming = attempt > 0 && diskBytes > 0 && diskBytes < a.size;
    let res;
    try {
      res = await openStream(
        a.url,
        access,
        "application/octet-stream",
        false,
        "GET",
        resuming ? { Range: `bytes=${diskBytes}-` } : void 0
      );
    } catch (err) {
      if (attempt < 3 && !(err instanceof UserError && /HTTP 4\d\d|非受信/.test(err.message)))
        continue;
      throw networkError(err);
    }
    let append = false;
    let offset = 0;
    if (resuming && res.statusCode === 206) {
      const range = String(res.headers["content-range"] ?? "");
      if (new RegExp(`^bytes\\s+${diskBytes}-\\d+/${a.size}$`).test(range)) {
        append = true;
        resumed = true;
        offset = diskBytes;
      } else {
        res.destroy();
        throw new UserError("\u65AD\u70B9\u7EED\u4F20\u54CD\u5E94\u8303\u56F4\u4E0E\u6E05\u5355\u4E0D\u4E00\u81F4");
      }
    } else if (attempt > 0) {
      resumed = true;
      hash = (0, import_node_crypto4.createHash)("sha256");
      offset = 0;
    }
    res.socket?.setTimeout(6e4);
    let writtenInPass = 0;
    try {
      await (0, import_promises2.pipeline)(
        res,
        new import_node_stream2.Transform({
          transform(chunk, _enc, cb) {
            writtenInPass += chunk.length;
            if (offset + writtenInPass > a.size)
              return cb(new UserError("\u9644\u4EF6\u8D85\u8FC7\u6E05\u5355\u5927\u5C0F"));
            if (!resumed) hash.update(chunk);
            cb(null, chunk);
          }
        }),
        (0, import_node_fs7.createWriteStream)(file, {
          flags: append ? "a" : attempt === 0 ? "wx" : "w",
          mode: 384
        })
      );
      diskBytes = (await fs7.stat(file)).size;
      if (diskBytes === a.size) break;
      if (attempt < 3 && diskBytes < a.size) continue;
      break;
    } catch (err) {
      if (err instanceof UserError) throw err;
      diskBytes = (await fs7.stat(file).catch(() => void 0))?.size ?? 0;
      if (attempt < 3 && diskBytes < a.size) continue;
      throw new UserError("\u9644\u4EF6\u4E0B\u8F7D\u4E2D\u65AD\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u7CFB\u7EDF\u4EE3\u7406\u540E\u91CD\u8BD5");
    }
  }
  const actualDigest = resumed ? await fileSha256(file) : hash.digest("hex");
  if (diskBytes !== a.size || actualDigest !== a.sha256.toLowerCase())
    throw new UserError("\u9644\u4EF6\u5927\u5C0F\u6216 SHA-256 \u6821\u9A8C\u5931\u8D25");
}

// src/updater/feed-client.ts
function checkRelease(r) {
  if (!r || !stable.test(r.version) || typeof r.tag !== "string" || typeof r.notes !== "string" || typeof r.publishedAt !== "string")
    throw new UserError("\u53D1\u5E03\u8BB0\u5F55\u683C\u5F0F\u9519\u8BEF");
}
function validatePackages(f, vps = false) {
  if (f?.schema !== 1 || !["github", "gitee"].includes(f.source) || typeof f.generatedAt !== "string")
    throw new UserError("\u65E0\u6CD5\u8BC6\u522B\u7684\u8BA2\u9605\u6E05\u5355");
  for (const k of ["helper", "resources"]) {
    const r = f[k];
    checkRelease(r);
    const name = archiveName(k, r.version), a = r.asset;
    checkAsset(a);
    const route = `/download/${k}/${r.version}/${name}`;
    if (vps && a.url !== route && a.url !== `${route}?source=${f.source}`)
      throw new UserError("\u6E05\u5355\u4E0B\u8F7D\u8DEF\u5F84\u4E0D\u7B26\u5408\u5951\u7EA6");
    if (a.filename !== name) throw new UserError("\u53D1\u5E03\u9644\u4EF6\u540D\u4E0E\u7248\u672C\u4E0D\u5339\u914D");
  }
  if (!stable.test(f.helper.minPluginVersion) || !stable.test(f.helper.recommendedPluginVersion) || !["on-demand", "offline", "bundled"].includes(f.resources.audioMode))
    throw new UserError("\u7F3A\u5C11\u517C\u5BB9\u6027\u6216\u8D44\u6E90\u5143\u6570\u636E");
  return f;
}
async function releases(provider, rawRepo, access, kinds) {
  const repo = rawRepo.trim();
  if (!/^[\w.-]+\/[\w.-]+$/.test(repo) || repo.split("/").some((p3) => p3 === "." || p3 === ".."))
    throw new UserError("\u4ED3\u5E93\u540D\u5E94\u4E3A \u6240\u6709\u8005/\u4ED3\u5E93");
  const root = provider === "github" ? "https://api.github.com/repos/" : "https://gitee.com/api/v5/repos/";
  const collected = [];
  let last = "";
  for (let page = 1; ; page++) {
    const rows = JSON.parse(
      await text(`${root}${repo}/releases?per_page=100&page=${page}`, access)
    );
    if (!Array.isArray(rows)) throw new UserError("\u53D1\u5E03\u5217\u8868\u683C\u5F0F\u9519\u8BEF");
    for (const r of rows) {
      if (kinds.some((k) => Boolean(candidate(r, k)))) collected.push(r);
    }
    if (rows.length < 100) break;
    const tail = rows[rows.length - 1].tag_name;
    if (tail === last) throw new UserError("\u4E0A\u6E38\u53D1\u5E03\u5206\u9875\u672A\u524D\u8FDB");
    last = tail;
  }
  return collected;
}
function assetUrl(a, repo, provider) {
  if (provider === "github" && Number.isSafeInteger(a.id))
    return `https://api.github.com/repos/${repo.trim()}/releases/assets/${a.id}`;
  if (!a.browser_download_url) throw new UserError("\u9644\u4EF6\u7F3A\u5C11\u4E0B\u8F7D\u5730\u5740");
  return a.browser_download_url;
}
function field(body, key) {
  return body.split(/\r?\n/).map(
    (l) => new RegExp(`^\\s*${key}\\s*:\\s*(\\S+)\\s*$`, "i").exec(l)?.[1]
  ).find(Boolean) ?? "";
}
function candidate(r, kind) {
  if (r.draft || r.prerelease || !Array.isArray(r.assets)) return;
  const ver = (kind === "resources" ? /^resources-v(\d+\.\d+\.\d+)$/ : /^v?(\d+\.\d+\.\d+)$/).exec(r.tag_name)?.[1];
  if (!ver) return;
  const hasChecksum = r.assets.some(
    (a) => a.name === "checksums.txt" || a.name === "SHA256SUMS"
  );
  const body = r.body ?? "";
  const hasMeta = kind === "plugin" ? true : kind === "helper" ? stable.test(field(body, "minPluginVersion")) && stable.test(field(body, "recommendedPluginVersion")) : ["on-demand", "offline", "bundled"].includes(field(body, "audioMode"));
  const complete = hasChecksum && hasMeta;
  if (kind === "helper") {
    const light = `ielts-helper-light-${ver}.zip`;
    if (r.assets.some((a) => a.name === light))
      return { ver, names: [light], complete };
    const standard = archiveName(kind, ver);
    if (r.assets.some((a) => a.name === standard))
      return { ver, names: [standard], complete };
    return;
  }
  const names = kind === "plugin" ? pluginFiles : [archiveName(kind, ver)];
  if (!names.every((n) => r.assets.some((a) => a.name === n))) return;
  return { ver, names, complete };
}
async function component(rows, kind, provider, repo, access) {
  const matched = rows.map((r) => ({ r, match: candidate(r, kind) })).filter(
    (x) => Boolean(x.match)
  ).sort((a, b) => {
    if (a.match.complete !== b.match.complete)
      return a.match.complete ? -1 : 1;
    return compareVersions(b.match.ver, a.match.ver);
  });
  let lastManifestError;
  for (const { r, match } of matched) {
    const { ver, names } = match;
    const by = new Map(r.assets.map((a) => [a.name, a]));
    const sum = by.get("checksums.txt") ?? by.get("SHA256SUMS");
    if (!sum) {
      const label = { plugin: "\u63D2\u4EF6", helper: "Helper", resources: "\u8D44\u6E90" }[kind];
      lastManifestError ??= new UserError(
        `${label} ${ver} \u7F3A\u5C11 checksums.txt \u6216 SHA256SUMS\uFF0C\u8BF7\u7EF4\u62A4\u8005\u8865\u9F50\u8F7B\u91CF\u53D1\u5E03\u9644\u4EF6`
      );
      continue;
    }
    if (!match.complete) {
      lastManifestError ??= new UserError("\u7F3A\u5C11\u517C\u5BB9\u6027\u6216\u8D44\u6E90\u5143\u6570\u636E");
      continue;
    }
    const checks = await text(
      assetUrl(sum, repo, provider),
      access,
      "application/octet-stream"
    );
    const digests = [];
    let checksumError;
    for (const name of names) {
      try {
        digests.push([name, checksum(checks, name)]);
      } catch (e) {
        if (e instanceof UserError) {
          checksumError = e;
          break;
        }
        throw e;
      }
    }
    if (checksumError) {
      lastManifestError ??= checksumError;
      continue;
    }
    const assets = {};
    let assetError;
    for (const [name, sha256] of digests) {
      const a = by.get(name), url = assetUrl(a, repo, provider);
      let size = a.size;
      if (size === void 0) {
        const res = await openStream(
          url,
          access,
          "application/octet-stream",
          false,
          "HEAD"
        );
        const len = res.headers["content-length"];
        res.destroy();
        if (len === void 0) {
          assetError = new UserError("\u4E0A\u6E38\u6CA1\u6709\u63D0\u4F9B\u9644\u4EF6\u5927\u5C0F");
          break;
        }
        size = Number(len);
      }
      const item = { url, size, sha256 };
      try {
        checkAsset(item);
      } catch (e) {
        if (e instanceof UserError) {
          assetError = e;
          break;
        }
        throw e;
      }
      assets[kind === "helper" ? archiveName(kind, ver) : name] = item;
    }
    if (assetError) {
      lastManifestError ??= assetError;
      continue;
    }
    const release = {
      version: ver,
      tag: r.tag_name,
      notes: r.body ?? "",
      publishedAt: r.published_at ?? r.created_at ?? ""
    };
    return { release, assets };
  }
  if (lastManifestError) throw lastManifestError;
  throw new UserError(`\u4ED3\u5E93\u4E2D\u6CA1\u6709\u53EF\u7528\u7684 ${kind} \u7A33\u5B9A\u7248`);
}
var pubRepo = (s) => s.pluginRepo?.trim() || "Cooper519/obsidian-ielts-helper";
async function publicPlugin(s) {
  const repo = pubRepo(s), a = await providerAccess(s, "github", false), c = await component(
    await releases("github", repo, a, ["plugin"]),
    "plugin",
    "github",
    repo,
    a
  );
  return { ...c.release, assets: c.assets };
}
async function getPluginRelease(s, refresh = false) {
  if (s.mode === "local") throw new UserError("\u4EC5\u672C\u5730\u6A21\u5F0F\u4E0D\u4F1A\u68C0\u67E5\u5728\u7EBF\u53D1\u5E03");
  return s.mode === "vps" ? (await getManifest(s, refresh)).plugin : publicPlugin(s);
}
async function getManifest(s, refresh = false) {
  if (s.mode === "local") throw new UserError("\u4EC5\u672C\u5730\u6A21\u5F0F\u4E0D\u4F1A\u68C0\u67E5\u5728\u7EBF\u53D1\u5E03");
  if (s.mode === "vps") {
    const a = vpsAccess(s);
    const f = JSON.parse(
      await text("/manifest.json", a, "application/json", refresh)
    );
    validatePackages(f, true);
    checkRelease(f.plugin);
    for (const name of pluginFiles) {
      const a2 = f.plugin.assets?.[name];
      checkAsset(a2);
      const route = `/download/plugin/${f.plugin.version}/${name}`;
      if (a2.url !== route && a2.url !== `${route}?source=${f.source}`)
        throw new UserError("\u6E05\u5355\u4E0B\u8F7D\u8DEF\u5F84\u4E0D\u7B26\u5408\u5951\u7EA6");
    }
    return f;
  }
  const [packages, plugin] = await Promise.all([
    getPackageFeed(s),
    publicPlugin(s)
  ]);
  return { ...packages, plugin };
}
async function withAuthFallback(candidates, action) {
  let lastErr;
  for (let i = 0; i < candidates.length; i++) {
    const item = candidates[i];
    if ("error" in item) {
      lastErr = item.error;
      continue;
    }
    try {
      return await action(item.access);
    } catch (err) {
      lastErr = err;
      if (i + 1 < candidates.length && isAuthFallbackError(err)) continue;
      throw err;
    }
  }
  throw lastErr;
}
async function getPackageFeed(s, refresh = false) {
  if (s.mode === "vps" || s.mode === "local") return getManifest(s, refresh);
  const provider = s.mode, repo = (provider === "github" ? s.githubRepo : s.giteeRepo)?.trim();
  if (!repo) throw new UserError("\u8BF7\u586B\u5199\u5F53\u524D\u66F4\u65B0\u6E90\u7684\u79C1\u6709\u4ED3\u5E93\u540D\uFF08\u683C\u5F0F\uFF1A\u6240\u6709\u8005/\u4ED3\u5E93\uFF09");
  const candidates = await providerCandidates(s, provider, true);
  return withAuthFallback(candidates, async (a) => {
    const rows = await releases(provider, repo, a, ["helper", "resources"]);
    const [h, r] = await Promise.all([
      component(rows, "helper", provider, repo, a),
      component(rows, "resources", provider, repo, a)
    ]), hn = archiveName("helper", h.release.version), rn = archiveName("resources", r.release.version);
    return validatePackages({
      schema: 1,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      source: provider,
      helper: {
        ...h.release,
        asset: { ...h.assets[hn], filename: hn },
        minPluginVersion: field(h.release.notes, "minPluginVersion"),
        recommendedPluginVersion: field(
          h.release.notes,
          "recommendedPluginVersion"
        )
      },
      resources: {
        ...r.release,
        asset: { ...r.assets[rn], filename: rn },
        audioMode: field(r.release.notes, "audioMode")
      }
    });
  });
}
async function withDownloadedPackage(s, m, k, callback) {
  if (s.mode === "local") throw new UserError("\u672C\u5730\u6A21\u5F0F\u8BF7\u9009\u62E9 ZIP");
  validatePackages(m, s.mode === "vps");
  const candidates = s.mode === "vps" ? [{ access: vpsAccess(s) }] : await providerCandidates(s, s.mode, true), release = m[k];
  const dir = await fs8.mkdtemp(path8.join((0, import_node_os3.tmpdir)(), "ielts-download-"));
  try {
    const f = path8.join(dir, release.asset.filename);
    await withAuthFallback(candidates, async (access) => {
      await fs8.rm(f, { force: true });
      await download(release.asset, access, f);
    });
    await callback({
      kind: k,
      version: release.version,
      file: f,
      sha256: release.asset.sha256
    });
  } finally {
    await fs8.rm(dir, { recursive: true, force: true });
  }
}

// src/updater/installer.ts
var fs9 = __toESM(require("node:fs/promises"));
var p = __toESM(require("node:path"));
var import_node_crypto5 = require("node:crypto");
async function stat3(file) {
  try {
    return await fs9.lstat(file);
  } catch (e) {
    if (e.code === "ENOENT") return void 0;
    throw e;
  }
}
async function readInstalled(appRoot) {
  const f = p.join(appRoot, "current.json");
  if (!await stat3(f)) return {};
  if (!(await fs9.lstat(f)).isFile())
    throw new UserError("\u7248\u672C\u6307\u9488\u4E0D\u662F\u666E\u901A\u6587\u4EF6");
  const record = JSON.parse(await fs9.readFile(f, "utf8"));
  if (!record || typeof record !== "object" || Array.isArray(record))
    throw new UserError("\u7248\u672C\u6307\u9488\u65E0\u6548");
  for (const k of ["version", "previousVersion", "resourcesVersion"])
    if (record[k] != null && (typeof record[k] !== "string" || !stable.test(record[k])))
      throw new UserError("\u7248\u672C\u6307\u9488\u5305\u542B\u65E0\u6548\u7248\u672C\u53F7");
  return record;
}
async function pointer(app, record) {
  const file = p.join(app, "current.json"), tmp = p.join(app, `.current-${(0, import_node_crypto5.randomUUID)()}`);
  try {
    await fs9.writeFile(
      tmp,
      Buffer.isBuffer(record) ? record : JSON.stringify(
        { ...record, updatedAt: (/* @__PURE__ */ new Date()).toISOString() },
        null,
        2
      ) + "\n",
      { flag: "wx", mode: 384 }
    );
    await fs9.rename(tmp, file);
  } finally {
    await fs9.rm(tmp, { force: true });
  }
}
function contains2(parent, child) {
  const r = p.relative(parent, child);
  return !r || !p.isAbsolute(r) && r !== ".." && !r.startsWith(".." + p.sep);
}
async function canonical2(file) {
  try {
    return await fs9.realpath(file);
  } catch (e) {
    if (e.code !== "ENOENT" || p.dirname(file) === file)
      throw e;
    return p.join(await canonical2(p.dirname(file)), p.basename(file));
  }
}
async function safeRoots(paths) {
  for (const s of [paths.appRoot, paths.dataDir, paths.vaultRoot])
    if (!p.isAbsolute(s))
      throw new UserError("\u5B89\u88C5\u3001\u6570\u636E\u4E0E Vault \u5FC5\u987B\u4F7F\u7528\u7EDD\u5BF9\u8DEF\u5F84");
  const [app, data, vault] = await Promise.all(
    [paths.appRoot, paths.dataDir, paths.vaultRoot].map(canonical2)
  );
  for (const d of [app, data])
    if (contains2(vault, d) || contains2(d, vault) || d === p.parse(d).root)
      throw new UserError("\u5916\u90E8\u76EE\u5F55\u4E0D\u80FD\u4E0E Vault \u91CD\u53E0\u6216\u4F7F\u7528\u78C1\u76D8\u6839\u76EE\u5F55");
  if (contains2(app, data) || contains2(data, app))
    throw new UserError("\u7A0B\u5E8F\u548C\u6570\u636E\u76EE\u5F55\u5FC5\u987B\u5F7C\u6B64\u72EC\u7ACB");
  await fs9.mkdir(app, { recursive: true });
  await fs9.mkdir(data, { recursive: true });
  return { app, data };
}
async function checkedChild(root, name) {
  let at = root;
  for (const part of name.split("/")) {
    at = p.join(at, part);
    const s = await stat3(at);
    if (s?.isSymbolicLink())
      throw new UserError("\u76EE\u6807\u8DEF\u5F84\u542B\u7B26\u53F7\u94FE\u63A5\uFF0C\u5DF2\u505C\u6B62\u66F4\u65B0");
  }
  return at;
}
var RecoveryIncomplete = class extends UserError {
};
async function acquireLock(file) {
  const create = () => fs9.writeFile(file, `${(/* @__PURE__ */ new Date()).toISOString()} ${process.pid}
`, {
    flag: "wx",
    mode: 384
  });
  try {
    await create();
    return;
  } catch (e) {
    if (e.code !== "EEXIST") throw e;
  }
  const busy2 = () => new UserError("\u5B89\u88C5\u76EE\u5F55\u5DF2\u6709\u66F4\u65B0\u9501\uFF0C\u8BF7\u5728\u4E0A\u4E00\u66F4\u65B0\u7ED3\u675F\u540E\u91CD\u8BD5");
  const guard = file + ".recovery";
  try {
    await fs9.mkdir(guard);
  } catch (e) {
    if (e.code === "EEXIST") throw busy2();
    throw e;
  }
  try {
    try {
      await create();
      return;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
    const record = /^(\S+) ([1-9]\d*)\s*$/.exec(
      await fs9.readFile(file, "utf8")
    );
    if (!record || !Number.isFinite(Date.parse(record[1]))) throw busy2();
    try {
      process.kill(Number(record[2]), 0);
      throw busy2();
    } catch (e) {
      if (e.code !== "ESRCH") throw busy2();
    }
    if ((await fs9.readdir(p.dirname(file))).some(
      (n) => n.startsWith(".ielts-stage-")
    ))
      throw new UserError(
        "\u4E0A\u6B21\u5B89\u88C5\u4E2D\u65AD\uFF0C\u6682\u5B58\u76EE\u5F55\u5DF2\u4FDD\u7559\u3002\u8BF7\u5148\u6838\u5BF9\u7248\u672C\u6307\u9488\u548C\u5907\u4EFD\uFF0C\u518D\u6E05\u7406\u9057\u7559\u9501\u3002"
      );
    await fs9.unlink(file);
    try {
      await create();
    } catch (e) {
      if (e.code === "EEXIST") throw busy2();
      throw e;
    }
    updateLog("\u5DF2\u63A5\u7BA1\u9000\u51FA\u8FDB\u7A0B\u7559\u4E0B\u7684\u66F4\u65B0\u9501");
  } finally {
    await fs9.rmdir(guard);
  }
}
async function locked(roots, action) {
  const locks = [];
  try {
    for (const root of [...new Set(roots)].sort()) {
      const file = p.join(root, ".ielts-update.lock");
      await acquireLock(file);
      locks.push(file);
    }
    return await action();
  } finally {
    for (const f of locks.reverse()) await fs9.unlink(f);
  }
}
async function hasResourceDbs(dataDir) {
  const split = await Promise.all(
    ["content.db", "vocabulary.db", "dictation.db"].map(
      async (name) => (await stat3(p.join(dataDir, name)))?.isFile()
    )
  );
  if (split.every(Boolean)) return true;
  return Boolean((await stat3(p.join(dataDir, "ielts.db")))?.isFile());
}
function isMissingDbStartError(err) {
  if (err instanceof ServiceStartError) {
    return err.reason === "exit" && err.missingBaseDb;
  }
  return err instanceof Error && /(?:base|active) database not found/i.test(err.message);
}
async function installPackages(paths, packages, service) {
  if (!packages.length || packages.some((x) => x.format === "bundle") && packages.length !== 1 || new Set(packages.map((x) => x.kind)).size !== packages.length || packages.some(
    (x) => !["helper", "resources"].includes(x.kind) || !stable.test(x.version)
  ))
    throw new UserError("\u5B89\u88C5\u5305\u7C7B\u522B\u91CD\u590D\u6216\u7248\u672C\u53F7\u65E0\u6548");
  const { app, data } = await safeRoots(paths);
  return locked([app, data], async () => {
    if (await stat3(p.join(app, "runtime-config.json")))
      throw new UserError(
        "\u8FD9\u662F\u65E7\u542F\u52A8\u5668\u7684\u7A0B\u5E8F\u76EE\u5F55\u3002\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u9009\u62E9\u65B0\u7684\u5916\u90E8\u7A0B\u5E8F\u76EE\u5F55\uFF0C\u518D\u5B89\u88C5\u7A0B\u5E8F\uFF1B\u73B0\u6709\u5B66\u4E60\u6570\u636E\u53EF\u4EE5\u7EE7\u7EED\u4F7F\u7528\u3002"
      );
    const old = await readInstalled(app), ptr = p.join(app, "current.json"), hadPointer = !!await stat3(ptr);
    if (await service.state() === "external")
      throw new UserError("\u7AEF\u53E3\u7531\u5916\u90E8\u670D\u52A1\u5360\u7528\uFF0C\u8BF7\u5148\u624B\u52A8\u505C\u6B62");
    const temps = [], undo = [], prepared = [];
    let stopped = false, starting = false, keep = false;
    try {
      const prepare = async (pkg) => {
        const tmp = await fs9.mkdtemp(
          p.join(pkg.kind === "helper" ? app : data, ".ielts-stage-")
        );
        temps.push(tmp);
        const extracted = await unpack(pkg, tmp);
        if (pkg.format === "bundle") {
          for (const part of await bundleParts(extracted.root, pkg.version))
            await prepare(part);
        } else prepared.push({ pkg, tmp, ...extracted });
      };
      for (const pkg of packages) await prepare(pkg);
      if (packages[0].format === "bundle" && old.resourcesVersion) {
        const i = prepared.findIndex((x) => x.pkg.kind === "resources");
        if (i >= 0 && compareVersions(old.resourcesVersion, prepared[i].pkg.version) >= 0) {
          const dbs = await Promise.all(
            ["content.db", "vocabulary.db", "dictation.db"].map(
              async (name) => stat3(await checkedChild(data, name))
            )
          );
          if (dbs.every((s) => s?.isFile())) prepared.splice(i, 1);
          else if (old.resourcesVersion !== prepared[i].pkg.version)
            throw new UserError(
              "\u5DF2\u5B89\u88C5\u7684\u8D44\u6E90\u7248\u672C\u8F83\u9AD8\u4F46\u6570\u636E\u5E93\u4E0D\u5B8C\u6574\uFF0C\u8BF7\u5355\u72EC\u5BFC\u5165\u5BF9\u5E94\u7248\u672C\u7684\u8D44\u6E90\u5305"
            );
        }
      }
      const owner = await service.state();
      if (owner === "external")
        throw new UserError("\u51FA\u73B0\u5916\u90E8\u670D\u52A1\uFF0C\u8BF7\u5148\u624B\u52A8\u505C\u6B62");
      if (owner === "owned") {
        await service.stop();
        stopped = true;
      }
      const next = { ...old };
      for (const { pkg, tmp, root, files } of prepared) {
        if (pkg.kind === "helper") {
          const release = await checkedChild(app, `releases/${pkg.version}`);
          await fs9.mkdir(p.dirname(release), { recursive: true });
          if (await stat3(release)) {
            const save = p.join(tmp, "old-release");
            await fs9.rename(release, save);
            undo.push(() => fs9.rename(save, release));
          }
          await fs9.rename(root, release);
          undo.push(() => fs9.rename(release, root));
          if (next.version !== pkg.version) {
            next.previousVersion = next.version;
            next.version = pkg.version;
          }
        } else {
          for (const name of files) {
            const dest = await checkedChild(data, name), before = await stat3(dest);
            if (before && (!before.isFile() || before.nlink > 1))
              throw new UserError("\u8D44\u6E90\u76EE\u6807\u4E0D\u662F\u72EC\u7ACB\u666E\u901A\u6587\u4EF6");
            if (name.endsWith(".db")) {
              for (const suffix of ["-wal", "-shm", "-journal"])
                if (await stat3(dest + suffix))
                  throw new UserError(
                    "\u8D44\u6E90\u5E93\u4ECD\u6709 SQLite \u65E5\u5FD7\uFF0C\u8BF7\u5173\u95ED\u6240\u6709\u4F7F\u7528\u5B83\u7684\u7A0B\u5E8F"
                  );
            }
            await fs9.mkdir(p.dirname(dest), { recursive: true });
            const save = p.join(tmp, "before", name);
            if (before) {
              await fs9.mkdir(p.dirname(save), { recursive: true });
              await fs9.copyFile(dest, save, fs9.constants.COPYFILE_FICLONE);
            }
            await fs9.rename(p.join(root, name), dest);
            undo.push(
              before ? () => fs9.rename(save, dest) : () => fs9.unlink(dest)
            );
          }
          next.resourcesVersion = pkg.version;
        }
      }
      if (hadPointer) {
        const prior = await fs9.readFile(ptr);
        await pointer(app, next);
        undo.push(() => pointer(app, prior));
      } else {
        await pointer(app, next);
        undo.push(() => fs9.unlink(ptr));
      }
      if (!next.version) {
        updateLog("\u5B66\u4E60\u8D44\u6E90\u5305\u5DF2\u843D\u76D8\uFF0C\u7B49\u5F85\u5B89\u88C5 Helper \u7A0B\u5E8F\u540E\u542F\u52A8\u670D\u52A1");
        return { started: false, missing: "helper" };
      }
      starting = true;
      try {
        await service.start();
        if (await service.state() !== "owned")
          throw new UserError("\u672A\u80FD\u786E\u8BA4\u65B0\u670D\u52A1\u5F52\u5C5E\uFF0C\u5DF2\u53D6\u6D88\u6FC0\u6D3B");
        updateLog("\u5DF2\u6FC0\u6D3B\u5E76\u542F\u52A8\u670D\u52A1");
        return { started: true };
      } catch (startError) {
        if (!old.version && !stopped && isMissingDbStartError(startError) && !await hasResourceDbs(data)) {
          if (await service.state() === "owned") await service.stop();
          updateLog("Helper \u7A0B\u5E8F\u5DF2\u843D\u76D8\uFF0C\u7B49\u5F85\u5B89\u88C5\u5B66\u4E60\u8D44\u6E90\u5305\u540E\u542F\u52A8\u670D\u52A1");
          return { started: false, missing: "resources" };
        }
        throw startError;
      }
    } catch (error) {
      try {
        if (starting && await service.state() === "owned")
          await service.stop();
        for (const f of undo.reverse()) await f();
        if (stopped) await service.start();
      } catch {
        keep = true;
        throw new RecoveryIncomplete(
          `\u66F4\u65B0\u5931\u8D25\uFF0C\u81EA\u52A8\u6062\u590D\u672A\u5B8C\u6210\uFF1B\u4FDD\u7559\u6062\u590D\u6750\u6599\uFF1A${temps.join("\u3001")}`
        );
      }
      throw error;
    } finally {
      if (!keep)
        for (const t of temps) await fs9.rm(t, { recursive: true, force: true });
    }
  });
}
async function installFromFeed(paths, source, manifest, kinds, service) {
  if (!kinds.length || new Set(kinds).size !== kinds.length)
    throw new UserError("\u8BF7\u9009\u62E9\u8981\u5B89\u88C5\u7684\u7A0B\u5E8F\u6216\u8D44\u6E90\u5305");
  const owner = await service.state();
  if (owner === "external")
    throw new UserError("\u7AEF\u53E3\u7531\u5916\u90E8\u670D\u52A1\u5360\u7528\uFF0C\u8BF7\u5148\u624B\u52A8\u505C\u6B62");
  if (owner === "owned") await service.stop();
  const collect = async (index, packages) => {
    if (index === kinds.length)
      return installPackages(paths, packages, service);
    let result;
    await withDownloadedPackage(source, manifest, kinds[index], async (pkg) => {
      result = await collect(index + 1, [...packages, pkg]);
    });
    return result;
  };
  try {
    return await collect(0, []);
  } catch (e) {
    if (!(e instanceof RecoveryIncomplete) && owner === "owned" && await service.state() === "stopped")
      await service.start();
    throw e;
  }
}
async function rollbackHelper(paths, service) {
  const { app, data } = await safeRoots(paths);
  await locked([app, data], async () => {
    if (await stat3(p.join(app, "runtime-config.json")))
      throw new UserError("\u8BF7\u7528\u65E7\u542F\u52A8\u5668\u56DE\u9000\u65E7\u5B89\u88C5\uFF0C\u6216\u5148\u5207\u6362\u5230\u65B0\u7684\u5916\u90E8\u7A0B\u5E8F\u76EE\u5F55");
    const old = await readInstalled(app);
    if (!old.version || !old.previousVersion)
      throw new UserError("\u6CA1\u6709\u53EF\u56DE\u9000\u7684\u4E0A\u4E00\u7248");
    const entry = await checkedChild(
      app,
      `releases/${old.previousVersion}/terminal/IELTS_Vocab_Helper.py`
    );
    if (!(await stat3(entry))?.isFile())
      throw new UserError("\u4E0A\u4E00\u7248\u672C\u7A0B\u5E8F\u4E0D\u5B8C\u6574");
    const owner = await service.state();
    if (owner === "external") throw new UserError("\u8BF7\u5148\u624B\u52A8\u505C\u6B62\u5916\u90E8\u670D\u52A1");
    if (owner === "owned") await service.stop();
    try {
      await pointer(app, {
        ...old,
        version: old.previousVersion,
        previousVersion: old.version
      });
      await service.start();
      updateLog("\u5DF2\u56DE\u9000\u5E76\u542F\u52A8\u670D\u52A1");
    } catch (e) {
      if (await service.state() === "owned") await service.stop();
      await pointer(app, old);
      if (owner === "owned") await service.start();
      throw e;
    }
  });
}

// src/updater/plugin-self-update.ts
var fs10 = __toESM(require("node:fs/promises"));
var p2 = __toESM(require("node:path"));
var busy = /* @__PURE__ */ new Set();
async function updatePlugin(s, release, pluginDir, reload) {
  if (s.mode === "local") throw new UserError("\u4EC5\u672C\u5730\u6A21\u5F0F\u4E0D\u4E0B\u8F7D\u63D2\u4EF6\u66F4\u65B0");
  if (!stable.test(release.version)) throw new UserError("\u4E0D\u662F\u7A33\u5B9A\u63D2\u4EF6\u7248\u672C");
  const root = await fs10.realpath(pluginDir);
  if (busy.has(root)) throw new UserError("\u63D2\u4EF6\u6B63\u5728\u66F4\u65B0");
  busy.add(root);
  let stage, retain = false;
  try {
    stage = await fs10.mkdtemp(p2.join(root, ".ielts-self-"));
    const backup = p2.join(stage, "before");
    await fs10.mkdir(backup);
    const access = s.mode === "vps" ? vpsAccess(s) : await providerAccess(s, "github", false);
    for (const name of pluginFiles) {
      const old = p2.join(root, name);
      if (!(await fs10.lstat(old)).isFile())
        throw new UserError("\u539F\u63D2\u4EF6\u6587\u4EF6\u4E0D\u662F\u666E\u901A\u6587\u4EF6");
      await download(release.assets[name], access, p2.join(stage, name));
    }
    const manifest = JSON.parse(
      await fs10.readFile(p2.join(stage, "manifest.json"), "utf8")
    );
    const oldManifest = JSON.parse(
      await fs10.readFile(p2.join(root, "manifest.json"), "utf8")
    );
    if (manifest.id !== oldManifest.id || manifest.id !== "ielts-helper" || manifest.version !== release.version)
      throw new UserError("\u65B0\u63D2\u4EF6\u8EAB\u4EFD\u6216\u7248\u672C\u4E0D\u7B26");
    for (const name of pluginFiles)
      await fs10.copyFile(
        p2.join(root, name),
        p2.join(backup, name),
        fs10.constants.COPYFILE_EXCL
      );
    const changed = [];
    let reloading = false;
    try {
      for (const name of pluginFiles) {
        await fs10.rename(p2.join(stage, name), p2.join(root, name));
        changed.push(name);
      }
      reloading = true;
      await reload();
      updateLog("\u63D2\u4EF6\u4E09\u6587\u4EF6\u5DF2\u66F4\u65B0\u5E76\u91CD\u8F7D");
    } catch (e) {
      try {
        for (const name of changed.reverse())
          await fs10.rename(p2.join(backup, name), p2.join(root, name));
      } catch {
        retain = true;
        throw new UserError(`\u63D2\u4EF6\u6062\u590D\u5931\u8D25\uFF1B\u8BF7\u4ECE ${backup} \u6062\u590D\u539F\u4E09\u6587\u4EF6`);
      }
      if (reloading) {
        try {
          await reload();
        } catch {
          throw new UserError("\u539F\u63D2\u4EF6\u6587\u4EF6\u5DF2\u6062\u590D\uFF1B\u8BF7\u624B\u52A8\u91CD\u5F00 Obsidian");
        }
      }
      throw e;
    }
  } finally {
    busy.delete(root);
    if (stage && !retain) await fs10.rm(stage, { recursive: true, force: true });
  }
}

// src/config/resource-status.ts
var import_node_fs8 = require("node:fs");
var import_node_path7 = __toESM(require("node:path"));
var databases = [
  "content.db",
  "vocabulary.db",
  "dictation.db",
  "learning-progress.db"
];
async function resourceStatus(dataDir) {
  assertIsolatedPath(dataDir);
  return Promise.all(
    databases.map(async (name) => {
      try {
        return {
          name,
          present: (await import_node_fs8.promises.stat(import_node_path7.default.join(dataDir, name))).isFile()
        };
      } catch (e) {
        if (e.code === "ENOENT")
          return { name, present: false };
        throw e;
      }
    })
  );
}

// src/ui/settings-tab.ts
function cleanPath(value) {
  return value.trim().replace(/^"(.*)"$/, "$1").trim();
}
function cleanRepo(value) {
  return value.trim().replace(/^https?:\/\/(?:github|gitee)\.com\//i, "").replace(/\.git$/i, "").replace(/\/+$/, "");
}
var HelperSettings = class extends import_obsidian2.PluginSettingTab {
  constructor(app, helper) {
    super(app, helper);
    this.helper = helper;
  }
  draft;
  verified;
  localFiles = [];
  explicitZips = "";
  manualSha = "";
  needFallbackZip = false;
  baseline = "";
  generation = 0;
  hide() {
    if (this.draft && JSON.stringify(this.draft) !== this.baseline)
      new import_obsidian2.Notice("\u672A\u4FDD\u5B58\u7684\u914D\u7F6E\u66F4\u6539\u5DF2\u653E\u5F03");
    this.generation++;
    this.draft = void 0;
    this.verified = void 0;
    this.localFiles = [];
    this.explicitZips = "";
    this.manualSha = "";
    this.needFallbackZip = false;
  }
  display() {
    const generation = ++this.generation;
    const root = this.containerEl;
    root.empty();
    const content = root.createDiv({ cls: "ielts-helper-settings" });
    content.createEl("h2", { cls: "ielts-helper-title", text: "IELTS Helper" });
    const heading = (text2) => content.createEl("h2", { cls: "ielts-helper-section-title", text: text2 });
    const vault = this.helper.config.vaultRoot;
    const fresh = !this.draft;
    this.draft ??= this.helper.profile ? structuredClone(this.helper.profile) : {
      vaultRoot: vault,
      studyRoot: import_node_path8.default.join(vault, "0-IELTS"),
      appRoot: "",
      dataDir: "",
      pythonPath: "",
      port: 8766,
      openBrowserOnStart: true,
      autoUpgradePlugin: false,
      autoCheckUpdates: true,
      updateSource: {
        mode: "vps",
        vpsUrl: "",
        pluginRepo: "Cooper519/obsidian-ielts-helper"
      }
    };
    const p3 = this.draft;
    if (fresh) this.baseline = JSON.stringify(p3);
    const dirty = content.createDiv({ cls: "ielts-helper-dirty" });
    dirty.setAttribute("role", "status");
    const showDirty = () => {
      dirty.textContent = JSON.stringify(p3) !== this.baseline ? "\u6709\u672A\u4FDD\u5B58\u7684\u66F4\u6539" : "";
    };
    content.addEventListener("input", showDirty);
    content.addEventListener("change", showDirty);
    showDirty();
    const prepare = async () => {
      if (!this.helper.profile || JSON.stringify(this.helper.profile) !== JSON.stringify(p3))
        await this.helper.save(p3);
      this.baseline = JSON.stringify(p3);
    };
    const action = (name, description, label, fn, parent = content) => {
      return new import_obsidian2.Setting(parent).setName(name).setDesc(description).addButton(
        (b) => b.setButtonText(label).onClick(async () => {
          b.setDisabled(true);
          try {
            await this.helper.run(fn);
          } finally {
            if (generation === this.generation) this.display();
          }
        })
      );
    };
    heading("\u8FD0\u884C\u72B6\u6001");
    const init = content.createDiv();
    init.hidden = true;
    const online = p3.updateSource.mode !== "local";
    const current = this.helper.profile;
    const service = action(
      "\u5B66\u4E60\u670D\u52A1",
      current ? "\u6B63\u5728\u68C0\u67E5\u2026" : "\u5C1A\u672A\u521D\u59CB\u5316",
      "\u6253\u5F00\u5B66\u4E60\u9875",
      () => this.helper.openStudy()
    );
    service.controlEl.querySelector("button")?.classList.add("mod-cta");
    if (!current) service.settingEl.hidden = true;
    const compatibility = content.createDiv();
    if (this.helper.service)
      void this.helper.service.version().then((v) => {
        if (generation !== this.generation) return;
        service.setDesc(
          v ? `\u8FD0\u884C\u4E2D \xB7 \u7AEF\u53E3 ${current?.port} \xB7 Helper ${v.version}` : "\u672A\u8FD0\u884C"
        );
        if (v)
          service.addButton(
            (b) => b.setButtonText("\u505C\u6B62\u670D\u52A1").onClick(async () => {
              await this.helper.run(() => this.helper.needService().stop());
              if (generation === this.generation) this.display();
            })
          );
        if (v?.pluginUpgradeRequired || v?.pluginUpgradeRecommended || [v?.recommendedPluginVersion, v?.minPluginVersion].some(
          (ver) => ver && compareVersions(this.helper.manifest.version, ver) < 0
        ))
          compatibility.createEl("p", {
            cls: "ielts-helper-warning",
            text: "\u8BF7\u5347\u7EA7 Obsidian \u63D2\u4EF6\u3002\u4F60\u4ECD\u53EF\u6253\u5F00\u5B66\u4E60\u9875\u548C\u542F\u505C\u670D\u52A1\u3002"
          });
      });
    let legacy = "";
    const migration = new import_obsidian2.Setting(init).setName("\u4ECE\u65E7\u7248\u5BFC\u5165\u914D\u7F6E").setDesc(
      "\u5BFC\u5165\u65E7\u7248\u8DEF\u5F84\u5373\u53EF\u7EE7\u7EED\u5B66\u4E60\u3002\u66F4\u65B0\u7A0B\u5E8F\u65F6\u8BF7\u53E6\u9009\u65B0\u76EE\u5F55\uFF0C\u4FDD\u7559\u65E7\u7248\u4F9B\u56DE\u9000\u3002"
    );
    migration.addText(
      (t) => t.setPlaceholder("runtime-config.json \u8DEF\u5F84").onChange((v) => {
        legacy = cleanPath(v);
      })
    );
    migration.addButton(
      (b) => b.setButtonText("\u5BFC\u5165\u914D\u7F6E").onClick(async () => {
        await this.helper.run(async () => {
          const file = legacy || process.env.IELTS_HELPER_LEGACY_CONFIG || p3.appRoot && import_node_path8.default.join(p3.appRoot, "runtime-config.json") || (process.platform === "win32" && process.env.IELTS_HELPER_ISOLATED !== "1" ? import_node_path8.default.join(
            import_node_path8.default.parse(vault).root,
            "Apps",
            "IELTS-Helper",
            "runtime-config.json"
          ) : "");
          if (!file)
            throw new UserError("\u8BF7\u586B\u5199\u65E7\u7248 runtime-config.json \u7684\u5B8C\u6574\u8DEF\u5F84");
          let imported;
          try {
            imported = await importLegacy(file, p3);
          } catch (e) {
            if (e.code === "ENOENT")
              throw new UserError(
                "\u672A\u627E\u5230\u65E7\u914D\u7F6E\uFF0C\u8BF7\u586B\u5199 runtime-config.json \u7684\u5B8C\u6574\u8DEF\u5F84"
              );
            throw e;
          }
          const saved = await this.helper.save(imported);
          new import_obsidian2.Notice(
            saved ? "\u65E7\u7248\u914D\u7F6E\u5DF2\u5BFC\u5165\u5E76\u4FDD\u5B58" : "\u8DEF\u5F84\u5DF2\u5BFC\u5165\uFF0C\u9996\u6B21\u5B89\u88C5\u6210\u529F\u540E\u4FDD\u5B58"
          );
          this.draft = void 0;
          this.display();
        });
      })
    );
    if (online)
      action(
        "\u9996\u6B21\u5728\u7EBF\u5B89\u88C5",
        "\u586B\u597D\u4E0B\u65B9\u8DEF\u5F84\u548C\u66F4\u65B0\u6E90\u540E\uFF0C\u4E0B\u8F7D\u7A0B\u5E8F\u4E0E\u5B66\u4E60\u8D44\u6E90\u3002",
        "\u521D\u59CB\u5316\u5B89\u88C5",
        async () => {
          await prepare();
          await this.helper.installOnline(["helper", "resources"]);
        },
        init
      );
    heading("\u7248\u672C\u4E0E\u66F4\u65B0");
    if (current && online)
      action(
        "\u68C0\u67E5\u66F4\u65B0",
        "\u68C0\u67E5\u5DF2\u4FDD\u5B58\u66F4\u65B0\u6E90\u4E2D\u7684\u7248\u672C\uFF0C\u4E0D\u4F1A\u4E2D\u65AD\u5B66\u4E60\u3002",
        "\u7ACB\u5373\u68C0\u67E5",
        async () => {
          this.verified = void 0;
          await this.helper.checkUpdates();
        }
      );
    const pluginRow = online ? action(
      "Obsidian \u63D2\u4EF6",
      "",
      "\u5347\u7EA7\u63D2\u4EF6",
      () => this.helper.upgradePlugin(true, { ...p3.updateSource })
    ) : new import_obsidian2.Setting(content).setName("Obsidian \u63D2\u4EF6");
    const toggles = (key, label, desc = "") => {
      new import_obsidian2.Setting(content).setName(label).setDesc(desc).addToggle(
        (t) => t.setValue(p3[key] ?? key === "autoCheckUpdates").onChange((v) => {
          p3[key] = v;
          showDirty();
        })
      );
    };
    if (online) {
      toggles("autoCheckUpdates", "\u81EA\u52A8\u68C0\u67E5\u66F4\u65B0");
      toggles(
        "autoUpgradePlugin",
        "\u81EA\u52A8\u5347\u7EA7\u63D2\u4EF6",
        "\u4EC5\u5347\u7EA7\u63D2\u4EF6\uFF1BHelper \u548C\u8D44\u6E90\u4ECD\u7531\u4F60\u624B\u52A8\u66F4\u65B0\u3002"
      );
    }
    const programRow = online ? action("IELTS Helper \u7A0B\u5E8F", "", "\u66F4\u65B0 Helper", async () => {
      await prepare();
      await this.helper.installOnline(["helper"]);
    }) : new import_obsidian2.Setting(content).setName("IELTS Helper \u7A0B\u5E8F");
    const resourceRow = online ? action("\u5B66\u4E60\u8D44\u6E90\u5305", "", "\u66F4\u65B0\u8D44\u6E90", async () => {
      await prepare();
      await this.helper.installOnline(["resources"]);
    }) : new import_obsidian2.Setting(content).setName("\u5B66\u4E60\u8D44\u6E90\u5305");
    let installed = "\u672A\u5B89\u88C5", resources = "\u672A\u5B89\u88C5", dbStatus = "";
    const showVersions = () => {
      const applied = JSON.stringify(current?.updateSource) === JSON.stringify(p3.updateSource);
      const latest = this.verified ?? (applied ? this.helper.feed : void 0);
      const verifiedPlugin = this.verified && "plugin" in this.verified ? this.verified.plugin : void 0;
      const plugin = verifiedPlugin ?? (applied ? this.helper.pluginRelease : void 0);
      const text2 = (v, latest2) => online ? `\u5F53\u524D ${v} \xB7 \u6700\u65B0 ${latest2 || "\u672A\u68C0\u67E5"}` : `\u5F53\u524D ${v}`;
      pluginRow.setDesc(text2(this.helper.manifest.version, plugin?.version));
      programRow.setDesc(text2(installed, latest?.helper.version));
      resourceRow.setDesc(
        [text2(resources, latest?.resources.version), dbStatus].filter(Boolean).join(" \xB7 ")
      );
    };
    showVersions();
    if (current) {
      void readInstalled(current.appRoot).then((v) => {
        if (generation !== this.generation) return;
        init.hidden = !!v.version;
        installed = v.version || "\u672A\u5B89\u88C5";
        resources = v.resourcesVersion || "\u672A\u77E5";
        if (v.previousVersion)
          programRow.addButton(
            (b) => b.setButtonText(`\u56DE\u9000\u81F3 ${v.previousVersion}`).onClick(async () => {
              await this.helper.run(() => this.helper.rollback());
              if (generation === this.generation) this.display();
            })
          );
        showVersions();
      }).catch(() => {
        if (generation === this.generation) {
          installed = "\u65E0\u6CD5\u8BFB\u53D6\u7248\u672C";
          showVersions();
        }
      });
      void resourceStatus(current.dataDir).then((rows) => {
        if (generation !== this.generation) return;
        const missing = rows.filter((r) => !r.present).map((r) => r.name);
        dbStatus = missing.length ? `\u7F3A\u5C11 ${missing.join("\u3001")}` : "\u6570\u636E\u5E93 4/4 \u5DF2\u5C31\u7EEA";
        showVersions();
      }).catch(() => {
        if (generation === this.generation) {
          dbStatus = "\u65E0\u6CD5\u8BFB\u53D6\u6570\u636E\u5E93\u76EE\u5F55";
          showVersions();
        }
      });
    } else init.hidden = false;
    const offline = content.createEl("details", { cls: "ielts-helper-local" });
    offline.open = !online || this.localFiles.length > 0 || Boolean(this.explicitZips);
    offline.createEl("summary", { text: "\u5BFC\u5165\u672C\u5730 ZIP" });
    const localBaseDesc = "\u652F\u6301 Helper \u7A0B\u5E8F\u5305\uFF08\u542B ielts-helper-light-X.Y.Z.zip\uFF09\u3001\u8D44\u6E90\u5305\u4E00\u8D77\u6216\u5206\u6B65\u5BFC\u5165\uFF1B\u65E7\u7248\u5B8C\u6574\u5305\u8BF7\u5355\u72EC\u9009\u62E9\u3002\u81EA\u52A8\u8BFB\u53D6\u540C\u76EE\u5F55 checksums*.txt / SHA256SUMS / .sha256\uFF0C\u4E5F\u53EF\u5355\u5305\u624B\u586B SHA-256\u3002";
    const localDesc = () => {
      const names = this.localFiles.map(
        (f) => f.file ? import_node_path8.default.basename(f.file) : "\u672A\u8BC6\u522B\u8DEF\u5F84"
      );
      return names.length ? `\u5DF2\u9009\uFF1A${names.join("\u3001")}\u3002${localBaseDesc}` : localBaseDesc;
    };
    const local = new import_obsidian2.Setting(offline).setName("\u9009\u62E9\u5B89\u88C5\u5305").setDesc(localDesc());
    const input = local.controlEl.createEl("input", {
      attr: { type: "file", accept: ".zip", multiple: "" }
    });
    input.onchange = () => {
      let getPath;
      try {
        const electron = require("electron");
        getPath = electron.webUtils?.getPathForFile;
      } catch {
        getPath = void 0;
      }
      this.localFiles = Array.from(input.files || []).map((f) => {
        let resolved = "";
        try {
          resolved = getPath?.(f) || "";
        } catch {
          resolved = "";
        }
        return {
          file: resolved || f.path || ""
        };
      });
      this.needFallbackZip = this.localFiles.some((f) => !f.file);
      fallback.settingEl.hidden = !this.needFallbackZip;
      this.explicitZips = "";
      local.setDesc(localDesc());
    };
    local.addText(
      (t) => t.setValue(this.manualSha).setPlaceholder("\u53EF\u9009\uFF1A\u5355\u5305 SHA-256").onChange((v) => {
        this.manualSha = v.trim();
      })
    );
    local.addButton(
      (b) => b.setButtonText("\u5BFC\u5165 ZIP").onClick(async () => {
        b.setDisabled(true);
        try {
          await this.helper.run(async () => {
            const explicit = this.explicitZips.split(/\r?\n/).map(cleanPath).filter(Boolean).map((file) => ({ file }));
            const selected = explicit.length ? explicit : this.localFiles;
            if (!selected.length) throw new UserError("\u8BF7\u5148\u9009\u62E9 ZIP \u6587\u4EF6");
            if (selected.some((f) => !f.file))
              throw new UserError("\u65E0\u6CD5\u8BFB\u53D6\u6587\u4EF6\u4F4D\u7F6E\uFF0C\u8BF7\u5728\u4E0B\u65B9\u586B\u5199\u5B8C\u6574\u8DEF\u5F84");
            if (this.manualSha && selected.length !== 1)
              throw new UserError("\u624B\u52A8\u6458\u8981\u4EC5\u652F\u6301\u5355\u5305\u5BFC\u5165");
            await prepare();
            const installed2 = await this.helper.installLocal(
              selected.map((f) => ({ ...f, sha256: this.manualSha || void 0 }))
            );
            if (installed2) {
              this.localFiles = [];
              this.explicitZips = "";
              this.manualSha = "";
              this.needFallbackZip = false;
            }
          });
        } finally {
          if (generation === this.generation) this.display();
        }
      })
    );
    const fallback = new import_obsidian2.Setting(offline).setName("ZIP \u5B8C\u6574\u8DEF\u5F84").setDesc("\u65E0\u6CD5\u8BFB\u53D6\u6240\u9009\u6587\u4EF6\u4F4D\u7F6E\uFF0C\u6BCF\u884C\u8F93\u5165\u4E00\u4E2A ZIP \u5B8C\u6574\u8DEF\u5F84\uFF08\u53EF\u540C\u65F6\u586B\u7A0B\u5E8F\u5305\u4E0E\u8D44\u6E90\u5305\uFF09\u3002");
    const fallbackArea = fallback.controlEl.createEl("textarea", {
      attr: {
        placeholder: "\u6BCF\u884C\u4E00\u4E2A ZIP \u5B8C\u6574\u8DEF\u5F84\uFF0C\u652F\u6301\u76F4\u63A5\u7C98\u8D34\u5E26\u5F15\u53F7\u7684\u8DEF\u5F84"
      }
    });
    fallbackArea.value = this.explicitZips;
    fallbackArea.oninput = () => {
      this.explicitZips = fallbackArea.value;
    };
    fallback.settingEl.hidden = !this.needFallbackZip && !this.explicitZips;
    heading("\u66F4\u65B0\u6E90\u4E0E\u672C\u673A\u8DEF\u5F84");
    new import_obsidian2.Setting(content).setName("\u66F4\u65B0\u6E90").addDropdown(
      (d) => d.addOptions({
        vps: "VPS \u8BA2\u9605\uFF08\u63A8\u8350\uFF09",
        github: "GitHub \u76F4\u8FDE",
        gitee: "Gitee \u76F4\u8FDE",
        local: "\u4EC5\u672C\u5730 ZIP"
      }).setValue(p3.updateSource.mode).onChange((v) => {
        p3.updateSource.mode = v;
        this.verified = void 0;
        this.display();
      })
    );
    const sourceText = (key, label, secret = false, changed, placeholder = "") => {
      const row = new import_obsidian2.Setting(content).setName(label);
      if (key === "vpsToken")
        row.setDesc(
          "\u7528\u4E8E\u67E5\u8BE2\u7248\u672C\u548C\u4E0B\u8F7D\u66F4\u65B0\uFF0C\u7531\u8BA2\u9605\u670D\u52A1\u7BA1\u7406\u5458\u63D0\u4F9B\u3002\u5BC6\u94A5\u53EA\u4FDD\u5B58\u5728\u672C\u673A\uFF1B\u672C\u5730\u5B66\u4E60\u65E0\u9700\u586B\u5199\u3002"
        );
      if (key === "githubToken" || key === "giteeToken")
        row.setDesc(
          "\u4F18\u5148\u4F7F\u7528\u672C\u673A Git \u51ED\u636E\uFF1B\u65E0\u53EF\u7528\u51ED\u636E\u6216\u6743\u9650\u4E0D\u8DB3\u65F6\u81EA\u52A8\u56DE\u843D\u6B64\u5904\u4EE4\u724C\u3002"
        );
      row.addText((t) => {
        if (placeholder) t.setPlaceholder(placeholder);
        t.setValue(p3.updateSource[key] || "").onChange((v) => {
          const isRepo = key === "githubRepo" || key === "giteeRepo" || key === "pluginRepo";
          p3.updateSource[key] = isRepo ? cleanRepo(v) : v.trim();
          changed?.();
        });
        if (secret) {
          t.inputEl.type = "password";
          t.inputEl.autocomplete = "off";
        }
      });
    };
    if (p3.updateSource.mode === "vps") {
      let revision = 0;
      const hint = "\u4F7F\u7528 HTTPS \u6839\u5730\u5740\u6216 /manifest.json\uFF1B\u9A8C\u8BC1\u53EA\u8BFB\u53D6\u7248\u672C\uFF0C\u4E0D\u4E0B\u8F7D\u3002";
      const changed = () => {
        revision++;
        this.verified = void 0;
        row.setDesc(hint);
        showVersions();
      };
      sourceText(
        "vpsUrl",
        "VPS HTTPS \u5730\u5740",
        false,
        changed,
        "https://feed.example.com/manifest.json"
      );
      sourceText("vpsToken", "VPS \u8BBF\u95EE\u5BC6\u94A5", true, changed);
      const row = new import_obsidian2.Setting(content).setName("\u8BA2\u9605\u6E05\u5355").setDesc(hint);
      row.descEl.setAttribute("aria-live", "polite");
      row.addButton(
        (b) => b.setButtonText("\u6D4B\u8BD5\u8FDE\u63A5").onClick(async () => {
          const current2 = revision;
          const show = (text2) => {
            if (current2 === revision && generation === this.generation)
              row.setDesc(text2);
          };
          b.setDisabled(true);
          this.verified = void 0;
          showVersions();
          show("\u6B63\u5728\u8BFB\u53D6\u8BA2\u9605\u6E05\u5355\u2026");
          try {
            const feed = await getManifest({ ...p3.updateSource }, true);
            if (current2 !== revision || generation !== this.generation) return;
            this.verified = feed;
            showVersions();
            const { plugin, helper, resources: resources2 } = feed;
            show(
              `\u63D2\u4EF6 ${plugin.version} \xB7 Helper ${helper.version} \xB7 \u8D44\u6E90 ${resources2.version}`
            );
          } catch (e) {
            show(
              e instanceof UserError ? e.message : "\u65E0\u6CD5\u9A8C\u8BC1\uFF1A\u8BF7\u68C0\u67E5 HTTPS \u8BA2\u9605\u94FE\u63A5\u3001\u5BC6\u94A5\u3001\u7F51\u7EDC\u4EE3\u7406\u4E0E\u8BC1\u4E66\u3002"
            );
          } finally {
            b.setDisabled(false);
          }
        })
      );
    }
    if (p3.updateSource.mode === "github" || p3.updateSource.mode === "gitee") {
      const provider = p3.updateSource.mode;
      let revision = 0;
      const hint = "\u9A8C\u8BC1\u53EA\u8BFB\u53D6\u7A0B\u5E8F\u4E0E\u8D44\u6E90 Release \u5217\u8868\uFF0C\u4E0D\u4E0B\u8F7D\u9644\u4EF6\u3002";
      const changed = () => {
        revision++;
        this.verified = void 0;
        testRow.setDesc(hint);
        showVersions();
      };
      sourceText(
        provider === "github" ? "githubRepo" : "giteeRepo",
        "\u79C1\u6709\u4ED3\u5E93",
        false,
        changed,
        "\u6240\u6709\u8005/\u4ED3\u5E93\uFF08\u5982 owner/ielts-helper\uFF09"
      );
      sourceText(
        provider === "github" ? "githubToken" : "giteeToken",
        "\u53EA\u8BFB Token",
        true,
        changed
      );
      const testRow = new import_obsidian2.Setting(content).setName("\u76F4\u8FDE\u6D4B\u8BD5").setDesc(hint);
      testRow.descEl.setAttribute("aria-live", "polite");
      testRow.addButton(
        (b) => b.setButtonText("\u6D4B\u8BD5\u8FDE\u63A5").onClick(async () => {
          const current2 = revision;
          const show = (text2) => {
            if (current2 === revision && generation === this.generation)
              testRow.setDesc(text2);
          };
          b.setDisabled(true);
          this.verified = void 0;
          showVersions();
          show("\u6B63\u5728\u68C0\u67E5\u79C1\u6709\u4ED3 Release\u2026");
          try {
            const feed = await getPackageFeed({ ...p3.updateSource }, true);
            if (current2 !== revision || generation !== this.generation) return;
            this.verified = feed;
            showVersions();
            show(
              `Helper ${feed.helper.version} \xB7 \u8D44\u6E90 ${feed.resources.version}`
            );
          } catch (e) {
            show(
              e instanceof UserError ? e.message : "\u65E0\u6CD5\u8FDE\u63A5\u4ED3\u5E93\uFF1A\u8BF7\u68C0\u67E5\u4ED3\u5E93\u540D\u3001Token \u6743\u9650\u4E0E\u7F51\u7EDC\u4EE3\u7406\u3002"
            );
          } finally {
            b.setDisabled(false);
          }
        })
      );
      action(
        "Git \u51ED\u636E\u7BA1\u7406\u5668",
        "\u8BFB\u53D6\u7CFB\u7EDF\u4E2D\u4FDD\u5B58\u7684\u4EE4\u724C\u3002",
        "\u8BFB\u53D6 Git \u51ED\u636E",
        async () => {
          const token = await getGcmToken(provider);
          if (!token) {
            new import_obsidian2.Notice("\u672A\u627E\u5230\u53EF\u7528\u7684 Git \u51ED\u636E");
            return;
          }
          p3.updateSource[provider === "github" ? "githubToken" : "giteeToken"] = token.trim();
          new import_obsidian2.Notice("\u4EE4\u724C\u5DF2\u586B\u5165\u8868\u5355\uFF0C\u8BF7\u4FDD\u5B58\u914D\u7F6E");
        }
      );
      sourceText(
        "pluginRepo",
        "\u516C\u5F00\u63D2\u4EF6\u4ED3\u5E93",
        false,
        void 0,
        "Cooper519/obsidian-ielts-helper"
      );
    }
    const placeholders = {
      appRoot: "\u586B\u5199\u7B14\u8BB0\u5E93\u5916\u7684\u7A0B\u5E8F\u76EE\u5F55\u7EDD\u5BF9\u8DEF\u5F84",
      dataDir: "\u586B\u5199\u7B14\u8BB0\u5E93\u5916\u7684\u6570\u636E\u76EE\u5F55\u7EDD\u5BF9\u8DEF\u5F84\uFF0C\u4E0E\u7A0B\u5E8F\u76EE\u5F55\u5206\u5F00",
      studyRoot: import_node_path8.default.join(vault, "0-IELTS"),
      pythonPath: process.platform === "win32" ? "\u70B9\u51FB\u53F3\u4FA7\u81EA\u52A8\u68C0\u6D4B\u6216\u586B python.exe \u5B8C\u6574\u8DEF\u5F84" : "\u70B9\u51FB\u53F3\u4FA7\u81EA\u52A8\u68C0\u6D4B\u6216\u586B python3 \u5B8C\u6574\u8DEF\u5F84"
    };
    for (const [key, label] of [
      ["appRoot", "\u5916\u90E8\u7A0B\u5E8F\u76EE\u5F55"],
      ["dataDir", "\u5916\u90E8\u6570\u636E\u76EE\u5F55"],
      ["studyRoot", "\u5B66\u4E60\u76EE\u5F55"],
      ["pythonPath", "Python \u89E3\u91CA\u5668"]
    ]) {
      const row = new import_obsidian2.Setting(content).setName(label);
      row.addText((t) => {
        t.setPlaceholder(placeholders[key]).setValue(p3[key]).onChange((v) => {
          p3[key] = cleanPath(v);
        });
      });
      if (key === "pythonPath")
        row.addButton(
          (b) => b.setButtonText("\u81EA\u52A8\u68C0\u6D4B").onClick(async () => {
            await this.helper.run(async () => {
              p3.pythonPath = (await this.helper.detectPython()).path;
              if (generation === this.generation) this.display();
            });
          })
        );
    }
    const portRow = new import_obsidian2.Setting(content).setName("\u670D\u52A1\u7AEF\u53E3");
    portRow.addText(
      (t) => t.setValue(Number.isFinite(p3.port) ? String(p3.port) : "").onChange((v) => {
        p3.port = /^\d+$/.test(v) ? Number(v) : NaN;
        const ok = Number.isInteger(p3.port) && p3.port >= 1024 && p3.port <= 65535;
        portRow.setDesc(ok ? "" : "\u8BF7\u8F93\u5165 1024\u201365535 \u4E4B\u95F4\u7684\u6574\u6570");
        t.inputEl.setAttribute("aria-invalid", String(!ok));
      })
    );
    toggles("openBrowserOnStart", "\u5B89\u88C5\u6216\u66F4\u65B0\u540E\u81EA\u52A8\u6253\u5F00\u5B66\u4E60\u9875");
    action(
      "\u4FDD\u5B58\u672C\u673A\u914D\u7F6E",
      "\u8DEF\u5F84\u548C\u5BC6\u94A5\u53EA\u4FDD\u5B58\u5728\u672C\u673A\uFF0C\u4E0D\u5199\u5165\u7B14\u8BB0\u5E93\u3002",
      "\u4FDD\u5B58",
      async () => {
        const saved = await this.helper.save(p3);
        this.baseline = JSON.stringify(p3);
        new import_obsidian2.Notice(saved ? "\u914D\u7F6E\u5DF2\u4FDD\u5B58" : "\u914D\u7F6E\u5DF2\u6682\u5B58\uFF0C\u9996\u6B21\u5B89\u88C5\u6210\u529F\u540E\u4FDD\u5B58");
      }
    );
  }
};

// src/ui/confirm-modal.ts
var import_obsidian3 = require("obsidian");
var ConfirmModal = class _ConfirmModal extends import_obsidian3.Modal {
  constructor(app, title, message, resolve) {
    super(app);
    this.title = title;
    this.message = message;
    this.resolve = resolve;
  }
  accepted = false;
  onOpen() {
    this.contentEl.addClass("ielts-helper-modal");
    this.contentEl.createEl("h2", { text: this.title });
    this.contentEl.createEl("p", { text: this.message });
    const buttons = this.contentEl.createDiv({ cls: "ielts-helper-toolbar" });
    buttons.createEl("button", { text: "\u53D6\u6D88" }).onclick = () => this.close();
    buttons.createEl("button", { text: "\u786E\u8BA4\u7EE7\u7EED", cls: "mod-cta" }).onclick = () => {
      this.accepted = true;
      this.close();
    };
  }
  onClose() {
    this.contentEl.empty();
    this.resolve(this.accepted);
  }
  static ask(app, title, message) {
    return new Promise(
      (resolve) => new _ConfirmModal(app, title, message, resolve).open()
    );
  }
};

// src/ui/onboarding-modal.ts
var import_obsidian4 = require("obsidian");
var OnboardingModal = class extends import_obsidian4.Modal {
  constructor(app, helper) {
    super(app);
    this.helper = helper;
  }
  settings;
  onOpen() {
    this.contentEl.addClass("ielts-helper-modal");
    this.settings = new HelperSettings(this.app, this.helper);
    this.settings.containerEl = this.contentEl;
    this.settings.display();
  }
  onClose() {
    this.settings?.hide();
    this.contentEl.empty();
  }
};

// src/main.ts
var IELTSPlugin = class extends import_obsidian5.Plugin {
  profile;
  config;
  service;
  feed;
  pluginRelease;
  status;
  busy = false;
  saving = false;
  routeBusy = false;
  alive = true;
  onboarding;
  async onload() {
    const adapter = this.app.vault.adapter;
    if (!(adapter instanceof import_obsidian5.FileSystemAdapter)) {
      new import_obsidian5.Notice("IELTS Helper \u4EC5\u652F\u6301\u684C\u9762\u672C\u5730 Vault");
      return;
    }
    this.config = new MachineConfig(adapter.getBasePath());
    try {
      this.profile = await this.config.load();
      if (this.profile)
        this.service = new ServiceManager(this.profile, this.manifest.version);
    } catch {
      new import_obsidian5.Notice("\u672C\u673A\u914D\u7F6E\u65E0\u6548\uFF0C\u8BF7\u68C0\u67E5 Vault \u5916 config.json");
    }
    this.registerView(DASHBOARD, (leaf) => new DashboardView(leaf, this));
    this.registerEvent(
      this.app.workspace.on("css-change", () => {
        for (const leaf of this.app.workspace.getLeavesOfType(DASHBOARD))
          if (leaf.view instanceof DashboardView) void leaf.view.refresh();
      })
    );
    this.addSettingTab(new HelperSettings(this.app, this));
    this.addRibbonIcon(
      "rocket",
      "\u6253\u5F00 IELTS Helper",
      () => void this.run(() => this.openStudy())
    );
    this.addRibbonIcon(
      "bar-chart",
      "\u6253\u5F00 IELTS \u4EEA\u8868\u76D8",
      () => void this.openDashboard()
    );
    const commands = [
      ["open-terminal", "\u6253\u5F00 IELTS Helper \u9996\u9875", () => this.openStudy()],
      ["open-vocabulary-center", "\u6253\u5F00\u8BCD\u6C47\u4E2D\u5FC3", () => this.openStudy(true)],
      [
        "stop-service",
        "\u505C\u6B62 IELTS Helper \u540E\u53F0\u670D\u52A1",
        () => this.needService().stop()
      ],
      ["open-dashboard", "\u6253\u5F00 IELTS \u4EEA\u8868\u76D8", () => this.openDashboard()],
      [
        "route-inbox",
        "\u5206\u914D\u6570\u636E\u5E93\u5F85\u5904\u7406\u8BCD\u5230\u4ECA\u65E5 Topic",
        () => this.routeInbox()
      ],
      [
        "check-updates",
        "\u68C0\u67E5\u63D2\u4EF6\u4E0E IELTS Helper \u66F4\u65B0",
        () => this.checkUpdates()
      ]
    ];
    for (const [id, name, action] of commands)
      this.addCommand({ id, name, callback: () => void this.run(action) });
    this.status = this.addStatusBarItem();
    this.status.addClass("ielts-helper-status");
    this.registerDomEvent(
      this.status,
      "click",
      () => void this.run(() => this.openStudy())
    );
    this.registerDomEvent(this.status, "contextmenu", (e) => {
      e.preventDefault();
      const menu = new import_obsidian5.Menu();
      for (const [title, action] of [
        ["\u6253\u5F00\u9996\u9875", () => this.openStudy()],
        ["\u6253\u5F00\u8BCD\u6C47\u4E2D\u5FC3", () => this.openStudy(true)],
        ["\u505C\u6B62\u670D\u52A1", () => this.needService().stop()],
        ["\u6253\u5F00\u8BBE\u7F6E", async () => this.openSettings()]
      ])
        menu.addItem(
          (item) => item.setTitle(title).onClick(() => void this.run(action))
        );
      menu.showAtMouseEvent(e);
    });
    await this.refreshStatus();
    this.registerInterval(
      window.setInterval(() => void this.refreshStatus(), 15e3)
    );
    if (!this.profile) {
      this.onboarding = new OnboardingModal(this.app, this);
      this.onboarding.open();
    } else if (this.profile.autoCheckUpdates !== false && this.profile.updateSource.mode !== "local")
      void this.checkUpdates(false).catch(() => {
      });
  }
  onunload() {
    this.alive = false;
    this.onboarding?.close();
    this.service?.dispose();
  }
  needProfile() {
    if (!this.profile)
      throw new UserError("\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u521D\u59CB\u5316\u6216\u63A5\u7BA1\u672C\u673A\u5B89\u88C5");
    return this.profile;
  }
  needService() {
    this.needProfile();
    if (!this.service) throw new UserError("\u670D\u52A1\u7BA1\u7406\u5668\u5C1A\u672A\u521D\u59CB\u5316");
    return this.service;
  }
  async api(route, body) {
    return localApi(this.needProfile().port, route, body);
  }
  async run(action) {
    try {
      await action();
    } catch (error) {
      new import_obsidian5.Notice(
        userMessage(error),
        8e3
      );
      log("\u64CD\u4F5C\u672A\u5B8C\u6210");
    } finally {
      await this.refreshStatus();
    }
  }
  openSettings() {
    const app = this.app;
    app.setting.open();
    app.setting.openTabById(this.manifest.id);
  }
  async save(p3) {
    validateProfile(p3);
    if (this.busy)
      throw new UserError("\u6B63\u5728\u6267\u884C\u5B89\u88C5\u6216\u66F4\u65B0\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u540E\u518D\u4FDD\u5B58\u914D\u7F6E");
    if (this.saving) throw new UserError("\u6B63\u5728\u4FDD\u5B58\u914D\u7F6E\uFF0C\u8BF7\u7A0D\u5019");
    this.saving = true;
    const prev = this.service;
    let locked2 = false;
    try {
      if (prev && (prev.hasOwnedProcess() || await prev.state() === "owned"))
        throw new UserError("\u4FEE\u6539\u914D\u7F6E\u524D\u8BF7\u5148\u505C\u6B62\u5F53\u524D\u5B66\u4E60\u670D\u52A1");
      if (this.busy)
        throw new UserError("\u6B63\u5728\u6267\u884C\u5B89\u88C5\u6216\u66F4\u65B0\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u540E\u518D\u4FDD\u5B58\u914D\u7F6E");
      prev?.beginReplace();
      locked2 = Boolean(prev);
      const persisted = !!(await readInstalled(p3.appRoot)).version;
      if (persisted) await this.config.save(p3);
      prev?.dispose();
      this.profile = structuredClone(p3);
      this.service = new ServiceManager(this.profile, this.manifest.version);
      this.feed = void 0;
      this.pluginRelease = void 0;
      log(persisted ? "\u672C\u673A\u914D\u7F6E\u5DF2\u4FDD\u5B58" : "\u9996\u6B21\u5B89\u88C5\u914D\u7F6E\u5DF2\u6682\u5B58");
      return persisted;
    } finally {
      if (locked2) prev?.endReplace();
      this.saving = false;
    }
  }
  async openStudy(vocabulary = false) {
    await this.needService().start();
    const version = await this.needService().version();
    if (version?.serviceIdentity?.dataRoot && version.serviceIdentity.vaultRoot)
      assertServiceContext(this.needProfile(), version);
    const url = `http://127.0.0.1:${this.needProfile().port}/${vocabulary ? "vocabulary-center.html" : ""}`;
    const { shell } = require("electron");
    await shell.openExternal(url);
  }
  async openDashboard() {
    let leaf = this.app.workspace.getLeavesOfType(DASHBOARD)[0];
    if (!leaf) {
      leaf = this.app.workspace.getLeaf("tab");
      await leaf.setViewState({ type: DASHBOARD, active: true });
    }
    await this.app.workspace.revealLeaf(leaf);
  }
  studyPrefix() {
    return this.profile && import_node_path9.default.relative(this.profile.vaultRoot, this.profile.studyRoot).split(import_node_path9.default.sep).join("/");
  }
  async routeInbox() {
    if (this.routeBusy) throw new UserError("\u6B63\u5728\u5206\u914D\u5F85\u5904\u7406\u8BCD\uFF0C\u8BF7\u7A0D\u5019");
    this.routeBusy = true;
    try {
      await this.needService().start();
      const version = await this.needService().version();
      assertServiceContext(this.needProfile(), version);
      if (version?.pluginUpgradeRequired || version?.minPluginVersion && compareVersions(
        this.manifest.version,
        version.minPluginVersion
      ) < 0)
        throw new UserError(
          "\u8BF7\u5148\u5347\u7EA7\u63D2\u4EF6\u4EE5\u4F7F\u7528 inbox \u5206\u914D\uFF1B\u5B66\u4E60\u9875\u4ECD\u53EF\u6B63\u5E38\u6253\u5F00"
        );
      const file = this.app.vault.getFileByPath(
        [this.studyPrefix(), "vocabulary/00-Study-Plan.md"].filter(Boolean).join("/")
      );
      if (!file) throw new UserError("\u672A\u627E\u5230 Study-Plan");
      const day = parseStudyPlan(await this.app.vault.read(file));
      if (!day?.topics.length)
        throw new UserError("Study-Plan \u4E2D\u672A\u627E\u5230\u5F53\u524D Day Topic");
      const result = await this.api("/api/vocabulary/route-inbox", { topic_id: day.topics[0].id });
      if (!result.ok) throw new UserError("\u6570\u636E\u5E93\u5F85\u5904\u7406\u8BCD\u5206\u914D\u5931\u8D25");
      new import_obsidian5.Notice(
        `\u5DF2\u5206\u914D ${result.moved || 0} \u4E2A\u8BCD\uFF0C\u8DF3\u8FC7 ${result.skipped || 0} \u2192 ${day.topics[0].id}\uFF08Day ${day.day}\uFF09`
      );
    } finally {
      this.routeBusy = false;
    }
  }
  async checkUpdates(interactive = true) {
    const p3 = this.needProfile();
    if (p3.updateSource.mode === "vps") {
      const feed = await getManifest(p3.updateSource, interactive);
      this.feed = feed;
      this.pluginRelease = feed.plugin;
    } else if (p3.updateSource.mode === "local") {
      if (interactive) new import_obsidian5.Notice("\u4EC5\u672C\u5730 ZIP \u6A21\u5F0F\u4E0D\u68C0\u67E5\u5728\u7EBF\u7248\u672C");
      return;
    } else {
      const [programs, plugin] = await Promise.allSettled([
        getPackageFeed(p3.updateSource),
        getPluginRelease(p3.updateSource)
      ]);
      this.feed = programs.status === "fulfilled" ? programs.value : void 0;
      this.pluginRelease = plugin.status === "fulfilled" ? plugin.value : void 0;
      if (!this.feed && !this.pluginRelease)
        throw programs.status === "rejected" ? programs.reason : plugin;
      if (interactive && (!this.feed || !this.pluginRelease))
        new import_obsidian5.Notice(
          this.feed ? "\u5DF2\u68C0\u67E5 Helper \u548C\u8D44\u6E90\uFF1B\u516C\u5F00\u63D2\u4EF6\u4ED3\u6682\u4E0D\u53EF\u7528" : "\u5DF2\u68C0\u67E5\u63D2\u4EF6\uFF1BHelper \u548C\u8D44\u6E90\u672A\u80FD\u68C0\u67E5"
        );
    }
    if (interactive && this.feed && this.pluginRelease)
      new import_obsidian5.Notice("\u7248\u672C\u68C0\u67E5\u5B8C\u6210\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u9875\u67E5\u770B");
    if (!interactive && p3.autoUpgradePlugin && this.pluginRelease && compareVersions(
      this.pluginRelease.version,
      this.manifest.version
    ) > 0)
      await this.upgradePlugin(false);
    await this.refreshStatus();
  }
  async exclusive(action) {
    if (this.saving) throw new UserError("\u6B63\u5728\u4FDD\u5B58\u914D\u7F6E\uFF0C\u8BF7\u7A0D\u5019\u91CD\u8BD5");
    if (this.busy) throw new UserError("\u6B63\u5728\u6267\u884C\u53E6\u4E00\u9879\u5B89\u88C5\u6216\u66F4\u65B0");
    this.busy = true;
    const progress = new import_obsidian5.Notice("\u6B63\u5728\u6821\u9A8C\u5E76\u6267\u884C\u64CD\u4F5C\uFF0C\u8BF7\u52FF\u5173\u95ED Obsidian\u2026", 0);
    try {
      await action();
    } finally {
      progress.hide();
      this.busy = false;
    }
  }
  paths() {
    const p3 = this.needProfile();
    return { appRoot: p3.appRoot, dataDir: p3.dataDir, vaultRoot: p3.vaultRoot };
  }
  async installOnline(kinds) {
    if (!await ConfirmModal.ask(
      this.app,
      "\u5B89\u88C5 / \u66F4\u65B0",
      "\u8BF7\u5148\u4FDD\u5B58\u5B66\u4E60\u8FDB\u5EA6\u3002\u5C06\u505C\u6B62\u672C\u63D2\u4EF6\u670D\u52A1\uFF0C\u518D\u4E0B\u8F7D\u3001\u6821\u9A8C\u5E76\u5B89\u88C5\uFF1B\u5931\u8D25\u6062\u590D\u65E7\u7248\uFF0C\u4FDD\u7559\u4E0A\u4E00\u7A0B\u5E8F\u7248\u672C\u3002"
    ))
      return;
    await this.exclusive(async () => {
      const p3 = this.needProfile();
      const feed = await getPackageFeed(p3.updateSource, true);
      if (!(await readInstalled(p3.appRoot)).version)
        await ensureStudyLayout(p3);
      const result = await installFromFeed(
        this.paths(),
        p3.updateSource,
        feed,
        kinds,
        this.needService()
      );
      this.feed = feed;
      if (result.started) {
        await this.config.save(p3);
        this.onboarding?.close();
        this.onboarding = void 0;
        new import_obsidian5.Notice("\u5B89\u88C5\u5B8C\u6210\uFF0C\u5B66\u4E60\u670D\u52A1\u5DF2\u5C31\u7EEA");
        if (p3.openBrowserOnStart) await this.openStudy();
      } else if (result.missing === "resources") {
        await this.config.save(p3);
        new import_obsidian5.Notice("Helper \u7A0B\u5E8F\u5DF2\u5B89\u88C5\uFF0C\u5F53\u524D\u6570\u636E\u76EE\u5F55\u7F3A\u5C11\u9898\u5E93\uFF0C\u8BF7\u7EE7\u7EED\u5B89\u88C5\u5B66\u4E60\u8D44\u6E90\u5305");
      } else {
        new import_obsidian5.Notice("\u5B66\u4E60\u8D44\u6E90\u5305\u5DF2\u5B89\u88C5\uFF0C\u8BF7\u7EE7\u7EED\u5B89\u88C5 Helper \u7A0B\u5E8F\u540E\u542F\u52A8\u670D\u52A1");
      }
    });
  }
  async installLocal(files) {
    if (!files.length) throw new UserError("\u8BF7\u9009\u62E9\u672C\u5730 ZIP");
    if (!await ConfirmModal.ask(
      this.app,
      "\u5BFC\u5165\u672C\u5730 ZIP",
      files.some((f) => /^ielts-helper-full-/.test(import_node_path9.default.basename(f.file))) ? "\u5C06\u66F4\u65B0 Helper\uFF0C\u6309\u9700\u5B89\u88C5\u5305\u5185\u8D44\u6E90\uFF0C\u4E0D\u8986\u76D6\u5B66\u4E60\u8FDB\u5EA6\u3002\u8BF7\u5148\u4FDD\u5B58\u5F53\u524D\u7EC3\u4E60\uFF0C\u786E\u8BA4\u540E\u4F1A\u91CD\u542F\u5B66\u4E60\u670D\u52A1\u3002" : "\u8BF7\u5148\u4FDD\u5B58\u5F53\u524D\u7EC3\u4E60\u3002\u786E\u8BA4\u540E\u4F1A\u6821\u9A8C\u5B89\u88C5\u5305\u5E76\u91CD\u542F\u5B66\u4E60\u670D\u52A1\u3002"
    ))
      return false;
    await this.exclusive(async () => {
      const packages = await Promise.all(
        files.map((f) => localPackage(f.file, f.sha256))
      );
      if (!(await readInstalled(this.needProfile().appRoot)).version)
        await ensureStudyLayout(this.needProfile());
      const result = await installPackages(
        this.paths(),
        packages,
        this.needService()
      );
      if (result.started) {
        await this.config.save(this.needProfile());
        this.onboarding?.close();
        this.onboarding = void 0;
        new import_obsidian5.Notice("\u672C\u5730\u5B89\u88C5\u5B8C\u6210\uFF0C\u5B66\u4E60\u670D\u52A1\u5DF2\u5C31\u7EEA");
        if (this.needProfile().openBrowserOnStart) await this.openStudy();
      } else if (result.missing === "resources") {
        await this.config.save(this.needProfile());
        new import_obsidian5.Notice("Helper \u7A0B\u5E8F\u5DF2\u5B89\u88C5\uFF0C\u5F53\u524D\u6570\u636E\u76EE\u5F55\u7F3A\u5C11\u9898\u5E93\uFF0C\u8BF7\u7EE7\u7EED\u5BFC\u5165\u5B66\u4E60\u8D44\u6E90\u5305");
      } else {
        new import_obsidian5.Notice("\u5B66\u4E60\u8D44\u6E90\u5305\u5DF2\u5B89\u88C5\uFF0C\u8BF7\u7EE7\u7EED\u5BFC\u5165 Helper \u7A0B\u5E8F\u5305\u540E\u542F\u52A8\u670D\u52A1");
      }
    });
    return true;
  }
  async rollback() {
    if (await ConfirmModal.ask(
      this.app,
      "\u56DE\u9000 Helper",
      "\u5C06\u505C\u6B62\u672C\u63D2\u4EF6\u670D\u52A1\u5E76\u5207\u6362\u5230\u4E0A\u4E00\u7A0B\u5E8F\u7248\u672C\uFF0C\u5B66\u4E60\u6570\u636E\u4E0D\u56DE\u9000\u3002"
    ))
      await this.exclusive(
        () => rollbackHelper(this.paths(), this.needService())
      );
  }
  async upgradePlugin(confirm = true, selectedSource) {
    if (confirm && !await ConfirmModal.ask(
      this.app,
      "\u5347\u7EA7\u63D2\u4EF6",
      "\u63D2\u4EF6\u5C06\u6821\u9A8C\u5E76\u66FF\u6362\u6807\u51C6\u4E09\u6587\u4EF6\uFF0C\u7136\u540E\u91CD\u65B0\u52A0\u8F7D\u3002"
    ))
      return;
    await this.exclusive(async () => {
      const source = selectedSource ?? this.needProfile().updateSource;
      const release = await getPluginRelease(source, confirm);
      if (compareVersions(release.version, this.manifest.version) <= 0) {
        new import_obsidian5.Notice("\u5F53\u524D\u5DF2\u662F\u6700\u65B0\u7248\uFF0C\u65E0\u9700\u5347\u7EA7\u63D2\u4EF6");
        return;
      }
      const manager = this.app.plugins;
      if (!manager?.disablePlugin || !manager.enablePlugin)
        throw new UserError("\u5F53\u524D Obsidian \u4E0D\u652F\u6301\u81EA\u52A8\u91CD\u8F7D\uFF0C\u8BF7\u624B\u52A8\u5347\u7EA7\u63D2\u4EF6");
      const adapter = this.app.vault.adapter;
      const dir = import_node_path9.default.join(
        adapter.getBasePath(),
        this.manifest.dir || `${this.app.vault.configDir}/plugins/${this.manifest.id}`
      );
      await updatePlugin(
        source,
        release,
        dir,
        () => reloadAndVerify(manager, this.manifest.id, dir)
      );
    });
  }
  async refreshStatus() {
    if (!this.status || !this.alive) return;
    const version = await this.service?.version();
    const installed = this.profile ? await readInstalled(this.profile.appRoot).catch(() => ({})) : void 0;
    const newer = !!this.pluginRelease && compareVersions(
      this.pluginRelease.version,
      this.manifest.version
    ) > 0 || !!this.feed?.helper && !!version && compareVersions(this.feed.helper.version, version.version) > 0 || !!this.feed?.resources && !!installed?.resourcesVersion && compareVersions(
      this.feed.resources.version,
      installed.resourcesVersion
    ) > 0;
    if (this.alive)
      this.status.setText(
        newer ? "IELTS: \u6709\u65B0\u7248" : version ? "IELTS: \u5728\u7EBF" : "IELTS: \u79BB\u7EBF"
      );
  }
  async detectPython() {
    return detectPython();
  }
};
